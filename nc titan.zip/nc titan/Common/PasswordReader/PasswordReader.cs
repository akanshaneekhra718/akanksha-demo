﻿//  <copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>

namespace Titan.Common.PasswordReader;
/// <summary>
/// PasswordReader reads the passphrase 
/// </summary>
public static class PasswordReader
{
    public static string ReadFile(string filePath)
    {
        string fileContents = String.Empty;
        try
        {
            using (var fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.Read))
            using (var streamReader = new StreamReader(fileStream))
            {
                fileContents = streamReader.ReadToEnd();
            }
        }
        catch (Exception ex)
        {
            Logger.Log(TraceLevel.Error, $"Error reading file:" + ex.Message);
            throw;
        }

        return fileContents;
    }
}
