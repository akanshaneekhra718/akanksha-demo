﻿//  <copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>

namespace Titan.Common.TestConnector;
public class TestConnector : IDisposable
{
    private TcpClient myClient;
    private const int myWaitTimeForRetryInMillisecond = 1000;
    private const string SitEnvVarCheckIsSitMachine = "SystemIntegrationTestEnvironment";
    private const string SitEnvExpectedValue = "SIT_Machine";
    private const string SitEnvVarMachineIP = "SIT_Machine_IP";
    private const string SitEnvVarMachinePort = "SIT_Machine_PORT";
    private bool IsSITEnvironment => Environment.GetEnvironmentVariable(SitEnvVarCheckIsSitMachine)?.
                                            Contains(SitEnvExpectedValue) ?? false;

    private readonly string mySitMachineIp = Environment.GetEnvironmentVariable(SitEnvVarMachineIP) ?? "localhost";
    private readonly int mySitMachinePort = Environment.GetEnvironmentVariable(SitEnvVarMachinePort) == null ?
                                            TestConstants.Port : int.Parse(Environment.GetEnvironmentVariable(SitEnvVarMachinePort));
    private readonly Thread myTcpClientThread;
    private bool myRunUntilGetStopRequest;
    private bool myIsDisposed;
    public event EventHandler<TestMessage> DataReceivedEvent;

    public TestConnector()
    {
        myClient = new TcpClient();
        if (IsSITEnvironment)
        {
            Logger.Log(TraceLevel.Verbose, "SIT Machine detected");
            myTcpClientThread = new Thread(ConnectToTestServerAsync);
            myTcpClientThread.Name = "TcpTestClient";
            myTcpClientThread.IsBackground = true;
            myTcpClientThread.Start();
            myRunUntilGetStopRequest = true;
        }
    }

    private TestMessage DeserializeTestMessage(byte[] message)
    {
        try
        {            
            TestMessage testMessage = JsonSerializer.Deserialize<TestMessage>(message);
            return testMessage;
        }
        catch (Exception ex)
        {
            Logger.Log(ex);
        }
        return null;
    }

    private void ConnectToTestServerAsync()
    {
        TestMessage testMessage = new TestMessage();
        testMessage.ControlCommand = ControlCommands.Disconnect;
        Logger.Log(TraceLevel.Verbose, "Trying to connect Test Server...");
        do
        {
            try
            {
                ProcessConnection();
            }
            catch (SocketException)
            {
                Logger.Log(TraceLevel.Verbose, "TestClient: Disconnected State");
                Thread.Sleep(myWaitTimeForRetryInMillisecond);
            }
            catch (IOException)
            {
                Logger.Log(TraceLevel.Warning, "TestClient: On going connection dropped");
                DataReceivedEvent?.Invoke(this, testMessage);
                Thread.Sleep(myWaitTimeForRetryInMillisecond);
            }
            catch (InvalidOperationException)
            {
                DataReceivedEvent?.Invoke(this, testMessage);
                Logger.Log(TraceLevel.Error, "TestClient: Unable to send data");
            }
            catch (Exception ex)
            {
                Logger.Log(ex);
                break;
            }
            finally
            {
                try
                {
                    // On close TcpClient get disposed creating new for reconnection.
                    myClient?.Close();
                    myClient = new TcpClient();
                }
                catch(Exception ex)
                {
                    Logger.Log(ex);
                }
            }

        } while (myRunUntilGetStopRequest);
        Logger.Log(TraceLevel.Verbose, "Stopping Tcp Test client");
    }

    private void ProcessConnection()
    {
        myClient.Connect(mySitMachineIp, mySitMachinePort);
        Logger.Log(TraceLevel.Verbose, "Connected to TestServer {0}:{1}",mySitMachineIp,mySitMachinePort);
        while (myClient.Connected)
        {
            byte[] receiveMsg = new byte[1024];
            int byteRead = myClient.GetStream().Read(receiveMsg, 0, receiveMsg.Length);
            if (byteRead == 0)
                throw new IOException("TCP socket is in CLOSE_WAIT state");
            byte[] msg = new byte[byteRead];
            Array.Copy(receiveMsg,msg, byteRead);
            TestMessage testMessage = DeserializeTestMessage(msg);
            Logger.Log(TraceLevel.Verbose, "--------> Got Message TCP : {0}", JsonSerializer.Serialize(testMessage));

            if (testMessage!= null)
                DataReceivedEvent?.Invoke(this, testMessage);
        }
    }

    public void Send(byte[] messageBytes)
    {
        try
        {
            byte[] size = BitConverter.GetBytes(messageBytes.Length);
            byte[] toSend = new byte[messageBytes.Length + size.Length];
            Buffer.BlockCopy(size, 0, toSend, 0, size.Length);
            Buffer.BlockCopy(messageBytes, 0, toSend, size.Length, messageBytes.Length);
            myClient.GetStream().Write(toSend, 0, toSend.Length);
        }
        catch (Exception ex)
        {
            Logger.Log(TraceLevel.Error, "Unable to send SenlinkMessageType: {0}", messageBytes);
            Logger.Log(ex);
        }
    }

    public void Send(string stringData) => Send(Encoding.Unicode.GetBytes(stringData));

    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }

    protected virtual void Dispose(bool disposing)
    {
        if (!myIsDisposed && disposing)
        {
            myRunUntilGetStopRequest = false;
            myClient?.Close();
            myTcpClientThread?.Join();
            myClient?.Dispose();
            myIsDisposed = true;
        }
    }
}
