//  <copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>

namespace Titan.Common.TestConnector;

public static class TestConstants
{
    public const int Port = 4475;
}

