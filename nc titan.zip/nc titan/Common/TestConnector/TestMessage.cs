﻿//  <copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>

namespace Titan.Common.TestConnector
{
    public enum TestCommandType
    {
        Observe = 1,
        Control = 2
    }

    public enum TestTargets
    {
        WorkflowController = 1,
        SignalPipeline = 2,
        All = 3
    }

    public enum ControlCommands
    {
        Disconnect = 1,
        StopControlling = 2,
        Kill = 3,
        DelayOneTitanUIRoundTrip = 4,
        DelayAllTitanUIRoundTrip = 5,
        DelayApolloRoundTrip = 6,
        QueryNetworkParametersFromStorage = 7,
        ValidateSiteConfigurationStorage=8,
        DeleteSiteConfigurationStorage=9,
        Reconnect=10,
        QueryApolloSystemInformationFromStorage = 13,
        PacketDropLow = 14,
        PacketDropMedium = 15,
        PacketDropHigh = 16,
        NoUdpData = 17,
        SetPairingDetailsIntoStorage=18,
        QueryProtocolVersionFromSystemVersionInfo = 19,
        QueryTitanSystemInformation=20
    }

    public class TestMessage
    {
        public TestCommandType CommandType { get; set; }
        public TestTargets Target { get; set; }
        public ControlCommands ControlCommand { get; set; }
        public int TimePeriod { get; set; }
        public string PairingVersion{get;set;}
    }

    public class TestResponse
    {
        public TestResponseType Type { get; set; } = TestResponseType.Acknowledgement;
        public ControlCommands ControlCommandResponse { get; set; }
    }

    public enum TestResponseType
    {
        Acknowledgement = 1,
        WorkflowController,
        SignalPipeline
        
    }

    public static class TestTools
    {
        public static string GetTypeOfEnum<T>(T type)
        {
            return Enum.GetName(typeof(T), type);
        }
    }
}
