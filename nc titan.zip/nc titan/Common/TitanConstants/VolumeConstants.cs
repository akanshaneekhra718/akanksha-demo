﻿//  <copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>

namespace Titan.Common.TitanConstants;

/// <summary>
/// VolumeConstants contains all the Storage specific common constants
/// </summary>
public static class VolumeConstants
{
    // Storage specific common constants
    public static readonly string AppDirectoryPath = Directory.GetParent(Directory.GetParent(AppContext.BaseDirectory).FullName).FullName;
    public static readonly string ContainerDirectory = Path.Combine(AppDirectoryPath, "data");
    public static readonly string SchemaDirectory = Path.Combine(AppDirectoryPath, "schemas");
    public static readonly string SiteConfigurationFile = "SiteConfiguration.json";
    public static readonly string SystemVersionInfoFile = "SystemVersionInfo.json";
    public static readonly string SystemInformationFile = "SystemInformation.json";
    public static readonly string CertificateFile = "Neocor.siemens-healthineers.com.pfx";
    public static readonly string HttpsFile = "passphrase.txt";
}
