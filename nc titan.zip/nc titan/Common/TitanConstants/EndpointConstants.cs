﻿//  <copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>

namespace Titan.Common.TitanConstants;

/// <summary>
/// EndpointConstants contains all the endpoints specific common constants
/// </summary>
public static class EndpointConstants
{
    public static readonly string HostName = "localhost";
    public static readonly int SignalPipelineRestPort = 7601;
    public static readonly int WorkflowControllerRestPort = 7602;
    public static readonly int WorkflowControllerGrpcServerPort = 7000;
    public static readonly int SignalPipelineWebSocketPort = 7500;
    public static readonly int WorkflowControllerWebSocketPort = 7501;
    public static readonly int TitanUIPort = 8080;
    public static readonly string ConfigurationControllerRoute = "api/Configuration";
    public static readonly string SignalPipelineStartAcquisitionRoute = "api/SignalPipeline/StartAcquisition";
    public static readonly string SignalPipelineStopAcquisitionRoute = "api/SignalPipeline";
    public static readonly string Protocol = "http";
    public static readonly string HttpDefaultStatus = "false";
    public static readonly string WorkflowControllerGrpcServerUrl = Protocol + "://" + HostName + ":" + WorkflowControllerGrpcServerPort.ToString();
    public static readonly string SignalPipelineRestUrl = Protocol + "://" + HostName + ":" + SignalPipelineRestPort.ToString();
    public static readonly string WorkflowControllerRestUrl = Protocol + "://" + HostName + ":" + WorkflowControllerRestPort.ToString();
}
