﻿//  <copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace Titan.Common.TitanLogger;

/// <summary>
/// Logger class.
/// </summary>
public static class Logger
{
    /// <summary>
    /// Log Level string const.
    /// </summary>
    private const string TRACELEVEL = "TRACELEVEL";
    private static readonly string callingExecutable = Process.GetCurrentProcess().ProcessName ?? "Unknown";

    /// <summary>
    /// Time Stamp.
    /// </summary>
    private static string TimeStamp
    {
        get
        {
            return DateTime.UtcNow.ToString("yyyyMMdd hh:mm:ss.ffffff");
        }
    }

    /// <summary>
    /// Log Message with traceLevel and agruments.
    /// </summary>
    /// <param name="traceLevel">traceLevel as TraceLevel Enum present in System.Diagonistics.</param>
    /// <param name="format">format as string</param>
    /// <param name="arg">arguments as params</param>
    public static void Log(TraceLevel traceLevel, string format, params object?[] arg)
    {
        LogMessage(traceLevel, string.Format("{0}|{1}|{2}|{3}", TimeStamp, callingExecutable, traceLevel.ToString(), string.Format(format, arg)));
    }

    /// <summary>
    /// Log Message with traceLevel and message.
    /// </summary>
    /// <param name="traceLevel">traceLevel as TraceLevel Enum present in System.Diagonistics.</param>
    /// <param name="message">message as string</param>
    public static void Log(TraceLevel traceLevel, string message)
    {
        LogMessage(traceLevel, string.Format("{0}|{1}|{2}|{3}", TimeStamp, callingExecutable, traceLevel.ToString(), message));
    }

    /// <summary>
    /// Log Exception.
    /// </summary>
    /// <param name="exception">exception as Exception</param>
    public static void Log(Exception exception)
    {
        Log(TraceLevel.Error, string.Format("{0}|{1}|{2}", TimeStamp, callingExecutable, exception.ToString()));
    }

    /// <summary>
    ///  Gets Log level.
    /// </summary>
    /// <returns>TraceLevel.</returns>
    private static TraceLevel GetTraceLevel()
    {
        TraceLevel appTraceLevel;
        if (!Enum.TryParse(Environment.GetEnvironmentVariable(TRACELEVEL), out appTraceLevel))
        {
            appTraceLevel = TraceLevel.Warning;
        }

        return appTraceLevel;
    }

    /// <summary>
    ///  Log Message.
    /// </summary>
    /// <param name="traceLevel">traceLevel as TraceLevel Enum present in System.Diagonistics.</param>
    /// <param name="logdata">log data as string.</param>
    private static void LogMessage(TraceLevel traceLevel, string logdata)
    {
        TraceLevel appTraceLevel = GetTraceLevel();
        if ((appTraceLevel != TraceLevel.Off) && (appTraceLevel >= traceLevel))
        {
            Console.WriteLine(logdata);
        }
    }
}