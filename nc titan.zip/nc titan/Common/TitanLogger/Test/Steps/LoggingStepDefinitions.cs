// <copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>

namespace TitanLoggerUnitTest.Steps
{
    [Binding]
    public class LoggingStepDefinitions
    {
        StringWriter stringWriter = new StringWriter();

        [Given(@"TraceLevel is Set to Error")]
        public void GivenTraceLevelIsSetToError()
        {
            Environment.SetEnvironmentVariable("TRACELEVEL", TraceLevel.Error.ToString());
        }

        [When(@"Log API is called to log Error, Warning, Info, and Debug messages")]
        public void WhenLogAPIIsCalledToLogErrorWarningInfoAndDebugMessages()
        {
            Console.SetOut(stringWriter);
            Logger.Log(TraceLevel.Error, "This is {0} message", "error");
            Logger.Log(TraceLevel.Warning, "This is {0} message", "warning");
            Logger.Log(TraceLevel.Info, "This is info message");
            Logger.Log(TraceLevel.Verbose, "This is All message");
        }

        [Then(@"Messages up to the Error level are logged")]
        public void ThenMessagesUpToTheErrorLevelAreLogged()
        {
            Assert.IsTrue(stringWriter.ToString().Contains("This is error message"));
            Assert.IsFalse(stringWriter.ToString().Contains("This is warning message"));
            Assert.IsFalse(stringWriter.ToString().Contains("This is info message"));
            Assert.IsFalse(stringWriter.ToString().Contains("This is All message"));
        }

        [Given(@"TraceLevel is Set to Warning")]
        public void GivenTraceLevelIsSetToWarning()
        {
            Environment.SetEnvironmentVariable("TRACELEVEL", TraceLevel.Warning.ToString());
        }

        [Then(@"Messages up to the Warning level are logged")]
        public void ThenMessagesUpToTheWarningLevelAreLogged()
        {
            Assert.IsTrue(stringWriter.ToString().Contains("This is error message"));
            Assert.IsTrue(stringWriter.ToString().Contains("This is warning message"));
            Assert.IsFalse(stringWriter.ToString().Contains("This is info message"));
            Assert.IsFalse(stringWriter.ToString().Contains("This is All message"));
        }

        [Given(@"TraceLevel is Set to Info")]
        public void GivenTraceLevelIsSetToInfo()
        {
            Environment.SetEnvironmentVariable("TRACELEVEL", TraceLevel.Info.ToString());
        }

        [Then(@"Messages up to the Info level are logged")]
        public void ThenMessagesUpToTheInfoLevelAreLogged()
        {
            Assert.IsTrue(stringWriter.ToString().Contains("This is error message"));
            Assert.IsTrue(stringWriter.ToString().Contains("This is warning message"));
            Assert.IsTrue(stringWriter.ToString().Contains("This is info message"));
            Assert.IsFalse(stringWriter.ToString().Contains("This is All message"));
        }

        [Given(@"TraceLevel Set to Verbose")]
        public void GivenTraceLevelSetToVerbose()
        {
            Environment.SetEnvironmentVariable("TRACELEVEL", TraceLevel.Verbose.ToString());
        }

        [Then(@"Messages up to the Verbose level are logged")]
        public void ThenMessagesUpToTheVerboseLevelAreLogged()
        {
            Assert.IsTrue(stringWriter.ToString().Contains("This is error message"));
            Assert.IsTrue(stringWriter.ToString().Contains("This is warning message"));
            Assert.IsTrue(stringWriter.ToString().Contains("This is info message"));
            Assert.IsTrue(stringWriter.ToString().Contains("This is All message"));
        }

        [Given(@"TraceLevel Set to Off")]
        public void GivenTraceLevelSetToOff()
        {
            Environment.SetEnvironmentVariable("TRACELEVEL", TraceLevel.Off.ToString());
        }

        [Then(@"No Messages are logged")]
        public void ThenNoMessagesAreLogged()
        {
            Assert.IsFalse(stringWriter.ToString().Contains("This is error message"));
            Assert.IsFalse(stringWriter.ToString().Contains("This is warning message"));
            Assert.IsFalse(stringWriter.ToString().Contains("This is info message"));
            Assert.IsFalse(stringWriter.ToString().Contains("This is All message"));
        }

        [Given(@"TraceLevel is not set")]
        public void GivenTraceLevelIsNotSet()
        {
            Environment.SetEnvironmentVariable("TRACELEVEL", null);
        }
    }
}
