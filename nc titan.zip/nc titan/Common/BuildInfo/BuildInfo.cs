﻿//  < copyright > Restricted Copyright(c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace Titan.Common.BuildInfo;

public static class BuildInfo
{
    private const int BuildDateTimeIndex = 0;
    private const int CurrentCommitHash = 1;
    private static object[] assemblyMetadataAttributes = Assembly.GetExecutingAssembly()
                            .GetCustomAttributes(typeof(AssemblyMetadataAttribute), false);
                            
    public static string GetBuildDateTime()
    {
        AssemblyMetadataAttribute assemblyMetadata =
        (AssemblyMetadataAttribute)assemblyMetadataAttributes[BuildDateTimeIndex];
        return assemblyMetadata.Value ?? "Unknown";
    }
    public static string GetCommitHash()
    {
        AssemblyMetadataAttribute assemblyMetadata =
        (AssemblyMetadataAttribute)assemblyMetadataAttributes[CurrentCommitHash];
        return assemblyMetadata.Value ?? "Unknown";
    }
}