namespace Titan.Common.Test;

public class SystemIntegrationTestEnvironmentAttribute : Attribute, IResourceFilter 
{
    public void OnResourceExecuted(ResourceExecutedContext context)
    {
        // Nothing in here, as this is run after our Controller (Endpoint) method finishes
    }

    #region <TraceKey AT-TTN-2040/>
    public void OnResourceExecuting(ResourceExecutingContext context)
    {
        // Check SIT Environment from Environment variable
        bool IsSITEnvironment = Environment.GetEnvironmentVariable("SystemIntegrationTestEnvironment")?.
                                            Contains("SIT_Machine") ?? false;

        if (!IsSITEnvironment)
        {
            // If we're not running in SIT Environment mode, then just return a 404, this short-circuits the request pipeline.
            context.Result = new NotFoundResult();
        }
    }
    #endregion
}