//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>

namespace Titan.Common.Test;

static class TitanUITestModuleConstant
{
  public static int TitanPort = 8080;
  public static string HostName = "localhost";
  public static string NgProcessName = "node";
  public static string ProductTitle = "Titan";
  public static string VersionAttribute = "Version";
  public static string VersionNumber = "VA10A";
  public static string LabelAttribute = "label";
  public static string WebSocketUrl = "http://*:7500/";
  public static string  ModelDialogueAttribute = "disconnected";
  public static int defaultScreenWidth = 531;
  public static string CopyRightYear = "2023";
  public static string copyRightInformation = "Copyright © Siemens Healthcare GmbH, 2022-2023";
}
