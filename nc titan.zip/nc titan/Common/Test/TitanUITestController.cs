//  <copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>

namespace Titan.Common.Test;

public class TitanUITestController : IDisposable
{
    public TitanHomePage myTitanHomePage;
    private IWebDriver myWebDriver;
    private EventWaitHandle myWebSocketStarted;
    private EventWaitHandle myModalDialogVisible;
    private bool myIsDisposed = false;
    private AcquisitionData myAcquisitionData;
    private AcquisitionStatus myAcquisitionStatus;
    private HttpListener myHttpListener = new HttpListener();
    public bool Status { get; private set; }
    private const int MaxTimeoutTripTimeMsgTest = 20000;
    private const int MaxTimeoutForParameterAreaToBeVisible = 5 * 60; // required first time to connect to Apollo waiting for 5 min
    private const int MinParameterFetchInterval = 1;
    private const int MaxTimeoutForMessageToDisplay = 80;
    private const int MinMessageFetchInterval = 1;
    private const string TripTimeTag = "RoundTripTime from Titan to UI is";
    private bool myIsTitanServerIsDown;
    private const int MaxRetryCountIfWebElementNotFound = 3;
    private const int splashScreenTimeOut = 3500;
    private const string PacketDropTag = "Missed";
    private const string IncorrectOrderPacketsTag = "Incorrect sequence received expected :";
    private const string PacketRateTag = "Unanticipated acquisition rate detected, expected :";
    private CommonUITestDataContract myCommonUITestDataContract;
    private ConfigurationPage myConfigurationPage;
    private const int TCPPort = 6708;
    private const int UDPPort = 6709;
    private ConfigurationUtility myConfigurationUtility;
    private enum VitalSignsType
    {
        HR,
        SpO2
    };

    public TitanUITestController(IWebDriver WebDriver)
    {
        myWebDriver = WebDriver;
        myTitanHomePage = new TitanHomePage(myWebDriver);
        myWebSocketStarted = new EventWaitHandle(false, EventResetMode.ManualReset);
        myModalDialogVisible = new EventWaitHandle(false, EventResetMode.ManualReset);
        myAcquisitionData = new AcquisitionData();
        myAcquisitionStatus = new AcquisitionStatus();
        myHttpListener = new HttpListener();
        myConfigurationPage = new ConfigurationPage();
        myCommonUITestDataContract = new CommonUITestDataContract(myWebDriver);
        myConfigurationUtility = new ConfigurationUtility(myCommonUITestDataContract, myConfigurationPage, myTitanHomePage);
    }

    public bool CleanupForClickOnTheBookmark()
    {
        try
        {
            myWebDriver.Close();
            myWebDriver.Quit();
        }
        catch (Exception ex)
        {
            Logger.Log(ex);
            return false;
        }
        return true;
    }

    public bool WaitUntilTitanHomePageIsAvailable()
    {
        for (int retryCount = 0; retryCount < MaxRetryCountIfWebElementNotFound; retryCount++)
        {
            try
            {
                WebDriverWait wait = new WebDriverWait(myWebDriver, TimeSpan.FromSeconds(MaxTimeoutForParameterAreaToBeVisible));
                bool status = wait.Until(myWebDriver => myTitanHomePage.TitleHomePage?.GetAttribute("label") == "Titan");
                if (!status)
                {
                    Logger.Log(TraceLevel.Error, "Disconnect Dialogue is available on screen with title : " + myTitanHomePage.StaticPage.GetAttribute(TitanUITestModuleConstant.LabelAttribute));
                }
                return status;
            }
            catch (Exception ex)
            {
                Logger.Log(TraceLevel.Warning, $"Retry count : {retryCount}" + ex.Message);
            }
        }
        return false;
    }

    public bool WaitUntilSettingsIconIsEnabled()
    {
        for (int retryCount = 0; retryCount < MaxRetryCountIfWebElementNotFound; retryCount++)
        {
            try
            {
                WebDriverWait wait = new WebDriverWait(myWebDriver, TimeSpan.FromSeconds(MaxTimeoutForParameterAreaToBeVisible));
                bool status = wait.Until(myWebDriver => myTitanHomePage.ConfigurationSettingsIcon?.GetAttribute("aria-disabled") != "true");
                if (!status)
                {
                    Logger.Log(TraceLevel.Error, "Settings Icon is disabled");
                }
                return status;
            }
            catch (Exception ex)
            {
                Logger.Log(TraceLevel.Warning, $"Retry count : {retryCount}" + ex.Message);
            }
        }
        return false;
    }

    public bool WaitUntilTitanHomePageIsAvailableWithParameterArea()
    {
        DateTime startTime = DateTime.Now;
        while (DateTime.Now - startTime < TimeSpan.FromSeconds(MaxTimeoutForParameterAreaToBeVisible))//Retry until time out
        {
            try
            {
                WebDriverWait wait = new WebDriverWait(myWebDriver, TimeSpan.FromSeconds(MaxTimeoutForParameterAreaToBeVisible)); // wait max 60*5 for titan page to load 
                bool status = wait.Until(myWebDriver => myTitanHomePage.HrLabel?.Text == "HR");
                bool hrStatus = VerifyHRLabelPresentOnUI("HR");
                if (status && !hrStatus)
                {
                    Logger.Log(TraceLevel.Warning, "Disconnect Dialogue is available on screen with title : " + myTitanHomePage.StaticPage.GetAttribute(TitanUITestModuleConstant.LabelAttribute));
                }
                Logger.Log(TraceLevel.Verbose, $"Is myTitanHomePage found : {status}, and is it having HR level :{hrStatus}");
                return status && hrStatus;
            }
            catch (Exception ex)
            {
                Logger.Log(TraceLevel.Warning, $"Retry since : {(DateTime.Now - startTime).ToString()}" + ex.Message);
            }
        }
        return false;
    }

    public bool WaitUntilModalDialogIsAvailableWithLabel(string label)
    {
        for (int retryCount = 0; retryCount < MaxRetryCountIfWebElementNotFound; retryCount++)
        {
            try
            {
                WebDriverWait wait = new WebDriverWait(myWebDriver, TimeSpan.FromSeconds(MaxTimeoutForParameterAreaToBeVisible));

                bool? status = wait.Until(myWebDriver => myTitanHomePage.ModalDialog?.GetAttribute(TitanUITestModuleConstant.LabelAttribute) == label);
                if (status == false)
                {
                    Logger.Log(TraceLevel.Warning, "Disconnect Dialogue is available on screen with title : " + myTitanHomePage.StaticPage.GetAttribute(TitanUITestModuleConstant.LabelAttribute));
                    Logger.Log(TraceLevel.Warning, "Sh-Modal modal is on UI : " + myTitanHomePage.ModalDialog?.GetAttribute("visible"));
                }
                return status ?? false;
            }
            catch (Exception ex)
            {
                Logger.Log(TraceLevel.Warning, $"Retry count : {retryCount}" + ex.Message);
            }
        }
        return false;
    }

    public bool WaitUntilDisconnectsModalDialogGoesAway()
    {
        for (int retryCount = 0; retryCount < MaxRetryCountIfWebElementNotFound; retryCount++)
        {
            try
            {
                string visibility = myTitanHomePage.ModalDialog.GetAttribute("visible");

                Logger.Log(TraceLevel.Verbose, "Modal dialog available : " + visibility);
                if (visibility == "false")
                    return true;
                WebDriverWait wait = new WebDriverWait(myWebDriver, TimeSpan.FromSeconds(120));
                Logger.Log(TraceLevel.Verbose, "Start waiting");
                return wait.Until(myWebDriver =>
                {
                    bool status = wait.Until(myWebDriver => myTitanHomePage.ModalDialog.GetAttribute("visible").Equals("false"));
                    Logger.Log(TraceLevel.Info, "Waiting for Disconnect Dialogue to disappear" + status);
                    return status;
                });
            }
            catch (Exception ex)
            {
                Logger.Log(TraceLevel.Warning, $"Retry count : {retryCount}" + ex.Message);
            }
        }
        return false;
    }

    public bool WaitUntilStaticPageIsAvailableWithLabel(string label)
    {
        for (int retryCount = 0; retryCount < MaxRetryCountIfWebElementNotFound; retryCount++)
        {
            try
            {
                WebDriverWait wait = new WebDriverWait(new SystemClock(), myWebDriver,
                    TimeSpan.FromSeconds(MaxTimeoutForParameterAreaToBeVisible),
                    TimeSpan.FromMilliseconds(MinMessageFetchInterval));

                bool? status = wait.Until(myWebDriver => myTitanHomePage.StaticPage?.GetAttribute(TitanUITestModuleConstant.LabelAttribute) == label);
                if (status == false)
                {
                    Logger.Log(TraceLevel.Warning, "Static Page could not be fetched");
                    Logger.Log(TraceLevel.Warning, "Sh-Modal modal is on UI : " + myTitanHomePage.ModalDialog?.GetAttribute("visible"));
                    Logger.Log(TraceLevel.Warning, "Sh-Modal modal label on UI : " + myTitanHomePage.ModalDialog?.GetAttribute(TitanUITestModuleConstant.LabelAttribute));
                }
                return status ?? false;
            }
            catch (Exception ex)
            {
                Logger.Log(TraceLevel.Warning, $"Retry count : {retryCount}" + ex.Message);
            }
        }
        return false;
    }

    public bool LaunchBrowserNavigateToTitanURL()
    {
        try
        {
            Logger.Log(TraceLevel.Verbose, "Precondition: Launching Titan UI");
            myWebDriver.Manage().Window.Maximize();
            string pageAddress = Environment.GetEnvironmentVariable("TITAN_WEBPAGE_ADDRESS") ?? TitanUITestModuleConstant.HostName;
            string pageLink = "http://" + pageAddress + ":" + TitanUITestModuleConstant.TitanPort.ToString();
            myWebDriver.Navigate().GoToUrl(pageLink);
            Logger.Log(TraceLevel.Verbose, "Titan UI launched successfully");
            myIsTitanServerIsDown = false;
            return true;
        }
        catch (WebDriverException ex)
        {
            Logger.Log(TraceLevel.Error, "WebPage is not available (Most probably TitanUI is down) : " + ex.Message);
            myIsTitanServerIsDown = true;
            //This exception comes when page is not available and this is valid test for Titan
            return true;
        }
        catch (Exception ex)
        {
            Logger.Log(TraceLevel.Error, "When: Error in clicking on favorite icon:: " + ex.Message);
        }
        return false;
    }

    public bool VerifyIsTitanPageGotRecovered(int timeInMin)
    {
        DateTime dateTime = DateTime.UtcNow;
        TimeSpan duration = new TimeSpan(0, timeInMin, 0);
        while (DateTime.UtcNow - dateTime < duration)
        {
            LaunchBrowserNavigateToTitanURL();
            if (!myIsTitanServerIsDown)
            {
                Logger.Log(TraceLevel.Info, "Got recover with in :" + (DateTime.UtcNow - dateTime).TotalSeconds + " Sec");
                return true;
            }
            Thread.Sleep(100);
        }
        return false;
    }

    private string GetIconURL()
    {
        try
        {
            byte[] byteArray = null;
            string imageUrl = myTitanHomePage.IconImage.GetAttribute("href");
            Logger.Log(TraceLevel.Verbose, "icon image: {0}", imageUrl);
            HttpClient httpClient = new HttpClient();
            HttpResponseMessage response = httpClient.GetAsync(imageUrl).Result;
            if (response.IsSuccessStatusCode)
            {
                byteArray = response.Content.ReadAsByteArrayAsync().Result;
            }
            return CreateMD5Sum(byteArray);
        }
        catch (Exception ex)
        {
            Logger.Log(ex);
        }
        return string.Empty;
    }

    private string CreateMD5Sum(byte[] bytes)
    {
        try
        {
            MD5 md5 = MD5.Create();
            byte[] byteArray = md5.ComputeHash(bytes);
            StringBuilder stringBuilder = new StringBuilder();
            foreach (byte element in byteArray)
            {
                stringBuilder.Append(element.ToString("X2"));
            }
            return stringBuilder.ToString();
        }
        catch (Exception ex)
        {
            Logger.Log(ex);
        }
        return string.Empty;
    }

    public bool VerifySplashScreenIsPresent()
    {
        try
        {
            string text = myTitanHomePage.SplashScreenPage?.GetAttribute(TitanUITestModuleConstant.VersionAttribute);
            if (text.Contains(TitanUITestModuleConstant.VersionNumber))
            {
                Logger.Log(TraceLevel.Info, "Splash Screen is displayed in the browser. Version Info found is : " + text);
                return true;
            }
            Logger.Log(TraceLevel.Warning, "Some other display found in the browser. Having Version : " + text);
        }
        catch (NoSuchElementException ex)
        {
            Logger.Log(TraceLevel.Error, "Page not found with Exception: " + ex.Message);
            Logger.Log(TraceLevel.Error, "Version:\"{0}\" not found");
        }
        catch (Exception ex)
        {
            Logger.Log(ex);
        }
        return false;
    }

    public bool VerifySplashScreenIsPresentWithProductInfo()
    {
        try
        {
            string label = myTitanHomePage.SplashScreenPage?.GetAttribute(TitanUITestModuleConstant.LabelAttribute);
            string version = myTitanHomePage.SplashScreenPage?.GetAttribute(TitanUITestModuleConstant.VersionAttribute);
            string copyRight = myTitanHomePage.SplashScreenPage?.Text;
            if (label.Equals(TitanUITestModuleConstant.ProductTitle) && version.Contains(TitanUITestModuleConstant.VersionNumber) && copyRight.Contains(TitanUITestModuleConstant.CopyRightYear))
            {
                Logger.Log(TraceLevel.Info, "Splash Screen is displayed in the browser:" + label + version + copyRight);
                return true;
            }
            Logger.Log(TraceLevel.Warning, "Some other display found in the browser. Having Splash Screen Info : " + label + version + copyRight);
        }
        catch (NoSuchElementException ex)
        {
            Logger.Log(TraceLevel.Error, "Page not found with Exception: " + ex.Message);
        }
        catch (Exception ex)
        {
            Logger.Log(ex);
        }
        return false;
    }

    public bool VerifyModal(string label)
    {
        try
        {
            Logger.Log(TraceLevel.Verbose, "Going to verify {0}", label);
            if (WaitUntilModalDialogIsAvailableWithLabel(label))
            {
                Logger.Log(TraceLevel.Info, "Modal is displayed in the browser. Description found is : " + label);
                myWebSocketStarted.Set();
                return true;
            }
            Logger.Log(TraceLevel.Warning, "Modal is not displayed in the browser");
        }
        catch (Exception ex)
        {
            Logger.Log(ex);
        }
        return false;
    }

    private bool GetTripTime(string log, ref int tripTime)
    {
        try
        {
            Logger.Log(TraceLevel.Verbose, $"#### Console Log ####: {log}");
            string num = log.Split('"').Where(str => str.Contains(TripTimeTag)).FirstOrDefault().Split(':')[1].Split(' ')[1];
            Logger.Log(TraceLevel.Verbose, $" Got string {num}");
            tripTime = Int16.Parse(num);
            return true;
        }
        catch (Exception ex)
        {
            Logger.Log(ex);
        }
        return false;
    }

    private int GetAverageTripTime(int durationOfExecution = 0)
    {
        Logger.Log(TraceLevel.Verbose, $"Going for {durationOfExecution} sec sleep");
        Thread.Sleep(durationOfExecution * 1000);
        IEnumerable<LogEntry> logs = myWebDriver.Manage().Logs.GetLog(LogType.Browser).Where(log => log.ToString().Contains(TripTimeTag));
        int logCnt = 0;
        int SumOfTripTime = 0;
        foreach (LogEntry log in logs)
        {
            int tripTime = 0;
            if (GetTripTime(log.ToString(), ref tripTime))
            {
                SumOfTripTime += tripTime;
                logCnt++;
            }
            else
                Logger.Log(TraceLevel.Warning, $"Unable to decode string : {log.ToString()}");
        }
        if (logCnt > 0)
            return SumOfTripTime / logCnt; //Average Trip time
        return int.MaxValue;
    }

    public bool VerifyHrValuesInConsole(string hrValues)
    {
        string[] hrValuesArray = hrValues.Split(',').ToArray();
        int index = 0;
        string[] hrValuesMessage = new string[hrValuesArray.Length];
        foreach (var hrValue in hrValuesArray)
        {
            hrValuesMessage[index] = "HR is Changed to: " + hrValue;
            index++;
        }
        return VerifyMessageInConsole(hrValuesMessage); 
    }

    public bool VerifyApolloStatusInConsole(bool isApolloConnected)
    {
        return VerifyMessageInConsole("{"+ $"\\\"StatusType\\\":\\\"IsApolloConnected\\\",\\\"State\\\":{isApolloConnected.ToString().ToLower()}" + "}");
    }

    public bool VerifyTripTimeInConsole()
    {
        return VerifyMessageInConsole(TripTimeTag);
    }

    public bool VerifyTripTimeInConsole(int tripTimeThreshold, int durationOfExecution)
    {
        try
        {
            int averageTripTime = GetAverageTripTime(durationOfExecution);
            Logger.Log(TraceLevel.Info, $"Average Trip Time = {averageTripTime} and Threshold = {tripTimeThreshold}");
            if (averageTripTime < tripTimeThreshold)
                return true;
        }
        catch (Exception ex)
        {
            Logger.Log(ex);
        }
        return false;
    }

    public bool VerifyMessageInConsole(string message)
    {
        try
        {
            LogEntry[] logs = myWebDriver.Manage().Logs.GetLog(LogType.Browser).ToArray();
            foreach (LogEntry log in logs)
            {
                Logger.Log(TraceLevel.Verbose, log.ToString());
                if (log.ToString().Contains(message))
                    return true;
            }
        }
        catch (Exception ex)
        {
            Logger.Log(ex);
        }
        return false;
    }

    public bool VerifyMessageInConsole(string[] messages)
    {
        int foundCount = 0; 
        try
        {
            LogEntry[] logs = myWebDriver.Manage().Logs.GetLog(LogType.Browser).ToArray();
            foreach (string message in messages)
            {
                foreach (LogEntry log in logs)
                {
                    Logger.Log(TraceLevel.Verbose, log.ToString());
                    if (log.ToString().Contains(message))
                    {
                        foundCount++;
                        break;
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Logger.Log(ex);
        }
        return foundCount ==  messages.Count();
    }

    public bool IsTimeDifferenceBelowThreshold(TitanUITestController room, int timeDifferenceThreshold, int durationOfExecution)
    {
        try
        {
            int tripTimeOfControlRoom = room.GetAverageTripTime(durationOfExecution);
            int TripTimeOFExamRoom = this.GetAverageTripTime(); // no need to wait here since instance is already running 
            if (tripTimeOfControlRoom == int.MaxValue || TripTimeOFExamRoom == int.MaxValue) return false;
            int timeDifference = TripTimeOFExamRoom - tripTimeOfControlRoom;
            if (timeDifference < 0) timeDifference *= -1;
            Logger.Log(TraceLevel.Info, "Average TripTime ExamRoom = {0} ControlRoom = {1} and time difference = {2}",
            TripTimeOFExamRoom, tripTimeOfControlRoom, timeDifference);
            if (timeDifference < timeDifferenceThreshold)
                return true;
        }
        catch (Exception ex)
        {
            Logger.Log(ex);
        }
        return false;
    }

    public bool VerifyHRValue()
    {
        try
        {
            string value = FetchVitalSignParameterValue(VitalSignsType.HR, true);
            int hrValue = (value != "---") ? Int32.Parse(value) : -1;
            if (hrValue != -1)//HR Value -1 means we couldn't fetch the value
            {
                Logger.Log(TraceLevel.Info, "HR Value {0} displayed in the Titan UI is ", hrValue);
                return true;
            }
            Logger.Log(TraceLevel.Warning, "HR Value in the Titan found is " + hrValue);
        }
        catch (NoSuchElementException ex)
        {
            Logger.Log(TraceLevel.Error, "Page not found with Exception: " + ex.Message);
            Logger.Log(TraceLevel.Error, "HR Value:\"{0}\" not found");
        }
        catch (Exception ex)
        {
            Logger.Log(ex);
        }
        return false;
    }

    //check if HR value is present in Titan monitoring screen
    public bool VerifyHRValueAvailable()
    {
        bool isHRValueAvailable = false;
        try
        {
            string value = FetchVitalSignParameterValue(VitalSignsType.HR, true);
            if (!String.IsNullOrEmpty(value) && value != "---")
            {
                isHRValueAvailable = true;
                Logger.Log(TraceLevel.Warning, "HR Value found and displayed");
            }
            else
            {
                Logger.Log(TraceLevel.Warning, "HR Value not displayed");
            }
        }
        catch (Exception ex)
        {
            Logger.Log(ex);
        }
        return isHRValueAvailable;
    }

    private List<string> ConvertToValidRange(List<string> list, VitalSignsType vitalSignsType)
    {
        List<string> retList = new List<string>();
        foreach (string value in list)
        {
            int intvalue = int.Parse(value);
            switch (vitalSignsType)
            {
                case VitalSignsType.HR:
                    if (intvalue == 0)
                        retList.Add("---");
                    else
                        retList.Add(value);
                    break;
                case VitalSignsType.SpO2:
                    if (intvalue == 0)
                        retList.Add("---");
                    else
                        retList.Add(value);
                    break;
                default:
                    break;
            }
        }
        return retList;
    }

    private bool VerifyContinuosVitalSignValueList(string vitalSignList, VitalSignsType vitalSignsType)
    {
        List<string> expValues = vitalSignList.Split(',').ToList();
        expValues = ConvertToValidRange(expValues, vitalSignsType);
        List<string> capturedValues = new List<string>();
        try
        {
            DateTime endTime = DateTime.Now.AddSeconds(60);
            Logger.Log(TraceLevel.Verbose, "current time : " + DateTime.Now);
            Logger.Log(TraceLevel.Verbose, "end time : " + endTime);
            List<string> pairListNotFound = new List<string>();
            while (endTime > DateTime.Now)
            {

                string currentVitalValue = FetchVitalSignParameterValue(vitalSignsType);
                capturedValues.Add(currentVitalValue);
                capturedValues = capturedValues.Distinct().ToList();
                pairListNotFound = expValues.Except(capturedValues).ToList();
                if (pairListNotFound.Count == 0) break;
                Thread.Sleep(100);
            }

            capturedValues.ForEach(pair => Logger.Log(TraceLevel.Verbose, "Element captured : " + pair));
            pairListNotFound.ForEach(pair => Logger.Log(TraceLevel.Verbose, "Element Not found : " + pair));
            return pairListNotFound.Count == 0;
        }
        catch (Exception ex)
        {
            Logger.Log(ex);
        }

        Logger.Log(TraceLevel.Warning, "VitalSign Value fetched didn't matched, expValues : {0}", expValues);
        return false;
    }

    public bool VerifyContinuosSpO2ValueList(string SpO2_List) =>
         VerifyContinuosVitalSignValueList(SpO2_List, VitalSignsType.SpO2);

    public bool VerifyContinuosHRValueList(string HR_List) =>
        VerifyContinuosVitalSignValueList(HR_List, VitalSignsType.HR);

    public bool VerifyElectrodeMessageOnImpactedLeads(List<Tuple<string, string, string>> pairList, int rawFileTurnAroundTimeInMs)
    {
        List<Tuple<string, string, string>> tempPairList = new List<Tuple<string, string, string>>();
        try
        {
            DateTime endTime = DateTime.Now.AddMilliseconds(rawFileTurnAroundTimeInMs);
            Logger.Log(TraceLevel.Verbose, "current time of system : " + DateTime.Now);
            Logger.Log(TraceLevel.Verbose, "end time of system : " + endTime);
            List<Tuple<string, string, string>> pairListNotFound = new List<Tuple<string, string, string>>();
            while (endTime > DateTime.Now)
            {
                tempPairList.Add(GetElectrodeText());
                tempPairList = tempPairList.Distinct().ToList();
                pairListNotFound = pairList.Except(tempPairList).ToList();
                if (pairListNotFound.Count == 0) break;
                Thread.Sleep(100);
            }
            tempPairList.ForEach(pair => Logger.Log(TraceLevel.Verbose, "ECG Lead status captured are : " + pair));
            pairListNotFound.ForEach(pair => Logger.Log(TraceLevel.Verbose, "ECG Lead status Not found are : " + pair));
            return pairListNotFound.Count == 0;

        }
        catch (NoSuchElementException)
        {
            Logger.Log(TraceLevel.Error, "Static Page is available on screen with title : " + myTitanHomePage.StaticPage.GetAttribute(TitanUITestModuleConstant.LabelAttribute));
        }
        catch (Exception ex)
        {
            Logger.Log(ex);
        }
        return false;
    }

    private Tuple<string, string, string> GetElectrodeText()
    {
        for (int i = 0; i <= 2; i++)
        {
            try
            {
                string leadI = myTitanHomePage.ElectrodeTextOnLeadI?.Text;
                string leadII = myTitanHomePage.ElectrodeTextOnLeadII?.Text;
                string leadIII = myTitanHomePage.ElectrodeTextOnLeadIII?.Text;

                return new Tuple<string, string, string>(leadI, leadII, leadIII);

            }
            catch (Exception ex)
            {
                Logger.Log(TraceLevel.Warning, $"{i} retry for finding ECG Lead status:" + ex.Message);
                Thread.Sleep(10);
            }
        }
        return new Tuple<string, string, string>("Unable to Fetch ECG Lead I status", "Unable to Fetch ECG Lead II status", "Unable to Fetch ECG Lead III status");
    }

    public bool VerifyMessageNotOnUI(IWebElement displayTextLocator, string expectedText, int timeInSec = MaxTimeoutForMessageToDisplay) =>
        VerifyMessageOnUI(displayTextLocator, expectedText, timeInSec, true);

    public bool VerifyMessageOnUI(IWebElement displayTextLocator, string expectedText, int timeInSec = MaxTimeoutForMessageToDisplay, bool isNotPresent = false)
    {
        for (int retryCount = 0; retryCount < MaxRetryCountIfWebElementNotFound; retryCount++)
        {
            try
            {
                WebDriverWait wait = new WebDriverWait(myWebDriver, TimeSpan.FromSeconds(timeInSec));
                bool status = wait.Until(myWebDriver => isNotPresent ^ displayTextLocator.Text.Equals(expectedText));

                if (status)
                {
                    Logger.Log(TraceLevel.Info, $"Actual Message: {displayTextLocator.Text} match with Expected Message: {expectedText} text");
                    return true;
                }
                Logger.Log(TraceLevel.Warning, $"Actual Message: {displayTextLocator.Text} does not match with Expected Message: {expectedText} text");
            }
            catch (Exception ex)
            {
                Logger.Log(TraceLevel.Warning, $"Retry count : {retryCount}" + ex.Message);
            }
        }
        return false;
    }

    public bool VerifyIconType(IWebElement iconLocator, string iconType, int timeInSec = MaxTimeoutForMessageToDisplay)
    {
        for (int retryCount = 0; retryCount < MaxRetryCountIfWebElementNotFound; retryCount++)
        {
            try
            {
                WebDriverWait wait = new WebDriverWait(myWebDriver, TimeSpan.FromSeconds(timeInSec));
                bool status = wait.Until(myWebDriver => iconLocator.GetAttribute("icon").Equals(iconType));

                Logger.Log(TraceLevel.Verbose, "Icon is present on the Titan UI of Type " + iconLocator.GetAttribute("icon"));
                return status;
            }
            catch (Exception ex)
            {
                Logger.Log(TraceLevel.Warning, $"Retry count : {retryCount}" + ex.Message);
            }
        }
        return false;
    }

    public bool VerifyIconNotPresentOnUI(IWebElement iconLocator, int timeInSec = MaxTimeoutForMessageToDisplay) =>
        VerifyIconPresentOnUI(iconLocator, timeInSec, false);

    public bool VerifyIconPresentOnUI(IWebElement iconLocator, int timeInSec = MaxTimeoutForMessageToDisplay, bool isVisible = true)
    {
        for (int retryCount = 0; retryCount < MaxRetryCountIfWebElementNotFound; retryCount++)
        {
            try
            {
                WebDriverWait wait = new WebDriverWait(myWebDriver, TimeSpan.FromSeconds(timeInSec));
                bool status = wait.Until(myWebDriver => iconLocator.Displayed == isVisible);

                if (status)
                {
                    Logger.Log(TraceLevel.Verbose, $"Icon present on the Titan UI is : {iconLocator.Displayed}");
                    return true;
                }
                Logger.Log(TraceLevel.Warning, $"Icon not present on the Titan UI is {iconLocator.Displayed}");
            }
            catch (Exception ex)
            {
                Logger.Log(TraceLevel.Warning, $"Retry count : {retryCount}" + ex.Message);
            }
        }
        return false;
    }

    public bool VerifySpo2MessageAndIconsPresentOnUI(string expectedText, string iconType, int timeInSec)
    {
        return VerifyIconType(myTitanHomePage.Spo2StatusIcon, iconType, timeInSec) &&
                VerifyMessageOnUI(myTitanHomePage.Spo2StatusText, expectedText, timeInSec);
    }

    private bool VerifyLabel(IWebElement labelLocator, string expectedText)
    {
        for (int retryCount = 0; retryCount < 3; retryCount++)
        {
            try
            {
                WebDriverWait wait = new WebDriverWait(myWebDriver, TimeSpan.FromSeconds(MaxTimeoutForMessageToDisplay));

                bool status = wait.Until(myWebDriver => labelLocator?.Text == expectedText);

                if (status)
                {
                    Logger.Log(TraceLevel.Info, $"Actual Label found in the UI is : {labelLocator.Text} and match with Expected Label: {expectedText}");
                    return true;
                }
                Logger.Log(TraceLevel.Warning, $"Actual Label found in the UI is: {labelLocator.Text} does not match with Expected Label: {expectedText}");

            }
            catch (NoSuchElementException ex)
            {
                Logger.Log(TraceLevel.Error, "Page not found with Exception: " + ex.Message);
                Logger.Log(TraceLevel.Error, "Disconnect Dialogue is available on screen with title : " + myTitanHomePage.StaticPage.GetAttribute(TitanUITestModuleConstant.LabelAttribute));
                Logger.Log(TraceLevel.Error, "Label :\"{0}\" not found in the UI is", expectedText);
            }
            catch (Exception ex)
            {
                Logger.Log(ex);
            }
        }
        return false;
    }

    public bool VerifySweepSpeedPresentOnUI(string sweepSpeed)
    {
        return VerifyLabel(myTitanHomePage.SweepSpeedLabel, sweepSpeed);
    }

    public bool VerifySensitivityPresentOnUI(string Sensitivity)
    {
        return VerifyLabel(myTitanHomePage.Sensitivity, Sensitivity);
    }

    public bool VerifyHRLabelPresentOnUI(string HRLabel)
    {
        return VerifyLabel(myTitanHomePage.HrLabel, HRLabel);
    }

    public bool IsMultipleLabelPresentOnUI(string labels, string elementToBeChecked)
    {
        for (int retryCount = 0; retryCount < 3; retryCount++)
        {
            try
            {
                if (labels.Contains(','))
                {
                    IEnumerable<string> currentLabelList;
                    List<string> expectedLabelList = labels.Split(',').ToList();
                    WebDriverWait wait = new WebDriverWait(myWebDriver, TimeSpan.FromSeconds(MaxTimeoutForMessageToDisplay));
                    switch (elementToBeChecked)
                    {
                        case "WaveformLabels":
                            currentLabelList = wait.Until(myWebDriver => myTitanHomePage.WaveformLabels.Select(actualLabels => actualLabels.Text));
                            break;
                        case "GainIndicatorText":
                            currentLabelList = wait.Until(myWebDriver => myTitanHomePage.GainIndicatorText.Select(actualLabels => actualLabels.Text));
                            break;
                        default:
                            return false;
                    }
                    IEnumerable<string> labelsNotFound = expectedLabelList.Except(currentLabelList);

                    if (labelsNotFound.ToList<string>().Count != 0)
                    {
                        foreach (string label in labelsNotFound)
                        {
                            Logger.Log(TraceLevel.Error, "Label not found {0} in the Titan UI", label);
                        }
                    }
                    else
                    {
                        Logger.Log(TraceLevel.Verbose, "All Labels found in the Titan UI");
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Log(TraceLevel.Warning, $"Retry count : {retryCount}" + ex.Message);
            }
        }
        return false;
    }

    public bool VerifyGainIndicatorLabelPresentOnUI(string gainIndicatorLabel)
    {
        WebDriverWait wait = new WebDriverWait(myWebDriver, TimeSpan.FromSeconds(MaxTimeoutForMessageToDisplay));
        if (!wait.Until(myWebDriver => myTitanHomePage.GainIndicatorText.ToList().Count > 1))
        {
            Logger.Log(TraceLevel.Warning, "Unable to find the ECG labels in the UI");
            return false;
        }

        return IsMultipleLabelPresentOnUI(gainIndicatorLabel, "GainIndicatorText");
    }

    public bool VerifyWaveformLabelPresentOnUI(string labels)
    {
        WebDriverWait wait = new WebDriverWait(myWebDriver, TimeSpan.FromSeconds(MaxTimeoutForMessageToDisplay));
        if (!wait.Until(myWebDriver => myTitanHomePage.WaveformLabels.ToList().Count > 1))
        {
            Logger.Log(TraceLevel.Warning, "Unable to find the Waveform labels in the UI");
            return false;
        }
        return IsMultipleLabelPresentOnUI(labels, "WaveformLabels");
    }

    public bool VerifyGainIndicatorHeightInPixel(int height, int errorPercentage)
    {
        bool status = true;
        int monitorWidth = myWebDriver.Manage().Window.Size.Width;
        double pixelPerMM = (double)monitorWidth / (double)TitanUITestModuleConstant.defaultScreenWidth;
        // Min Error Allowed
        int expGainIndicatorHeightInPixelMin = Convert.ToInt32(pixelPerMM * (height - (height * errorPercentage / 100)));

        // Max Error Allowed
        int expGainIndicatorHeightInPixelMax = Convert.ToInt32(pixelPerMM * (height + (height * errorPercentage / 100)));

        int actualGainIndicatorHeightInPixel = 0;
        WebDriverWait wait = new WebDriverWait(myWebDriver, TimeSpan.FromSeconds(MaxTimeoutForMessageToDisplay));
        if (!wait.Until(myWebDriver => myTitanHomePage.GainIndicatorIcons.ToList().Count > 1))
        {
            Logger.Log(TraceLevel.Warning, "Unable to find the ECG Gain Indicator in the UI");
            return false;
        }
        for (int retryCount = 0; retryCount < 3; retryCount++)
        {
            try
            {
                foreach (IWebElement GainIndicatorValue in myTitanHomePage.GainIndicatorIcons)
                {
                    actualGainIndicatorHeightInPixel = Convert.ToInt32(GainIndicatorValue.GetAttribute("height"));
                    Logger.Log(TraceLevel.Verbose, $"Gain Indicator Value in Pixel found {actualGainIndicatorHeightInPixel} in the Titan UI");

                    // it should be within 10% error which is allowed
                    if (actualGainIndicatorHeightInPixel >= expGainIndicatorHeightInPixelMin && actualGainIndicatorHeightInPixel <= expGainIndicatorHeightInPixelMax)
                    {
                        Logger.Log(TraceLevel.Info, $"Actual Gain Indicator Value(pixel) found in the UI is : {actualGainIndicatorHeightInPixel} match with the Expected Gain Indicator(pixel): which is within {expGainIndicatorHeightInPixelMin} and {expGainIndicatorHeightInPixelMax}");
                    }
                    else
                    {
                        //not breaking or returning false here, since we need to check gain indicator for the all the labels. This will help in better debugging for which labels it was not proper.
                        status = false;
                        Logger.Log(TraceLevel.Error, $"Actual Gain Indicator Value(pixel) found in the UI is : {actualGainIndicatorHeightInPixel} did not match with the Expected Gain Indicator(pixel): which is within {expGainIndicatorHeightInPixelMin} and {expGainIndicatorHeightInPixelMax}");
                    }
                }
                return status;
            }
            catch (Exception ex)
            {
                Logger.Log(TraceLevel.Warning, $"Retry count : {retryCount}" + ex.Message);
            }
        }
        return status;
    }

    public bool VerifySpO2LabelPresentOnUI(string SpO2Label) =>
        VerifyLabel(myTitanHomePage.SpO2Label, SpO2Label);

    public bool VerifySpO2Value()
    {
        try
        {
            string value = FetchVitalSignParameterValue(VitalSignsType.SpO2, true);
            int SpO2Value = (value != "---") ? Int32.Parse(value) : -1;
            if (SpO2Value != -1)//SpO2 Value -1 means we couldn't fetch the value
            {
                Logger.Log(TraceLevel.Info, "SpO2 Value {0} displayed in the Titan UI", SpO2Value);
                return true;
            }
            Logger.Log(TraceLevel.Info, "SpO2 Value in the Titan found is " + SpO2Value);
        }
        catch (NoSuchElementException ex)
        {
            Logger.Log(TraceLevel.Error, "Page not found with Exception: " + ex.Message);
            Logger.Log(TraceLevel.Error, "SpO2 Value:\"{0}\" not found");
        }
        catch (Exception ex)
        {
            Logger.Log(ex);
        }
        return false;
    }

    private string FetchVitalSignParameterValue(VitalSignsType vitalSignsType, bool value = false)
    {
        for (int retryCount = 0; retryCount < MaxRetryCountIfWebElementNotFound; retryCount++)
        {
            try
            {
                IWebElement vitalSignParameterLocator = null;
                switch (vitalSignsType)
                {
                    case VitalSignsType.HR:
                        vitalSignParameterLocator = myTitanHomePage.HrValue;
                        break;
                    case VitalSignsType.SpO2:
                        vitalSignParameterLocator = myTitanHomePage.SpO2Value;
                        break;
                    default:
                        Logger.Log(TraceLevel.Error, "Not supported Vital Parameter " + vitalSignParameterLocator.ToString());
                        return String.Empty;
                }
                if (value)
                {
                    WebDriverWait wait = new WebDriverWait(myWebDriver, TimeSpan.FromSeconds(MaxTimeoutForMessageToDisplay));
                    bool status = wait.Until(myWebDriver => vitalSignParameterLocator?.Text != "---");

                    if (status)
                    {
                        return vitalSignParameterLocator?.Text;
                    }
                    Logger.Log(TraceLevel.Verbose, "$$$ VitalSignParameter text is : " + vitalSignParameterLocator?.Text);
                    return "---";
                }
                else
                {
                    string VitalSignParameterText = vitalSignParameterLocator?.Text;
                    Logger.Log(TraceLevel.Verbose, "$$$ VitalSignParameter text is : " + VitalSignParameterText);
                    if (!(string.IsNullOrEmpty(VitalSignParameterText)))
                    {
                        return VitalSignParameterText;
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Log(TraceLevel.Error, "VitalSignParameter value couldn't be fetched");
                Logger.Log(TraceLevel.Error, "Modal Dialogue is available on screen with title : " + myTitanHomePage.ModalDialog?.GetAttribute(TitanUITestModuleConstant.LabelAttribute));
                Logger.Log(ex);
            }
        }
        return String.Empty;
    }

    private bool VerifyVitalSignParameterValueIsPresent(IWebElement vitalSignParameterLocator, string value)
    {
        for (int retryCount = 0; retryCount < MaxRetryCountIfWebElementNotFound; retryCount++)

        {
            try
            {
                WebDriverWait wait = new WebDriverWait(new SystemClock(), myWebDriver,
                TimeSpan.FromSeconds(MaxTimeoutForParameterAreaToBeVisible),
                TimeSpan.FromMilliseconds(MinParameterFetchInterval));
                bool? status = wait.Until(myWebDriver => vitalSignParameterLocator?.Text == value);
                return status ?? false;
            }
            catch (NoSuchElementException ex)
            {
                Logger.Log(TraceLevel.Error, "element not found with Exception: " + ex.Message);
                Logger.Log(TraceLevel.Error, $"VitalSign Value:\"{value}\" not found");
            }
            catch (Exception ex)
            {
                Logger.Log(ex);

            }
        }
        return false;
    }

    public bool VerifyHRValueIsPresent(string value) =>
        VerifyVitalSignParameterValueIsPresent(myTitanHomePage.HrValue, value);

    public bool VerifySpO2ValueIsPresent(string value) =>
        VerifyVitalSignParameterValueIsPresent(myTitanHomePage.SpO2Value, value);

    public bool VerifyHRUnitPresentOnUI(string HRUnit) =>
         VerifyLabel(myTitanHomePage.HRUnit, HRUnit);

    public bool VerifySPO2UnitPresentOnUI(string SPO2Unit) =>
         VerifyLabel(myTitanHomePage.SPO2Unit, SPO2Unit);

    public bool VerifySPO2DisconnectTextOnUI(List<Tuple<string, string>> pairList, int rawFileTurnAroundTimeInMs)
    {
        string text;
        string icon;
        List<Tuple<string, string>> tempPairList = new List<Tuple<string, string>>();
        try
        {
            DateTime endTime = DateTime.Now.AddMilliseconds(rawFileTurnAroundTimeInMs);
            Logger.Log(TraceLevel.Verbose, "current time of the system is : " + DateTime.Now);
            Logger.Log(TraceLevel.Verbose, "end time i=of the system is : " + endTime);
            List<Tuple<string, string>> pairListNotFound = new List<Tuple<string, string>>();
            while (endTime > DateTime.Now)
            {
                text = myTitanHomePage.Spo2StatusText?.Text;
                icon = myTitanHomePage.Spo2StatusIcon?.Displayed == true ? "Present" : "Not Present";
                tempPairList.Add(Tuple.Create(text, icon));
                tempPairList = tempPairList.Distinct().ToList();
                pairListNotFound = pairList.Except(tempPairList).ToList();
                if (pairListNotFound.Count == 0) break;
                Thread.Sleep(100);
            }
            tempPairList.ForEach(pair => Logger.Log(TraceLevel.Verbose, "SPO2 Element captured in the UI are : " + pair));
            pairListNotFound.ForEach(pair => Logger.Log(TraceLevel.Verbose, "SPO2 Element Not found in the UI are : " + pair));
            return pairListNotFound.Count == 0;

        }
        catch (NoSuchElementException)
        {
            Logger.Log(TraceLevel.Error, "Static Page is available on screen with title : " + myTitanHomePage.StaticPage.GetAttribute(TitanUITestModuleConstant.LabelAttribute));
        }
        catch (Exception ex)
        {
            Logger.Log(ex);
        }
        return false;
    }

    public bool VerifyNoSPO2StatusMessageAndIconPresentOnUI(string expectedText)
    {
        try
        {
            return VerifyIconNotPresentOnUI(myTitanHomePage.Spo2StatusIcon) &&
                        VerifyMessageNotOnUI(myTitanHomePage.Spo2StatusText, expectedText);
        }
        catch (Exception ex)
        {
            Logger.Log(ex);
        }
        return false;
    }

    public bool ConfigureTitanToConnectApollo()
    {
        bool isConfigured = false;
        // As per the logs observer in the pipeline recovering is taking 1 min, so for safer side selected 3 min max recovery time.
        TimeSpan maxTimeAllowedToRetry = TimeSpan.FromMinutes(3);
        DateTime startTime = DateTime.UtcNow;
        LaunchBrowserNavigateToTitanURL();
        Thread.Sleep(splashScreenTimeOut); //wait for splash screen to go away
        WaitUntilSettingsIconIsEnabled(); //verifying Titan Container is not down
        if (IsTitanConfiguredToConnectApollo())
        {
            Logger.Log(TraceLevel.Info, "Already Configured with Valid Apollo");
            isConfigured = true;
        }
        while (!isConfigured && DateTime.UtcNow - startTime < maxTimeAllowedToRetry)
        {
            try
            {
                myCommonUITestDataContract.Click(myTitanHomePage.SettingsIcon);
                myCommonUITestDataContract.Click(myConfigurationPage.EditButton);
                myCommonUITestDataContract.Click(myConfigurationPage.HostName);
                myCommonUITestDataContract.SelectAndClearTextBox(myConfigurationPage.HostName);
                myCommonUITestDataContract.EnterTextInTextBox(myConfigurationPage.HostName, myConfigurationUtility.GetSystemIPAddress());
                myCommonUITestDataContract.Click(myConfigurationPage.TcpPort);
                myCommonUITestDataContract.SelectAndClearTextBox(myConfigurationPage.TcpPort);
                myCommonUITestDataContract.EnterTextInTextBox(myConfigurationPage.TcpPort, TCPPort.ToString());
                myCommonUITestDataContract.Click(myConfigurationPage.UdpPort);
                myCommonUITestDataContract.SelectAndClearTextBox(myConfigurationPage.UdpPort);
                myCommonUITestDataContract.EnterTextInTextBox(myConfigurationPage.UdpPort, UDPPort.ToString());
                myCommonUITestDataContract.Click(myConfigurationPage.ApplyButton);
                myCommonUITestDataContract.ExecuteJavaScript(myConfigurationPage.CancelJavaScript);

                Logger.Log(TraceLevel.Verbose, "Configuration is saved successfully");
                isConfigured = true;
            }
            catch (Exception ex)
            {
                Logger.Log(TraceLevel.Warning, "Unable to save configuration Setting, mostly container is down");
                Logger.Log(ex);
                Logger.Log(TraceLevel.Info, "Closing the configuration dialogue and retry after 100ms");
                myCommonUITestDataContract.ExecuteJavaScript(myConfigurationPage.CancelJavaScript);
                Thread.Sleep(100);
            }
        }
        CleanupForClickOnTheBookmark();
        return isConfigured;
    }

    bool IsTitanConfiguredToConnectApollo()
    {
        myCommonUITestDataContract.Click(myTitanHomePage.SettingsIcon);
        bool isConfigured =
            myConfigurationUtility.GetSystemIPAddress().Equals(myCommonUITestDataContract.GetAttributeValue(myConfigurationPage.HostName, "value"))
         && TCPPort.ToString().Equals(myCommonUITestDataContract.GetAttributeValue(myConfigurationPage.TcpPort, "value"))
         && UDPPort.ToString().Equals(myCommonUITestDataContract.GetAttributeValue(myConfigurationPage.UdpPort, "value"));
        myCommonUITestDataContract.ExecuteJavaScript(myConfigurationPage.CancelJavaScript);
        return isConfigured;
    }

    public bool VerifyContinuosHRValueList(string HR_List, int duration)
    {
        int i = 0;
        bool result = true;
        while (i < duration)
        {
            result = result && VerifyContinuosHRValueList(HR_List);
            i++;
        }
        return result;
    }
    
    public void Dispose()
    {
        if (!myIsDisposed && myHttpListener != null)
        {
            myHttpListener.Close();
            myHttpListener = null;
            myIsDisposed = true;
        }
    }
}
