//  <copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>

namespace Titan.Common.Test;
public static class WebDriver
{
    public enum BrowserType
    {
        Chrome,
        Edge,
        Firefox
    }
     /// <summary>
     /// Methods Creates WebDriver Instance both Local and Remote as per the parameter value passed
    /// </summary>
    /// <param name="browserType">Pass browserType</param>
    /// <param name="hubUrl">Pass hubURL to create Remote WebDriver </param>
    public static IWebDriver CreateInstance(BrowserType browserType, string hubUrl = null)
    {
        IWebDriver webDriver = null;
        
        switch (browserType)
        {
            case BrowserType.Chrome:
                ChromeOptions chromeOptions = new ChromeOptions();
                chromeOptions.SetLoggingPreference(LogType.Browser, LogLevel.All);
                webDriver = (string.IsNullOrEmpty(hubUrl) ? new ChromeDriver(chromeOptions) : GetRemoteWebDriver(hubUrl, chromeOptions));
                break;

           case BrowserType.Edge:
                EdgeOptions edgeOptions = new EdgeOptions();
                edgeOptions.SetLoggingPreference(LogType.Browser, LogLevel.All);
                webDriver = (string.IsNullOrEmpty(hubUrl) ? new EdgeDriver(edgeOptions) : GetRemoteWebDriver(hubUrl, edgeOptions));
                break;

            case BrowserType.Firefox:
                FirefoxOptions firefoxOptions = new FirefoxOptions();
                firefoxOptions.SetLoggingPreference(LogType.Browser, LogLevel.All);
                webDriver = (string.IsNullOrEmpty(hubUrl) ? new FirefoxDriver(firefoxOptions) : GetRemoteWebDriver(hubUrl, firefoxOptions));
                break;
        }
        return webDriver;
    }
    
    private static IWebDriver GetRemoteWebDriver(string hubUrl, DriverOptions options)
    {
        return new RemoteWebDriver(
                    new Uri(hubUrl),
                    options
                );
    }

    /// <summary>
    ///  Below method quit the whole browser session along with all the associated browser windows, tabs and pop-ups.
    /// </summary>
    /// <param name="driver"></param>
    /// <returns>bool</returns>
    public static bool CleanupForClickOnTheBookmark(IWebDriver driver)
    {
        bool isCleared = false;
        try
        {
            driver.Quit();
            isCleared = true;
        }
        catch (Exception exception)
        {
            Logger.Log(exception);
        }
        return isCleared;
    }

    /// <summary>
    /// Methods Kills the Preexisting browser process if avilable
    /// </summary>
    public static bool KillWebDriverProcess(BrowserType browser)
    {
        bool webDriverProcessKilled = false;
        string webDriverProcess = browser switch
        {
            BrowserType.Chrome => "chromedriver",
            BrowserType.Edge => "msedgedriver",
            BrowserType.Firefox => "geckodriver",
            _=>string.Empty
        };
        if(!string.IsNullOrEmpty(webDriverProcess))
        {
            Process.GetProcessesByName(webDriverProcess).ToList().ForEach(e => { e.Kill(); e.WaitForExit(5000);});
            Process.GetProcessesByName("chrome").ToList().ForEach(e => { e.Kill(); e.WaitForExit(5000); });
            webDriverProcessKilled = true;
        }
        return webDriverProcessKilled;
    }
}
