//  <copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>

namespace Titan.Common.Test;
class ApolloSimulatorController
{
    private readonly List<Process> myProcessList;
    public string myCurrentTestCaseId;
    private const int DefaultTcpPort = 6708;
    private const string ApolloNonRespondingScenarioNo = "27";
    private const string ApolloToSendInvalidLengthOfDataPacket = "10";
    private const string ApolloToSendNoDataPacketAfter20Sec = "16";
    private const string LogFolderName = "Logs";
    private const string ApolloSimulatorApplicationName = "ApolloSimulator";

    public ApolloSimulatorController()
    {
        myProcessList = new List<Process>();
        myCurrentTestCaseId = String.Empty;
    }
    private bool StopApplicationInProcessList(string processName)
    {
        try
        {
            for (int i = 0; i < myProcessList.Count; i++)
            {
                if (!myProcessList[i].HasExited)
                {

                    Logger.Log(TraceLevel.Verbose, "Current Process Name: {0} Id: {1}.", myProcessList[i].ProcessName, myProcessList[i].Id);

                    if (myProcessList[i].ProcessName == processName)
                    {
                        Logger.Log(TraceLevel.Verbose, "$$$$ Killing process {0} : {1}", myProcessList[i], myProcessList[i].Id);
                        myProcessList[i].Kill();

                        myProcessList[i].WaitForExit(5000);
                        myProcessList[i].Dispose();
                        myProcessList.RemoveAt(i);
                        break;
                    }
                }
            }
            // Fix for killing process. Above logic need to be re-looked for killing process
            List<Process> processCollection = Process.GetProcessesByName(processName).ToList();
            if(processCollection.Count() > 0)
            {
                processCollection.ForEach(element => element.Kill());
            }
        }
        catch (Exception ex)
        {
            Logger.Log(TraceLevel.Error, "Failed to stop the Process {0}", ex.Message);
            return false;
        }
        return true;
    }

    static public bool KillPreexistingApolloSimulator()
    {
        try
        {
            for (int maxRetryToKill = 1; maxRetryToKill <= 3; maxRetryToKill++)
            {
                Process[] processes = Process.GetProcessesByName(ApolloSimulatorApplicationName);
                if (processes.Length == 0) break;
                Logger.Log(TraceLevel.Verbose, "Kill attempt : {0}", maxRetryToKill);
                foreach (Process process in processes)
                {
                    Logger.Log(TraceLevel.Verbose, "#### Killing process {0} : {1}", process, process.Id);
                    process.Kill();
                    process.WaitForExit(5000);
                }
            }
            return true;
        }
        catch (Exception ex)
        {
            Logger.Log(ex);
        }
        return false;
    }

    public bool StartApolloWithNotRespondingTcp()
    {
        return StartApolloSimulator(DefaultTcpPort, ApolloNonRespondingScenarioNo);
    }

    public bool StartApolloToSendInvalidLengthOfDataPacket()
    {
        return StartApolloSimulator(DefaultTcpPort, ApolloToSendInvalidLengthOfDataPacket);
    }

    public bool StartApolloToSendNoDataPacketAfter20Sec()
    {
        return StartApolloSimulator(DefaultTcpPort, ApolloToSendNoDataPacketAfter20Sec);
    }

    public bool StartApolloWithNotRespondingToHelloCmd()
    {
        //TODO: Need to replace with correct error code
        //Will be taken up in User Story AT 482: Enabler : SenLink Command time out handling
        return StartApolloSimulator(DefaultTcpPort, ApolloNonRespondingScenarioNo);
    }

    public bool StartApolloWithArguments(string args)
    {
        return StartApolloSimulator(DefaultTcpPort, args);
    }

    public bool StartApolloSimulatorWithApolloRawFile(string rawFile)
    {
        string location = "";
        if (!string.IsNullOrEmpty(rawFile))
            location = @" -r " + rawFile;
        return StartApolloSimulator(DefaultTcpPort, location);
    }

    public bool StartApolloSimulatorWithApolloCsvFile(string csvFile)
    {
        string location = "";
        if (!string.IsNullOrEmpty(csvFile))
            location = @" -C " + csvFile;
        return StartApolloSimulator(DefaultTcpPort, location);
    }

    private string GetApolloLogFilePath()
    {
        string logDirectory = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, @"..\..\..\")) + $"{LogFolderName}\\";
        if (!Directory.Exists(logDirectory))
            Directory.CreateDirectory(logDirectory);
        return $"{logDirectory}ApolloSimulator_{myCurrentTestCaseId}_{DateTime.UtcNow.ToString("yyyyMMddHHmmss")}.log";
    }

    public bool StartApolloSimulator(int port = DefaultTcpPort, string args = "")
    {
        try
        {
            Process processToBeBooted = new Process
            {
                StartInfo =
                {
                    WindowStyle = ProcessWindowStyle.Normal,
                    FileName = ApolloSimulatorApplicationName,
                    Arguments = @" -t " + port.ToString() + @" -v -v -l " + $"{GetApolloLogFilePath()}" + " " + args,
                },
            };

            if (processToBeBooted.Start())
            {
                myProcessList.Add(processToBeBooted);
                Logger.Log(TraceLevel.Verbose, "Process Name: {0} : ID {1}  started with port:{2} args \"{3}\"", processToBeBooted.StartInfo.FileName, processToBeBooted.Id, port, args);
            }
            else
            {
                Logger.Log(TraceLevel.Verbose, "Process Name: {0} failed to start.", processToBeBooted.StartInfo.FileName);
                return false;
            }
        }
        catch (Exception ex)
        {
            Logger.Log(ex);
            return false;
        }
        return true;
    }

    public bool DeleteConfigFiles()
    {
        string filesToDelete = @"*config_*.json";
        string[] fileList = Directory.GetFiles(System.Environment.CurrentDirectory, filesToDelete);
        foreach (string file in fileList)
        {
            File.Delete(file);
        }
        return true;
    }

    public bool StopApolloSimulator()
    {
        return StopApplicationInProcessList(ApolloSimulatorApplicationName);
    }
}
