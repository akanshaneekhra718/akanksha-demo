//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>

namespace Titan.Common.Test;

public enum ApplicationName
{
    WorkflowController = 1
}

public static class StartStopTitanProcesses
{
    public static bool StartProcess()
    {
        bool isApplicationStarted;
        try
        {
            Process processToBeBooted = new Process { StartInfo = { FileName = ApplicationName.WorkflowController.ToString(), Arguments = null } };
            processToBeBooted.StartInfo.RedirectStandardOutput = true;
            processToBeBooted.StartInfo.RedirectStandardError = true;
            if (processToBeBooted.Start())
            {
                processToBeBooted.StandardOutput.ReadLine();
                Logger.Log(TraceLevel.Verbose, "Process Name: {0} : ID {1} started ", processToBeBooted.StartInfo.FileName, processToBeBooted.Id);
                isApplicationStarted = IsProcessRunning();
            }
            else
            {
                Logger.Log(TraceLevel.Verbose, "Process Name: {0} failed to start.", processToBeBooted.StartInfo.FileName);
                isApplicationStarted = false;
            }
        }
        catch (Exception exception)
        {
            Logger.Log(TraceLevel.Error, exception.Message);
            isApplicationStarted = false;
        }
        return isApplicationStarted;
    }

    public static void StopProcess()
    {
        try
        {
            Process[] processlist = Process.GetProcesses();
            foreach (Process process in processlist)
            {
                if (process.ProcessName.Contains(ApplicationName.WorkflowController.ToString()))
                {
                    process.Kill();
                    process.Dispose();
                }
            }
        }
        catch (Exception exception)
        {
            Logger.Log(TraceLevel.Error, exception.Message);
        }
    }

    public static bool IsProcessRunning()
    {
        bool isRunning = false;
        try
        {
            Process[] processlist = Process.GetProcessesByName(ApplicationName.WorkflowController.ToString());
            if (processlist.Length != 0)
                isRunning = true;
        }
        catch (Exception exception)
        {
            Logger.Log(TraceLevel.Error, exception.Message);
        }

        return isRunning;
    }
}
