//  <copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>

namespace Titan.Common.Test;

public sealed class TitanHomePage
{
    public IWebDriver WebDriver { get; }
    public IWebElement TitleHomePage => GetWebElementRetryIfNotFound("sh-access-bar", TagName);
    public IWebElement ModalDialog => GetWebElementRetryIfNotFound("critical-messages", Id);
    public IWebElement StaticPage => GetWebElementRetryIfNotFound("apolloStatus", Id);
    public IWebElement SplashScreenPage => GetWebElementRetryIfNotFound("sh-splash-screen", TagName);
    public IWebElement IconImage => GetWebElementRetryIfNotFound("/html/head/link[@rel='icon' and @type='image/x-icon']", XPath);
    public IWebElement HrValue => GetWebElementRetryIfNotFound("titanValueBox.hrValue.id", Id);
    public IWebElement HrLabel => GetWebElementRetryIfNotFound("titanValueBox.hrLabel.id", Id);
    public IWebElement ElectrodeText => GetWebElementRetryIfNotFound("electrodeText", Id);
    public IWebElement ElectrodeWarningIcon => GetWebElementRetryIfNotFound("messageLine.icon.id", Id);
    public IWebElement SweepSpeedLabel => GetWebElementRetryIfNotFound("waveform-overlay-sweepSpeed", Id);
    public IWebElement Sensitivity => GetWebElementRetryIfNotFound("waveform-overlay-sensitivity", Id);
    public IWebElement SpO2Label => GetWebElementRetryIfNotFound("titanValueBox.spo2Label.id", Id);
    public IWebElement SpO2Value =>  GetWebElementRetryIfNotFound("titanValueBox.spo2Value.id", Id);
    public IWebElement HRUnit => GetWebElementRetryIfNotFound("titanValueBox.hrUnit.id", Id); 
    public IWebElement SPO2Unit => GetWebElementRetryIfNotFound("titanValueBox.spo2Unit.id", Id);
    public IWebElement ElectrodeTextOnLeadI => GetWebElementRetryIfNotFound("waveform.electrode.status.id.1", Id);
    public IWebElement ElectrodeTextOnLeadII => GetWebElementRetryIfNotFound("waveform.electrode.status.id.2", Id);
    public IWebElement ElectrodeTextOnLeadIII => GetWebElementRetryIfNotFound("waveform.electrode.status.id.3", Id);
    public By CouldNotConnectToApolloMsg => By.Id("apolloStatus");
    public By SettingsIcon => By.Id("settingIcon");
    public By HrValueLocator => By.Id("titanValueBox.hrValue.id");

    public By titanDisconnectedLabel = By.XPath(@"//sh-empty-state[@id='apolloStatus' and @label=""We Couldn't Connect To Titan""]");
    public By apolloDisconnectedLabel = By.XPath(@"//sh-empty-state[@id='apolloStatus' and @label=""We Couldn't Connect To Apollo""]");
    public IWebElement Spo2StatusIcon => GetWebElementRetryIfNotFound("messageCenter.spo2Status.icon.id", Id);
    public IWebElement Spo2StatusText => GetWebElementRetryIfNotFound("spo2StatusText", Id);
    public IReadOnlyCollection<IWebElement> WaveformLabels => GetWebElementsRetryIfNotFoundForXPath(".//sh-text[starts-with(@id,'waveform.text.label.id.')]");
    public IReadOnlyCollection<IWebElement> GainIndicatorText => GetWebElementsRetryIfNotFoundForXPath(".//sh-text[starts-with(@id,'waveform.text.gain.indicator.text.id.')]");
    public IReadOnlyCollection<IWebElement> GainIndicatorIcons => GetWebElementsRetryIfNotFoundForXPath(".//*[starts-with(@id, 'waveform.text.gain.indicator.id.')]");
    public IWebElement ConfigurationSettingsIcon => GetWebElementRetryIfNotFound("settingIcon", Id);
    private const string TagName = "TagName";
    private const string Id = "Id";
    private const string XPath = "XPath";
    public By UserIdentifierLabel => By.Id("userIdentifierLabel");
    public TitanHomePage(IWebDriver webDriver)
    {
        WebDriver = webDriver;
    }

    public bool LaunchBrowserNavigateToTitanURL()
    {
        bool isTitanUiLaunched = false;
        try
        {
            Logger.Log(TraceLevel.Verbose, "Precondition: Launching Titan UI");
            WebDriver.Manage().Window.Maximize();
            string pageAddress = Environment.GetEnvironmentVariable("TITAN_WEBPAGE_ADDRESS") ?? TitanUITestModuleConstant.HostName;
            string pageLink = "http://" + pageAddress + ":" + TitanUITestModuleConstant.TitanPort.ToString();
            WebDriver.Navigate().GoToUrl(pageLink);
            Logger.Log(TraceLevel.Verbose, "Titan UI launched successfully");
            isTitanUiLaunched = true;
        }
        catch (WebDriverException ex)
        {
            Logger.Log(TraceLevel.Error, "WebPage is not available (Most probably TitanUI is down) : " + ex.Message);
        }
        catch (Exception ex)
        {
            Logger.Log(TraceLevel.Error, "When: Error in Launching Titan URL:: " + ex.Message);
        }
        return isTitanUiLaunched;
    }

    /*
    Stale element exception occurs if the element which we referred is removed from the DOM structure
    fix is to retry it, below code try three time for that element. 
    */
    private IWebElement GetWebElementRetryIfNotFound(string propertyName, string propertyType)
    {
        Func<string, By> function = null;
        switch (propertyType)
        {
            case TagName:
                function = By.TagName;
                break;
            case Id:
                function = By.Id;
                break;
            case XPath:
                function = By.XPath;
                break;
            default:
                throw new NotImplementedException();
        }

        // Using for loop, it tries for 30 times.
        for (int i = 0; i < 30; i++)
        {
            try
            {
                return new WebDriverWait(WebDriver, TimeSpan.FromSeconds(1))
                           .Until(myWebDriver => myWebDriver.FindElement(function(propertyName)));
            }
            catch (Exception ex)
            {
                Logger.Log(TraceLevel.Warning, $"{i} retry for finding element :" + ex.Message);
                Thread.Sleep(100);
            }
        }
        return WebDriver.FindElement(function(propertyName));
    }

    private IReadOnlyCollection<IWebElement> GetWebElementsRetryIfNotFoundForXPath(string propertyName)
    {
        // Using for loop, it tries for 5 times.
        for (int i = 0; i <= 4; i++)
        {
            try
            {
                return new WebDriverWait(WebDriver, TimeSpan.FromSeconds(15))
                           .Until(myWebDriver => myWebDriver.FindElements(By.XPath(propertyName)));
            }
            catch (Exception ex)
            {
                Logger.Log(TraceLevel.Warning, $"{i} retry for finding element :" + ex.Message);
                Thread.Sleep(10);
            }
        }
        return WebDriver.FindElements(By.XPath(propertyName));
    }

    public bool CleanUp()
    {
        try
        {
            WebDriver.Close();
            WebDriver.Quit();
        }
        catch (Exception ex)
        {
            Logger.Log(ex);
            return false;
        }
        return true;
    }
}
