//  <copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>

namespace Titan.Common.Test;
public class CommonUITestDataContract
{
    private readonly IWebDriver myWebDriver;
    private const int maxTry=5;
    public CommonUITestDataContract(IWebDriver webDriver)
    {
        myWebDriver = webDriver;
    }
    /// <summary>
    /// Function check whether locator is present in web page
    /// </summary>
    /// <param name="Locator">Takes By parameter</param>
    /// <returns>Gives Boolean</returns>
    public bool IsElementPresent(By locator)
    {
        bool isPresent = false;
        try
        {
            isPresent = myWebDriver.FindElements(locator).Any();
        }
        catch (Exception exception)
        {
            Logger.Log(exception);
        }
        return isPresent;
    }

    /// <summary>
    /// Function check and returns web element 
    /// </summary>
    /// <param name="Locator">Takes By parameter</param>
    /// <returns>Gives IWebelement</returns>

    public IWebElement GetElement(By locator)
    {
        ExplicitWait(locator, 5);
        if (IsElementPresent(locator))
        {
            return myWebDriver.FindElement(locator);
        }
        else
        {
            throw new NoSuchElementException("Locator not found::" + locator.ToString());
        }
    }

    /// <summary>
    /// Function Clicks on the passed Webelement
    /// </summary>
    /// <param name="Locator">Takes By parameter</param>
    public void Click(By locator)
    {
        for(int i=0;i<=maxTry;i++)
        {
            try
            {
                ExplicitWait(locator,6);
                IWebElement webElement = GetElement(locator);
                webElement.Click();
                Logger.Log(TraceLevel.Warning, $"{locator} clicked after {i} iterartion max try 5 and interval 1 sec");
                break;
            }
            catch(Exception ex)
            {
                Thread.Sleep(TimeSpan.FromSeconds(1));
                if(i==maxTry)
                {
                    throw new Exception($"{ex.Message} locater is unclickable after {i} seconds");
                }
            }
        }
       
    }

    /// <summary>
    /// Function performs explicit wait for passed locator to be visible
    /// </summary>
    /// <param name="Locator">Takes By parameter</param>  
    /// <param name="time">Takes integer parameter time in seconds</param> 
    public void ExplicitWait(By locator, int time)
    {
        for (int retryCount = 0; retryCount < maxTry; retryCount++)
        {
            try
            {
                WebDriverWait wait = new WebDriverWait(myWebDriver, TimeSpan.FromSeconds(time));
                Func<IWebDriver, bool> isLocatorDisplayed =
                myWebDriver =>
                {
                    IWebElement element = myWebDriver.FindElement(locator);
                    return element.Displayed;
                };

                wait.Until(isLocatorDisplayed);
            }
            catch (StaleElementReferenceException exception)
            {
                Logger.Log(TraceLevel.Error, $"Stale Element exception caught : {exception.Message}");
                myWebDriver.Navigate().Refresh();
            }
            catch (Exception exception)
            {
                Logger.Log(TraceLevel.Error, $"{exception.Message}");
            }
        }
    }

    /// <summary>
    /// Function check whether WebElement is displayed
    /// </summary>
    /// <param name="Locator">Takes By parameter</param>
    /// <returns>Gives Boolean</returns>
    public bool IsElementDisplayed(By locator)
    {
        bool isDisplayed = false;
        try
        {
            ExplicitWait(locator, 10);
            IWebElement webElement = myWebDriver.FindElement(locator);
            isDisplayed= webElement.Displayed;
            Logger.Log(TraceLevel.Verbose, $"Is Element diplayed : " + isDisplayed);
        }
        catch(Exception ex)
        {
            Logger.Log(TraceLevel.Error,$"Element not located or diplayed {ex.ToString()}");
        }
        return isDisplayed;
    }

    public bool IsElementSelected(By locator)
    {
        ExplicitWait(locator, 10);
        IWebElement webElement = myWebDriver.FindElement(locator);
        return webElement.Enabled;
    }

    /// <summary>
    /// Function enters Text into textbox
    /// </summary>
    /// <param name="Locator">Takes By parameter</param>
    /// <param name="Text">Takes string</param>
    public void EnterTextInTextBox(By locator, string text)
    {
        ExplicitWait(locator, 3);
        IWebElement webElement = GetElement(locator);
        webElement.SendKeys(text);
    }

    /// <summary>
    /// Function clears textbox
    /// </summary>
    /// <param name="Locator">Takes By parameter</param>
    public void ClearTextBox(By locator)
    {
        ExplicitWait(locator, 2);
        Actions actions = new Actions(myWebDriver);
        IWebElement webElement = GetElement(locator);
        actions.DoubleClick(webElement).SendKeys(Keys.Delete).Build().Perform();
    }
    /// <summary>
    /// Function clears textbox
    /// </summary>
    /// <param name="Locator">Takes By parameter</param>
    public void SelectAndClearTextBox(By locator)
    {
        ExplicitWait(locator,2);
        for(int i=0;i< maxTry; i++)
        {
           IWebElement webElement = GetElement(locator);
           webElement.SendKeys(Keys.Control + "A" + Keys.Delete);
           if (string.IsNullOrEmpty(GetAttributeValue(locator,"value")))
           {
                Logger.Log(TraceLevel.Warning, $"{locator} value cleared in {i} attempt each try 200 ms");
                break;
           }
           else
           {
               if((locator.ToString()).Contains("inputTextHostname"))
               {
                    ExecuteJavaScript(ConfigurationPage.ClearHostnameTextBoxScript);
               }
               else if((locator.ToString()).Contains("inputTextTcpPort"))
               {
                    ExecuteJavaScript(ConfigurationPage.ClearTcpTextBoxScript);
               }
               else
               {
                    ExecuteJavaScript(ConfigurationPage.ClearUdpTextBoxScript);
               }
           }
           Thread.Sleep(TimeSpan.FromMilliseconds(200));
        }
        
    }

    /// <summary>
    /// Function performs Javascript operation
    /// </summary>
    /// <param name="Script">Takes string javascript</param>
    /// <returns>Gives true if script executed else returns false</returns>
    public bool ExecuteJavaScript(string script)
    {
        bool isExecuted = false;
        try
        {
            IJavaScriptExecutor loadExecuter = ((IJavaScriptExecutor)myWebDriver);
            loadExecuter.ExecuteScript(script);
            isExecuted = true;
        }
        catch (Exception exception)
        {
            Logger.Log(exception);
        }
        return isExecuted;
    }

    /// <summary>
    /// Variation of Function GetText value from HTML elements attribute
    /// </summary>
    /// <param name="Locator">Takes By parameter</param>
    /// <param name="attribute">Takes string parameter</param>
    /// <returns>string </returns>
    public string GetAttributeValue(By locator, string attribute)
    {
        string getText = string.Empty;
        try
        {
            ExplicitWait(locator, 10);
            IWebElement webElement = GetElement(locator);
            getText = webElement.GetAttribute(attribute);
            Logger.Log(TraceLevel.Info, "{locator} value is : " + getText);
        }
        catch (Exception exception)
        {
            Logger.Log(exception);
        }
        return getText;
    }

    public void MouseHover(By locator)
    {
        IWebElement element;
        try
        {
            element = myWebDriver.FindElement(locator);
            Actions action = new Actions(myWebDriver);
            action.MoveToElement(element).Build().Perform();
        }
        catch(Exception exception)
        {
            Logger.Log(exception);
        }
    }

    public Dictionary<string, string> GetTextOfWebElements(By labelLocator, By valueLocator)
    {
        Dictionary<string, string> labelValueOfWebElements = new();
        int maxAttemptCount = 10;
        for (int attempted = 0; attempted < maxAttemptCount; attempted++)
        {
            if (myWebDriver.FindElements(valueLocator)?.Count > 0)
            {
                List<string> labelElementsList = (myWebDriver.FindElements(labelLocator)).Select(element => element.Text).ToList();
                List<string> valueElementsList = (myWebDriver.FindElements(valueLocator)).Select(element => element.Text).ToList();
                labelValueOfWebElements = labelElementsList.ToDictionary(x => x, x => valueElementsList[labelElementsList.IndexOf(x)]);
                break;
            }
            else
            {
                Thread.Sleep(1000);
            }
        }
        return labelValueOfWebElements;
    }
}
