﻿//  <copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>

namespace Titan.Common.TitanStatusCode;

/// <summary>
/// Configuration related status codes ranging from 1000-1999
/// </summary>
public enum ConfigurationStatusCodes
{
    #region <TraceKey AT-TTN-1325 />
    // When Retrieve/Persist data API completes its job successfully. 
    Success = 1000,
    // When the volume is not mounted 
    DirectoryNotFound = 1001,
    // When file doesn't exist during displaying of network parameters
    FileNotFound = 1002,
    // When parameters are being deleted or file is corrupted during retrieve
    JsonOrFileIOFailure = 1003,
    // When there is any type of Socket Error thrown during TCP connection failure with Apollo
    SocketError = 1004,
    // When there is any error while validating the json file against its schema
    SchemaMismatch = 1005,
    // When the json file is readonly
    FileReadOnly = 1006,
    //When Directory ReadOnly
    DirectoryReadOnly = 1007,
    //When Host already exist
    HostAlreadyExist = 1008
    #endregion
}
