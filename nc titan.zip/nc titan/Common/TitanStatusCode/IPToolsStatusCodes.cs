﻿//  < copyright > Restricted Copyright(c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>

namespace Titan.Common.TitanStatusCode;

/// <summary>
/// IPTools related status codes ranging from 1100-1199
/// </summary>
public enum IPToolsStatusCodes
{
    #region <TraceKey AT-TTN-2018 />
    MultipleIPsAssociated = 1101,
    InvalidIPv4Format = 1102
    #endregion
}
