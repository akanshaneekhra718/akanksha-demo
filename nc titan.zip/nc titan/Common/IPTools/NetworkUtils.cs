﻿//  < copyright > Restricted Copyright(c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>

namespace Titan.Common.IPTools;

public class NetworkUtils : INetworkUtils
{
    private IPToolsStatusCodes iPToolsStatusCode;
    private const string socketError = "An error occurred while procssing your request";

    #region <TraceKey AT-TTN-2018 />
    private IPToolsStatusCodes PingHostOrAddress(IPAddress iPAddress)
    {
        try
        {
            using (Ping ping = new Ping())
            {
                PingReply reply = ping.Send(iPAddress);
                switch (reply.Status)
                {
                    case IPStatus.Success:
                        iPToolsStatusCode = (IPToolsStatusCodes)IPStatus.Success;
                        break;

                    case IPStatus.TimedOut:
                        iPToolsStatusCode = (IPToolsStatusCodes)IPStatus.TimedOut;
                        break;

                    case IPStatus.DestinationHostUnreachable:
                        iPToolsStatusCode = (IPToolsStatusCodes)IPStatus.DestinationHostUnreachable;
                        break;
                }
            }
        }
        catch (PingException ex)
        {
            Logger.Log(TraceLevel.Error, $"{socketError} {ex.Message}");
            throw;
        }

        return iPToolsStatusCode;
    }

    public IPToolsStatusCodes ValidateHostOrAddress(string hostOrAddress)
    {
        IPAddress[] iPAddresses;

        try
        {
            iPAddresses = Dns.GetHostAddresses(hostOrAddress);
            if (iPAddresses.Length > 1)
            {
                iPToolsStatusCode = IPToolsStatusCodes.MultipleIPsAssociated;
            }
            else if (iPAddresses[0].AddressFamily == AddressFamily.InterNetwork)
            {
                iPToolsStatusCode = PingHostOrAddress(iPAddresses[0]);
            }
            else
            {
                iPToolsStatusCode = IPToolsStatusCodes.InvalidIPv4Format;
            }
        }
        catch (SocketException socketError)
        {
            if (socketError.SocketErrorCode == SocketError.HostNotFound)
            {
                iPToolsStatusCode = (IPToolsStatusCodes)SocketError.HostNotFound;
            }
            else
            {
                Logger.Log(TraceLevel.Error, $"{socketError} {socketError.Message}");
                throw;
            }
        }
        return iPToolsStatusCode;
    }
    #endregion
}