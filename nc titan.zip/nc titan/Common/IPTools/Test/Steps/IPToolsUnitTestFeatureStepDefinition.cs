﻿//  < copyright > Restricted Copyright(c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>

namespace Titan.Common.IPTools.IPToolsUnitTest;

[Binding]
public class IPToolsStepDefinitions
{
    private NetworkUtils myNetworkUtils;
    private readonly Mock<INetworkUtils> myNetworkUtilsMock;
    private IPToolsStatusCodes iPToolsStatusCode;
    private Boolean myResult=false;

    public IPToolsStepDefinitions()
    {
        myNetworkUtilsMock = new Mock<INetworkUtils>();
    }

    [Given(@"NetworkUtils is initialised")]
    public void GivenNetworkUtilsIsInitialised()
    {
        myNetworkUtils = new NetworkUtils();
    }

    [When(@"ValidateHostOrAddress is called with ""([^""]*)"" as a parameter that returns statuscode")]
    public void WhenValidateHostOrAddressIsCalledWithHostnameOrAddressAsAParameterThatReturnsStatuscode(string hostnameorIP)
    {
        try
        {
            iPToolsStatusCode = myNetworkUtils.ValidateHostOrAddress(hostnameorIP);            
        }
        catch (Exception ex)
        {
            Logger.Log(TraceLevel.Error, ex.Message);
        }
    }
    
    [Then(@"Verify (.*) is sent")]
    public void ThenVerifyStatuscodeIsSent(int statuscode)
    {
        Assert.AreEqual(statuscode, (int)iPToolsStatusCode);        
    }

    [When(@"ValidateHostOrAddress is called with ""([^""]*)"" as a parameter")]
    public void WhenValidateHostOrAddressIsCalledWithHostnameOrAddressAsAParameter(string hostnameorIP) 
    {
        try
        {
            myNetworkUtils.ValidateHostOrAddress(hostnameorIP);
            myResult = true;
        }
        catch (Exception ex)
        {
            Logger.Log(TraceLevel.Error, ex.Message);
            myResult = false;
        }
    }
    
    [Then(@"Verify no exception is thrown")]
    public void ThenVerifyNoExceptionIsThrown() 
    {
        Assert.IsTrue(myResult);
    }

    [Then(@"Verify ping exception is thrown")]
    public void VerifyPingExceptionIsThrown()
    {
        Assert.IsFalse(myResult);
    }
}