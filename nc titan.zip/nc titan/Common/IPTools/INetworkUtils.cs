﻿//  < copyright > Restricted Copyright(c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace Titan.Common.IPTools;

public interface INetworkUtils
{
    #region <TraceKey AT-TTN-2018 />
    public IPToolsStatusCodes ValidateHostOrAddress(string hostOrAddress);
    #endregion
}
