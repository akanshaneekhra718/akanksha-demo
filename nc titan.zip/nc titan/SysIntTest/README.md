# Introduction
Test code is generated using .Net BDD framework called "SpecFlow". It is an open-source project, and an official .Net version of cucumber.
Acceptance test scenarios are defined in feautre files provided by framework, and subsequent steps are generated in StepDefinition files.
During execution scenarios are executed using the provided steps (step definitions). Execution is done with a help of test execution frameworks, like MsTest
		
# Installation
Extension required to be installed -> Cucumber (Gherkin) Full Support by Alexander Krechik.

Open git bash or command prompt.

Install below packages for MSTest framework and for web automation
	dotnet add package MSTest.TestFramework --version 2.2.8
	dotnet add package Microsoft.Build --version 17.0.0
	dotnet add package Selenium.WebDriver --version 4.1.0
	dotnet add package Selenium.Support --version 4.1.0
	dotnet add package Selenium.WebDriver.ChromeDriver --version 97.0.4692.7100
	dotnet add package SpecFlow.MsTest --version 3.9.40
	dotnet add package MSTest.TestAdapter --version 2.2.8
	dotnet add package FluentAssertions --version 6.3.0

# Creating Step definitions
Update feature file with test scenarios/steps. 
Run test with logger as trx (trx logs will show step definitionas missing for feature steps)
	dotnet test --logger trx
Copy the step definition from trx log, use them in step definition file (Modify them as per need).
Alternatevely, edit the Step Definition file and include missing steps directly

# Hooks
Update StepDefinition.cs file for any Before or After event handling conditions, it can be applied on:
	Test		[Before/After Test]
	Feature		[Before/After Feature]
	Scenario	[Before/After Scenario]
	Step		[Before/After Step]
For multiple event handling, define order in which they need to be executed.
	[BeforeScenario(Order = 1)]
For scoped event handling, use tags to differentiate with global event handling.
	[AfterScenario(Order = 1)]
	[Scope(Tag = "hooksExample")]

# Configuring the Feature file to Steps Definition Navigation:
Open the settings screen "File -> Preferences -> Settings"
Open Extensions -> Cucumber Autocomplete and scroll to 'Steps' option.
Click on the “Edit in settings.json” link associated with this.
Update json file with below settings and exit.
	"cucumberautocomplete.steps": ["./**/*.cs"],
	"cucumberautocomplete.syncfeatures": "./**/*.feature"
