﻿namespace TitanTest.NlsTest.TestModule
{
    public sealed class TrustedDeviceModule
    {

        public List<TrustedDeviceParammeter> TrustedDeviceList { get; private set; }
        public string DateCaptured { get; private set; }

        private static readonly object lockObj = new object();
        private static TrustedDeviceModule myInstance = null;
        private Xpta.Sita.TestSteps.ILogger myLogger;
        public static TrustedDeviceModule Instance
        {
            get
            {
                lock (lockObj)
                {
                    if (myInstance == null)
                    {
                        myInstance = new TrustedDeviceModule();
                    }
                    return myInstance;
                }
            }
        }

        private TrustedDeviceModule()
        {
            TrustedDeviceList = new List<TrustedDeviceParammeter>();
        }

        public void SetCapturedDate()
        {
            DateCaptured = DateTime.Now.ToString("dd/MM/yyyy");
        }

        public void UpdateTrustedDevice()
        {

            ICollection<IControl> deviceCollection;
            try
            {
                deviceCollection = ConfigurationPage.TrustedDeviceTable.Children;
            }
            catch (Exception ex)
            {
                myLogger?.WriteError($"Unble to generate Trusted Device List :{ex.Message}");
                return;
            }

            TrustedDeviceList = CreateTrustedDeviceList(deviceCollection);
            myLogger?.WriteInfo("Trusted Device List is updated");
        }

        private List<TrustedDeviceParammeter> CreateTrustedDeviceList(ICollection<IControl> controlCollection)
        {
            List<TrustedDeviceParammeter> deviceList = new List<TrustedDeviceParammeter>();


            for (int count = 2; count < controlCollection.Count; count++)
            {
                ICollection<IControl> tableRow = controlCollection.ElementAt(count).ToChromeControl().Children;
                TrustedDeviceParammeter trustedDeviceParammeter = new TrustedDeviceParammeter();
                trustedDeviceParammeter.Name = tableRow.ElementAt(1).ToChromeControl().InnerText.Trim();
                trustedDeviceParammeter.LastActive = tableRow.ElementAt(2).ToChromeControl().InnerText.Trim();
                deviceList.Add(trustedDeviceParammeter);
            }
            return deviceList;
        }

        public bool CompareTructedDevice(TrustedDeviceParammeter trustedDeviceParammeter1, TrustedDeviceParammeter trustedDeviceParammeter2)
        {
            return trustedDeviceParammeter1.Name.Equals(trustedDeviceParammeter2.Name)
                && trustedDeviceParammeter1.LastActive.Equals(trustedDeviceParammeter2.LastActive);
        }

        public void InjectLogger(Xpta.Sita.TestSteps.ILogger logger)
        {
            myLogger = logger;
        }
    }

    public class TrustedDeviceParammeter
    {
        public string Name { get; set; }
        public string LastActive { get; set; }
    }


}
