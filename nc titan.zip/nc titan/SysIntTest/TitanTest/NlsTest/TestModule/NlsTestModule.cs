﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.NlsTest.TestModule
{

    public sealed class NlsTestModule
    {
        
        private static readonly object lockObj = new object();
        private static NlsTestModule myInstance = null;
        private Xpta.Sita.TestSteps.ILogger myLogger;
        public void InjectLogger(Xpta.Sita.TestSteps.ILogger logger)
        {
            myLogger = logger;
        }
        public static NlsTestModule Instance
        {
            get
            {
                lock (lockObj)
                {
                    if (myInstance == null)
                    {
                        myInstance = new NlsTestModule();
                    }
                    return myInstance;
                }
            }
        }

        public void LanguageSelection(string languageType)
        {
            Thread.Sleep(3000);
            TitanHomePage.UserIdentifierLabel.WaitUntilVisible(50);
            Assert.IsFalse(UserIdentifierOption.UserIdentifierMenu.Visible);
            TitanHomePage.UserIdentifierLabel.MouseClick();
            UserIdentifierOption.LanguageLabel.MouseMove();
            SelectLanguage(languageType);
        }
        public void SelectLanguage(string Language)
        {
            UserIdentifierOption.EnglishLanguageLabel.WaitUntilVisible(10);
            UserIdentifierOption.EnglishLanguageLabel.MouseMove();
            switch (Language)
            {
                case "English":
                    ClickLanguageMenuItem(UserIdentifierOption.EnglishLanguageLabel);
                    break;
                case "Deutsch":
                    ClickLanguageMenuItem(UserIdentifierOption.GermanLanguageLabel);
                    break;
                case "Svenska":
                    ClickLanguageMenuItem(UserIdentifierOption.SwedishLanguageLabel);
                    break;
            }
            TitanHomePage.UserIdentifierLabel.WaitUntilVisible(10);
        }

        private void ClickLanguageMenuItem(IChromeMenuItem chromeMenuItem)
        {
            chromeMenuItem.WaitUntilVisible(30);
            chromeMenuItem.MouseMove();           
            chromeMenuItem.SetFocus();
            chromeMenuItem.MouseClick();
        }

        public void VerifyLanguageMenuItem(IChromeMenuItem chromeMenuItem, string languageNotActive)
        {
            TitanHomePage.UserIdentifierLabel.WaitUntilVisible(5);
            TitanHomePage.UserIdentifierLabel.MouseClick();
            UserIdentifierOption.LanguageLabel.WaitUntilVisible(5);
            UserIdentifierOption.LanguageLabel.MouseMove();
            chromeMenuItem.WaitUntilVisible(5);
            Assert.IsTrue(chromeMenuItem.Attributes.ContainsKey("active"), languageNotActive);
        }

        public void VerifyLanguageLabel(string languageLabel, string expectedLabel)
        {
            TitanHomePage.UserIdentifierLabel.MouseClick();
            UserIdentifierOption.LanguageLabel.WaitUntilVisible(10);
            Assert.AreEqual(languageLabel, expectedLabel);
        }
    }
}