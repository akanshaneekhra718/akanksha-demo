﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.NlsTest.TestSteps
{
    public class SelectLanguageFromUserIdentifierOption : TestStep
    {

        [TestStepParameter(DisplayName = "Language")]
        public string Language { get; set; }
        [TestStepParameter(DisplayName = "System Type")]
        public string SystemRoomType { get; set; }

        public override string Description => "User clicks on the User Identifier option and Select Launguage";
        readonly TitanUITestController myController = TitanUITestController.Instance;
        readonly NlsTestModule myNlsTest = NlsTestModule.Instance;

        public override void Initialize()
        {
            CommonBase.RemoteAddress = myController.GetLocalAddress();
        }

        public override void Action()
        {
            if (String.IsNullOrEmpty(Language) || String.IsNullOrEmpty(SystemRoomType)){
                Log.WriteError("SystemRoomType :" + SystemRoomType);
                Log.WriteError("Language :" + Language);
                Assert.Fail("Test Parametrt Value not defined");
                return;
            }

            switch (SystemRoomType.ToLower())
            {
                case "exam":
                    CommonBase.RemoteAddress = myController.GetLocalAddress();
                    Log.WriteInfo("systemType: " + SystemRoomType);
                    Log.WriteInfo("Local IP add ::" + myController.GetLocalAddress());
                    myNlsTest.LanguageSelection(Language);
                    break;
                case "control":
                    Log.WriteInfo("systemType: " + SystemRoomType);
                    CommonBase.RemoteAddress = myController.GetRemoteAddress();
                    Log.WriteInfo("Remote IP add ::" + myController.GetRemoteAddress());
                    myNlsTest.LanguageSelection(Language);
                    break;
                default:
                    Assert.Fail("System Type is undefined : "+ SystemRoomType);
                    break;
            }
        }

    }
}
