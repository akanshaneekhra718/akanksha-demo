﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.NlsTest.TestSteps;
public class UserSelectLanguageFromLanguageMenu : TestStep
{
    [TestStepParameter(DisplayName = "Language")]
    public string Language { get; set; }
    public override string Description => "User selects Language from the language menu";

    readonly NlsTestModule myNlsTest = NlsTestModule.Instance;

    public override void Action()
    {
        if (String.IsNullOrEmpty(Language))
        {
            Assert.Fail("Language is unDefined");
            return;
        }

        myNlsTest.SelectLanguage(Language);
    }
}