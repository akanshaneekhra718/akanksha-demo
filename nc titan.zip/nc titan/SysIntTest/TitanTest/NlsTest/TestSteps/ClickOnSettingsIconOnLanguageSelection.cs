//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.NlsTest.TestSteps;

public class ClickOnSettingsIconOnLanguageSelection : TestStep
{
    [TestStepParameter(DisplayName = "Language")]
    public string Language { get; set; }
    public override string Description => "Click on settings icon";

    /// <inheritdoc />
    public override void Action()
    {
        if (String.IsNullOrEmpty(Language))
        {
            Assert.Fail("language is not defined");
            return;
        }

        TitanHomePage.SettingsIcon.WaitUntilVisible(10);
        TitanHomePage.SettingsIcon.WaitUntilEnabled(10);

        try
        {
            TitanHomePage.SettingsIcon.ExecuteScript<IButton>("document.getElementById(\"settingIcon\").click()");
        }
        catch (Exception ex)
        {
            Assert.Fail("Error while cliking on setting icon:" + ex.Message);
        }

        Log.WriteInfo(Language + "Is Selected");
        switch (Language)
        {
            case "English":
                ConfigurationPage.NetworkMenuItem.WaitUntilEnabled(10);
                Assert.IsTrue(ConfigurationPage.NetworkMenuItem.Enabled);
                break;
            case "Deutsch":
                ConfigurationPage.NetworkMenuItemDe.WaitUntilEnabled(10);
                Assert.IsTrue(ConfigurationPage.NetworkMenuItemDe.Enabled);
                break;
            case "Svenska":
                ConfigurationPage.NetworkMenuItemSv.WaitUntilEnabled(10);
                Assert.IsTrue(ConfigurationPage.NetworkMenuItemSv.Enabled);
                break;
            default:
                Assert.Fail("Language not defined:" + Language);
                break;
        }

    }
}
