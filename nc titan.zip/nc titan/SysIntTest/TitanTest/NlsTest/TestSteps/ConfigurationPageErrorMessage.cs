﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.NlsTest.TestSteps
{
    public class ConfigurationPageErrorMessage : TestStep
    {
        public override string Description => "Error (.*) is Displayed";
        [TestStepParameter(DisplayName = "TestErrorMessage")]
        public string TestErrorMessage { get; set; }

        public override void Action()
        {
            if (String.IsNullOrEmpty(TestErrorMessage))
            {
                Assert.Fail("Error Message Undefined");
                return;
            }

            ConfigurationPage.ErrorNotificationNetworkConfig.WaitUntilVisible(15);
            Assert.AreEqual(ConfigurationPage.ErrorNotificationNetworkConfig.GetAttribute("message"), TestErrorMessage);
        }
    }
}
