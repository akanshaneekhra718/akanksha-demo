﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.NlsTest.TestSteps
{
    public class NotificationMessageOnImpactedClient : TestStep
    {
        [TestStepParameter(DisplayName = "Network Error Model Dialogue")]
        public string NetworkErrorModalDialogLabel { get; set; }
        [TestStepParameter(DisplayName = "Icon Type")]
        public string IconType { get; set; }
        [TestStepParameter(DisplayName = "Network Error Modal Dialog Text")]
        public string ErrorText { get; set; }
        [TestStepParameter(DisplayName = "ImpactedSystem1")]
        public string ImpactedSystem1 { get; set; }
        [TestStepParameter(DisplayName = "ImpactedSystem2")]
        public string ImpactedSystem2 { get; set; }
        public override string Description => "Step to verify Network Error Model Dialogue";
        readonly TitanUITestController myController = TitanUITestController.Instance;
        public bool result1;
        public bool result2;
        public override void Initialize()
        {
            CommonBase.RemoteAddress = myController.GetLocalAddress();
        }

        /// <inheritdoc />
        public override void Action()
        {
            if (String.IsNullOrEmpty(NetworkErrorModalDialogLabel) || String.IsNullOrEmpty(IconType) || String.IsNullOrEmpty(ErrorText)
                || (String.IsNullOrEmpty(ImpactedSystem1) && String.IsNullOrEmpty(ImpactedSystem2)))
            {
                Log.WriteError("NetworkErrorModalDialog :" + NetworkErrorModalDialogLabel);
                Log.WriteError("IconType :" + IconType);
                Log.WriteError("NetworkErrorModalDialogText :" + ErrorText);
                Log.WriteError("ImpactedSystem1 :" + ImpactedSystem1);
                Log.WriteError("ImpactedSystem2 :" + ImpactedSystem2);
                Assert.Fail("Test parameter is not defined");
                return;
            }

            if (!String.IsNullOrEmpty(ImpactedSystem1))
            {
                if (!ImpactedSystem1.ToLower().Equals("exam"))
                {
                    Assert.Fail("Exam Room Variable is not Expected");
                    return;
                }
                CommonBase.RemoteAddress = myController.GetLocalAddress();
                Assert.IsTrue(verifyErrorDialoogueBox(NetworkErrorModalDialogLabel, IconType, ErrorText));
            }

            if (!String.IsNullOrEmpty(ImpactedSystem2))
            {
                if (!ImpactedSystem2.ToLower().Equals("control"))
                {
                    Assert.Fail("Exam Room Variable is not Expected");
                    return;
                }
                CommonBase.RemoteAddress = myController.GetRemoteAddress();
                Assert.IsTrue(verifyErrorDialoogueBox(NetworkErrorModalDialogLabel, IconType, ErrorText));
            }
        }

        private bool verifyErrorDialoogueBox(string NetworkDialogueLabel, string IType, string EText)
        {
            TitanHomePage.NetworkErrorModelDialogue.WaitUntilVisible(20);

            string ActDialogLabelText = TitanHomePage.NetworkErrorModelDialogue.GetAttribute("label");
            string ActIconType = TitanHomePage.NetworkErrorModelDialogue.GetAttribute("type");
            string ActNetworkErrorModalDialogText = TitanHomePage.NetworkErrorModelDialogue.ExecuteScript<string>("return document.querySelector('#critical-messages').innerHTML").Trim();

            if (ActDialogLabelText.Equals(NetworkDialogueLabel) && ActIconType.Equals(IType) && ActNetworkErrorModalDialogText.Equals(EText))
            {
                return true;
            }

            Log.WriteError("Expected Label :" + NetworkDialogueLabel);
            Log.WriteError("Actual Label   :" + ActDialogLabelText);
            Log.WriteError("Expected error :" + ActIconType);
            Log.WriteError("Actual error   :" + IType);
            Log.WriteError("Expected Msg   :" + EText);
            Log.WriteError("Actual Msg     :" + ActNetworkErrorModalDialogText);
            return false;
        }
    }
}
