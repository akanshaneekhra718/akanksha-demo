﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.NlsTest.TestSteps
{
    public class VerifyStaticTrustedDevicePage : TestStep
    {
        public override string Description => "Verify Trusted device list will be displayed with text No trusted devices.To trust this device add it to the list";

        public override void Action()
        {
            Assert.IsFalse(ConfigurationPage.TrustedDeviceTable.IsExisting, "Table device list is visible");
            Assert.AreEqual(ConfigurationPage.StaticTrustedDevicePage.GetAttribute("label"), "No trusted devices. To trust this device add it to the list.", "TrustedStatic Text string is not matching");

        }
    }
}
