//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.NlsTest.TestSteps;

public class VerifyTitanDisconnectMessage : TestStep
{
    [TestStepParameter(DisplayName = "Titan Disconnect Messages")]
    public string TitanDisconnectMessages { get; set; }
    public override string Description => "Verify Apollo Disconnect Msg";
   
    /// <inheritdoc />
    public override void Action()
    {
        if (String.IsNullOrEmpty(TitanDisconnectMessages))
        {
            Assert.Fail("Titan Disconnect Messages is empty or null");
            return;
        }

        TitanHomePage.StaticPage.WaitUntilVisible(10);
        Assert.AreEqual(TitanHomePage.StaticPage.Name, TitanDisconnectMessages);
    }
}