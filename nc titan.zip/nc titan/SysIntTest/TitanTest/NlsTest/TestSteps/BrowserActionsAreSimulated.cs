﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.NlsTest.TestSteps;
public class BrowserActionsAreSimulated : TestStep
{
    [TestStepParameter(DisplayName = "Language")]
    public string BrowserActions { get; set; }
    public override string Description => "Browser actions are simulated";

    public override void Action()
    {
        if (String.IsNullOrEmpty(BrowserActions))
        {
            Assert.Fail("Browser Actions are not defined");
            return;
        }

        switch (BrowserActions)
        {
            case "Browser is closed":
                try
                {
                    TitanHomePage.MainWindow.Close();
                    TitanHomePage.MainWindow.WaitUntilInvisible(1);
                }
                catch (Exception ex)
                {
                    Assert.Fail("Unable to close the Browser" + ex.Message);
                }
                break;
            case "Browser process is killed":
                Assert.IsTrue(ProcessController.KillProcess(ProcessController.ProcessType.chrome),"Unable to kill the browser process");
                Assert.IsFalse(ProcessController.CheckBrowserProcessAlive(ProcessController.ProcessType.chrome), "Browser process is sitll alive");
                break;
            default:
                Assert.Fail("Browser actions are not as expected :" + BrowserActions);
                break;
        }
    }
}
