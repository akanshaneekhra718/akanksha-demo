﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.NlsTest.TestSteps
{
    public class VerifyPreSelectedLanguageisDisplayedOnRoom : TestStep
    {
        [TestStepParameter(DisplayName = "Language")]
        public string Language { get; set; }
        public override string Description => "Selected Language is displayed as part of the User Menu Language Label";
        readonly NlsTestModule myNlsTest = NlsTestModule.Instance;
        public string NetworkErrorModalDialogText { get; set; }
        [TestStepParameter(DisplayName = "Client1")]
        public string ImpactedSystem1 { get; set; }
        [TestStepParameter(DisplayName = "Client2")]
        public string ImpactedSystem2 { get; set; }
        readonly TitanUITestController myController = TitanUITestController.Instance;
        public override void Initialize()
        {
            CommonBase.RemoteAddress = myController.GetLocalAddress();
        }

        /// <inheritdoc />
        public override void Action()
        {
            if (String.IsNullOrEmpty(Language) || (String.IsNullOrEmpty(ImpactedSystem1) && String.IsNullOrEmpty(ImpactedSystem2)))
            {
                Log.WriteError("NetworkErrorModalDialogText :" + NetworkErrorModalDialogText);
                Log.WriteError("ImpactedSystem1 :" + ImpactedSystem1);
                Log.WriteError("ImpactedSystem2 :" + ImpactedSystem2);
                Assert.Fail("Test parameter is not defined");
                return;
            }

            if (!String.IsNullOrEmpty(ImpactedSystem1))
            {
                if (!ImpactedSystem1.ToLower().Equals("exam"))
                {
                    Assert.Fail("Exam Room Variable is not Expected");
                    return;
                }
                CommonBase.RemoteAddress = myController.GetLocalAddress();
                VerifyLanguage(Language);
            }

            if (!String.IsNullOrEmpty(ImpactedSystem2))
            {
                if (!ImpactedSystem2.ToLower().Equals("control"))
                {
                    Assert.Fail("Control Room Variable is not Expected");
                    return;
                }
                CommonBase.RemoteAddress = myController.GetRemoteAddress();
                VerifyLanguage(Language);
            }
        }

        private void VerifyLanguage(string Language)
        {
            switch (Language)
            {
                case "English":
                    myNlsTest.VerifyLanguageLabel(UserIdentifierOption.LanguageLabel.Name, "Language (English)");
                    break;

                case "Deutsch":
                    myNlsTest.VerifyLanguageLabel(UserIdentifierOption.LanguageLabel.Name, "Sprache (Deutsch)");
                    break;

                case "Svenska":
                    myNlsTest.VerifyLanguageLabel(UserIdentifierOption.LanguageLabel.Name, "Språk (Svenska)");
                    break;
                default:
                    Assert.Fail("Language is not defined:" + Language);
                    break;
            }
        }
    }
}