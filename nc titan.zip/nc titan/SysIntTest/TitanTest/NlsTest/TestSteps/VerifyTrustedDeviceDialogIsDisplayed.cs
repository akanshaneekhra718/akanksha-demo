﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.NlsTest.TestSteps
{
    public class VerifyTrustedDeviceDialogIsDisplayed : TestStep
    {
        public override string Description => "Verify Trusted Device dialog is displayed";

        public override void Action()
        {
            Assert.IsTrue(ConfigurationPage.TrustedDeviceDialog.Visible); 
            Assert.Equals(ConfigurationPage.TrustedDeviceDialog.InnerText, "Trusted Devices");
            Assert.IsTrue(ConfigurationPage.TrustedAddButton.Visible);
        }
    }
}
