﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.NlsTest.TestSteps
{
    public class SpO2StatusMessageCheck : TestStep
    {
        [TestStepParameter(DisplayName = "Erroneous SpO2 Raw File")]
        public string Message { get; set; }
        public override string Description => "User get notified with Message on UI for Probe disconnected Status";

        /// <inheritdoc />
        public override void Action()
        {
            if (String.IsNullOrEmpty(Message))
            {
                Assert.Fail("Message is not defined");
                return;
            }

            TitanHomePage.SpO2StatusText.WaitUntilVisible(10, ExecutionContext.CancellationToken);
            Assert.AreEqual(TitanHomePage.SpO2StatusText.TextValue, Message);
        }
    }
}