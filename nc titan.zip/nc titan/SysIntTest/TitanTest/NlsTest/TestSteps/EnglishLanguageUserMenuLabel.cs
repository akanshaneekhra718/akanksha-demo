﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.NlsTest.TestSteps
{
    public class EnglishLanguageUserMenuLabel : TestStep
    {
        public override string Description => "English Language is displayed as part of the User Menu Language Label";

        public override void Action()
        {
            Assert.AreEqual(UserIdentifierOption.LanguageLabel.Name, "Language (English)");
        }
    }
}
