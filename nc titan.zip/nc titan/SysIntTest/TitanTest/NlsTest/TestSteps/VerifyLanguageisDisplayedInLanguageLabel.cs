﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.NlsTest.TestSteps
{
    public class VerifyLanguageisDisplayedInLanguageLabel : TestStep
    {
        [TestStepParameter(DisplayName = "Language")]
        public string Language { get; set; }
        public override string Description => "Selected Language is displayed as part of the User Menu Language Label";
        readonly NlsTestModule myNlsTest = NlsTestModule.Instance;
        public override void Action()
        {
            if (String.IsNullOrEmpty(Language))
            {
                Assert.Fail("Test Parameter Value Language is not defined");
                return;
            }

            switch (Language)
            {
                case "English":
                    myNlsTest.VerifyLanguageLabel(UserIdentifierOption.LanguageLabel.Name, "Language (English)");
                    break;

                case "Deutsch":
                    myNlsTest.VerifyLanguageLabel(UserIdentifierOption.LanguageLabel.Name, "Sprache (Deutsch)");
                    break;

                case "Svenska":
                    myNlsTest.VerifyLanguageLabel(UserIdentifierOption.LanguageLabel.Name, "Språk (Svenska)");
                    break;

                default:
                    Assert.Fail("Language is undefined :" + Language);
                    break;
            }
        }

    }
}