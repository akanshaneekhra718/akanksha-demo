﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.NlsTest.TestSteps
{
    public class AddTrustedHostDeviceNameInput : TestStep
    {
        [TestStepParameter(DisplayName = "Hostname")]
        public string Hostname { get; set; }
        public override string Description => "User enters device name under Add Device dialog";

        public override void Action()
        {
            if (String.IsNullOrEmpty(Hostname))
            {
                Assert.Fail("Hostname is empty");
                return;
            }
            ConfigurationPage.AddDeviceNameField.WaitUntilVisible(5);

            if (!String.IsNullOrEmpty(ConfigurationPage.AddDeviceNameField.Text))
            {
                ConfigurationPage.ClearDeviceNameField.MouseClick();
                Assert.IsTrue(String.IsNullOrEmpty(ConfigurationPage.AddDeviceNameField.Text),"Unable to clear Device Name input text field");
               
            }
            ConfigurationPage.AddDeviceNameField.Text = Hostname;
            Assert.AreEqual(Hostname, ConfigurationPage.AddDeviceNameField.Text);
        }
    }
}
