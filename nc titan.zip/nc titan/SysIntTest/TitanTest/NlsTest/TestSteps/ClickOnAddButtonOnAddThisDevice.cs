﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.NlsTest.TestSteps
{
    public class ClickOnAddButtonOnAddThisDevice : TestStep
    {
        public override string Description => "User clicks on the Add button";
        TrustedDeviceModule trustedDeviceModule = TrustedDeviceModule.Instance;

        public override void Action()
        {
            BaseContracts.MouseClickAndWait(ConfigurationPage.AddThisDeviceOnAddButton);
            trustedDeviceModule.SetCapturedDate();
            ConfigurationPage.AddThisDeviceOnAddButton.WaitUntilInvisible(2);
        }
    }
}
