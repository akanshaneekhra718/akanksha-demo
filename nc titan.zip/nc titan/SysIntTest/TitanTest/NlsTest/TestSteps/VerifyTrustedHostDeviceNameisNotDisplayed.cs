﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.NlsTest.TestSteps
{
    public class VerifyTrustedHostDeviceNameisNotDisplayed : TestStep
    {
        [TestStepParameter(DisplayName = "UserEnteredHostname")]
        public string UserEnteredHostname { get; set; }

        public override string Description => "Verify Trusted host device name parameter is not displayed in Trusted Device list";
        readonly TrustedDeviceModule trustedDeviceModule = TrustedDeviceModule.Instance;

        public override void Action()
        {
            if (String.IsNullOrEmpty(UserEnteredHostname))
            {
                Assert.Fail("User Entered hostname not present");
                return;
            }

            trustedDeviceModule.UpdateTrustedDevice();
            Assert.IsFalse(trustedDeviceModule.TrustedDeviceList.AsParallel().Any(x => x.Name.Equals(UserEnteredHostname)));
        }
    }
}
