﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.NlsTest.TestSteps
{
    public class ApolloSimulatorIsStartedWithErroneousSpO2RawFile : TestStep
    {
        [TestStepParameter(DisplayName = "Erroneous SpO2 Raw File")]
        public string ErroneousSpO2RawFile { get; set; }
        public override string Description => "Apollo Simulator Is Started With Erroneous SpO2 Raw File";

        readonly TitanUITestController myController = TitanUITestController.Instance;
        readonly ApolloSimulatorController myApolloSimulatorController = ApolloSimulatorController.Instance;
        public override void Initialize()
        {
            CommonBase.RemoteAddress = myController.GetLocalAddress();
        }
        public override void Precondition()
        {
            myApolloSimulatorController.KillPreexistingApolloSimulator();
        }

        /// <inheritdoc />
        public override void Action()
        {
            if (String.IsNullOrEmpty(ErroneousSpO2RawFile))
            {
                Assert.Fail("Erraneous Raw file name not present");
                return;
            }

            Log.WriteInfo("Provided Raw file :" + ErroneousSpO2RawFile);

            if (!File.Exists(ErroneousSpO2RawFile))
            {
                Assert.Fail(ErroneousSpO2RawFile + "Raw file does not exist in directory ");
                return;

            }

            Assert.IsTrue(myApolloSimulatorController.StartApolloSimulatorWithApolloRawFile(ErroneousSpO2RawFile));
        }
    }
}