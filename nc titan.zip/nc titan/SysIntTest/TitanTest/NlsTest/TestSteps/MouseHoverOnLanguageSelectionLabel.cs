﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.NlsTest.TestSteps
{
    public class MouseHoverOnLanguageSelectionLabel : TestStep
    {
        public override string Description => "User mouse hovers on the Language selection menu item from User Menu drop down list";

        public override void Action()
        {
            try
            {
                UserIdentifierOption.LanguageLabel.MouseMove();
                UserIdentifierOption.LanguageMenu.WaitUntilVisible(5);
            }
            catch (Exception ex)
            {
                Assert.Fail("Unable to mouse move:" + ex.Message);
            }
        }
    }
}
