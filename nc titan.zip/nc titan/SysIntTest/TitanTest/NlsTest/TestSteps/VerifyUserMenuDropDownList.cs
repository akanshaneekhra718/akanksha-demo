﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.NlsTest.TestSteps
{
    public class VerifyUserMenuDropDownList:TestStep
    {
        public override string Description => "Verify User Menu drop down list is displayed";

        public override void Action()
        {
            Assert.IsTrue(UserIdentifierOption.UserIdentifierMenu.Visible);
        }
    }
}
