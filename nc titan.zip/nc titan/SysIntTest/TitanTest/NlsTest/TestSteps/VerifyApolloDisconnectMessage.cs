//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.NlsTest.TestSteps;

public class VerifyApolloDisconnectMessage : TestStep
{
    [TestStepParameter(DisplayName = "Apollo Disconnect Messages")]
    public string ApolloDisconnectMessage { get; set; }
    public override string Description => "Verify Apollo Disconnect Msg";
   
    /// <inheritdoc />
    public override void Action()
    {
        if (String.IsNullOrEmpty(ApolloDisconnectMessage))
        {
            Assert.Fail("Apollo Disconnect Messages is empty or null");
            return;
        }

        TitanHomePage.StaticPage.WaitUntilVisible(10);
        Assert.AreEqual(TitanHomePage.StaticPage.Name, ApolloDisconnectMessage); 
    }
}