﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.NlsTest.TestSteps
{
    public class UserEnterDeviceNameInputField : TestStep
    {
        public override string Description => "User enters the WorkLaptopChrome in the Device Name input field text on the Add This Device dialog";

        public override void Action()
        {
            ConfigurationPage.AddDeviceNameField.Text = "WorkLaptopChrome";
        }
    }
}
