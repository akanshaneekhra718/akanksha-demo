﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.NlsTest.TestSteps;

public class ClientConnectionsAreDegradedForXSec : TestStep
{
    [TestStepParameter(DisplayName = "ControlCommand")]
    public string ControlCommand { get; set; }
    [TestStepParameter(DisplayName = "TimePeriod")]
    public string TimePeriod { get; set; }

    public override string Description => "Step to Network Error Misbehaviour";
    readonly TitanUITestController myController = TitanUITestController.Instance;
    readonly VitalSignTestModule myTestModule = new VitalSignTestModule();

    public override void Initialize()
    {
        CommonBase.RemoteAddress = myController.GetLocalAddress();
        myTestModule.InjectLogger(Log);
    }

    /// <inheritdoc />
    public override void Action()
    {
        if (String.IsNullOrEmpty(ControlCommand) || String.IsNullOrEmpty(TimePeriod))
        {
            Log.WriteError("ControlCommand :" + ControlCommand);
            Log.WriteError("TimePeriod :" + TimePeriod);
            Assert.Fail("Test parameter is undefined");
            return;
        }

        Assert.IsTrue(myTestModule.SendTestMessage(ControlCommand, int.Parse(TimePeriod), TestTargets.WorkflowController));

    }

}
