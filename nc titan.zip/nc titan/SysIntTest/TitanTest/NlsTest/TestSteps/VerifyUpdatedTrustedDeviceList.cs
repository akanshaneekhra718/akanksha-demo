﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.NlsTest.TestSteps
{
    public class VerifyUpdatedTrustedDeviceList : TestStep
    {
        public override string Description => "Verify updated trusted list";
        readonly TrustedDeviceModule trustedDeviceModule = TrustedDeviceModule.Instance;
        public override void Action()
        {
            List<TrustedDeviceParammeter> trustedDrviceList = trustedDeviceModule.TrustedDeviceList;
            trustedDeviceModule.InjectLogger(Log);
            trustedDeviceModule.UpdateTrustedDevice();

            if (!trustedDeviceModule.TrustedDeviceList.Any() || !trustedDrviceList.Any())
            {
                Assert.Fail("Test failed: Unable to retrieve trusted device list.");
                return;
            }

            if (trustedDeviceModule.TrustedDeviceList[0] == trustedDrviceList[0])
            {
                Assert.Fail("Test failed: Trusted Device List not updated after calling UpdateTrustedDevice()."); 
                return;
            }

            for (int count = trustedDrviceList.Count -1; count == 0; count--)
            {
                if (!trustedDeviceModule.CompareTructedDevice(trustedDrviceList[count], trustedDeviceModule.TrustedDeviceList[count]))
                {
                    Assert.Fail("Test failed: Device information mismatch between initial and updated trusted device lists.");
                    return;
                }
            }
        }
    }

}
