﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.NlsTest.TestSteps
{
    public class ClickOnAddDeviceButton : TestStep
    {
        public override string Description => "Click on the Add Device button in the Trusted Device dialog";

        readonly TrustedDeviceModule trustedDeviceModule = TrustedDeviceModule.Instance;
        public override void Action()
        {
            BaseContracts.MouseClickAndWait(ConfigurationPage.TrustedAddButton);
            ConfigurationPage.CancelThisDeviceOnAddButton.WaitUntilVisible(2);
            trustedDeviceModule.SetCapturedDate();
        }
    }
}
