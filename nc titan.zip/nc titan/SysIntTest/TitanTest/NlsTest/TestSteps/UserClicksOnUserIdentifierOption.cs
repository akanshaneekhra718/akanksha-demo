﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.NlsTest.TestSteps
{
    public class UserClicksOnUserIdentifierOption:TestStep
    {
        public override string Description => "User clicks on the User Identifier option on the Titan home Page";

        public override void Action()
        {
            TitanHomePage.UserIdentifierLabel.WaitUntilVisible(10, ExecutionContext.CancellationToken);
            Assert.IsFalse(UserIdentifierOption.UserIdentifierMenu.Visible);
            TitanHomePage.UserIdentifierLabel.MouseClick();
        }  
    }
}
