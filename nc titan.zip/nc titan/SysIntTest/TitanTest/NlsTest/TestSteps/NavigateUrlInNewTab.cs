﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.NlsTest.TestSteps
{
    public class NavigateUrlInNewTab : TestStep
    {
        public override string Description => "Open Titan URL in new Tab";

        public override void Action()
        {
            string pageAddress = Environment.GetEnvironmentVariable("TITAN_WEBPAGE_ADDRESS") ?? TitanTestConstants.HostName;
            string pageLink = "http://" + pageAddress + ":" + TitanTestConstants.TitanPort.ToString();

            try
            {
                TitanHomePage.NewTab.MouseClick();
                TitanHomePage.NewTabAdressBar.MouseClick();
                TitanHomePage.NewTabAdressBar.Text = pageLink;
                Keyboard.PressKey(KeyboardKey.Enter);
            }
            catch (Exception ex)
            {
                Assert.Fail("Error caught while launching url in new tab:Due to SITA: " + ex.Message);
            }


            TitanHomePage.SettingsIcon.WaitUntilVisible(30);
        }
    }
}
