﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.NlsTest.TestSteps
{
    public class EnglishLanguageIsHighligted : TestStep
    {
        public override string Description => "Verify English Language is highlighted in the language menu";

        public override void Action()
        {
            Assert.IsTrue(UserIdentifierOption.EnglishLanguageLabel.Attributes.ContainsKey("active"), "English language not active");
        }
    }
}
