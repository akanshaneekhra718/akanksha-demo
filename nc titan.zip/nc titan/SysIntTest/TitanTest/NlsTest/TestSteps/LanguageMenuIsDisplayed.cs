﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.NlsTest.TestSteps
{
    public class LanguageMenuIsDisplayed : TestStep
    {
        public override string Description => "Verify language menu is displayed";

        public override void Action()
        {
            Assert.IsTrue(UserIdentifierOption.LanguageMenu.Visible);
        }
    }
}
