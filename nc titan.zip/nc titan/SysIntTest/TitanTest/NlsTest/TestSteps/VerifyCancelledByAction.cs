﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.NlsTest.TestSteps
{
    public class VerifyCancelledByAction : TestStep
    {
        [TestStepParameter(DisplayName = "ActionsOnAddThisDevice")]
        public string ActionsOnAddThisDevice { get; set; }
        public override string Description => "Add workflow is canceled by actions";

        public override void Action()
        {
            if (String.IsNullOrEmpty(ActionsOnAddThisDevice))
            {
                Assert.Fail("Add This Device dialog is not available");
                return;
            }

            switch (ActionsOnAddThisDevice)
            {
                case "Cancel Button":
                    Log.WriteInfo("Test failed: To click on the 'Cancel' button to cancel the device addition.");
                    BaseContracts.MouseClickAndWait(ConfigurationPage.CancelThisDeviceOnAddButton);
                    break;
                case "Click on close Button":
                    Log.WriteInfo("Test failed: To click on the 'Close' button to dismiss the device addition dialog.");
                    BaseContracts.MouseClickAndWait(ConfigurationPage.AddThisDeviceCloseButton);
                    break;
                case "Click Outside Add This Device dialog":
                    Mouse.Move(TitanHomePage.TitanAccessBar.ClickablePoint, 1);
                    Mouse.Click();
                    break;
                default:
                    BrowserActionsAreSimulated browserActionsAreSimulated = new BrowserActionsAreSimulated();
                    browserActionsAreSimulated.BrowserActions = ActionsOnAddThisDevice;
                    browserActionsAreSimulated.Action();
                    break;
            }

            ConfigurationPage.CancelThisDeviceOnAddButton.WaitUntilInvisible(2);
        }
    }
}
