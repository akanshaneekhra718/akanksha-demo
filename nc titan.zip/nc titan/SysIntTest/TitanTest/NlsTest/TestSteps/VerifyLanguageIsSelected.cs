﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.NlsTest.TestSteps
{
    public class VerifyLanguageIsSelected : TestStep
    {
        [TestStepParameter(DisplayName = "Language")]
        public string Language { get; set; }
        public override string Description => "Verify language is selected";
        readonly NlsTestModule myNlsTest = NlsTestModule.Instance;

        public override void Action()
        {
            if (String.IsNullOrEmpty(Language))
            {
                Assert.Fail("Language is undefined");
                return;
            }

            switch (Language)
            {
                case "English":
                    myNlsTest.VerifyLanguageMenuItem(UserIdentifierOption.EnglishLanguageLabel, "English language not active");
                    break;

                case "Deutsch":
                    myNlsTest.VerifyLanguageMenuItem(UserIdentifierOption.GermanLanguageLabel, "German language not active");
                    break;

                case "Svenska":
                    myNlsTest.VerifyLanguageMenuItem(UserIdentifierOption.SwedishLanguageLabel, "Swedish language not active");
                    break;
                default:
                    Assert.Fail("Language is undefined :" + Language);
                    break;
            }
        }
    }
}
