﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.NlsTest.TestSteps
{
    public class VerifyAddedUserInTrustedDeviceListOnTop : TestStep
    {
        [TestStepParameter(DisplayName = "Hostname")]
        public string Hostname { get; set; }
        public override string Description => "Verify that added hostname is visible at the top of the Trusted Devices list with datestamp";
        readonly TrustedDeviceModule trustedDeviceModule = TrustedDeviceModule.Instance;

        public override void Action() 
        {
            if (String.IsNullOrEmpty(Hostname))
            {
                Assert.Fail("Hostname is not avialable");
                return;
            }

            trustedDeviceModule.UpdateTrustedDevice();
            if (!trustedDeviceModule.TrustedDeviceList.Any())
            {
                Assert.Fail("Trusted Device list is not avilable");
                return;
            }

            Assert.AreEqual(Hostname, trustedDeviceModule.TrustedDeviceList[0].Name,"Trusted device name is not at top");
            Assert.AreEqual(trustedDeviceModule.DateCaptured, trustedDeviceModule.TrustedDeviceList[0].LastActive, "Trusted device date is not at top");
        }


    }
}

