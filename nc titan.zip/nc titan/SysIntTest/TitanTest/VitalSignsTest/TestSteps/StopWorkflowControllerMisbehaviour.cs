﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>

namespace TitanTest.VitalSignsTest.TestSteps;

public class StopWorkflowControllerMisbehaviour : TestStep
{
    public override string Description => "Step to Stop Network Error Misbehaviour";
    readonly TitanUITestController myController = TitanUITestController.Instance;
    readonly VitalSignTestModule myVitalSignTestModule = new VitalSignTestModule();

    public override void Initialize()
    {
        CommonBase.RemoteAddress = myController.GetLocalAddress();
    }

    /// <inheritdoc />
    public override void Action()
    {
        Assert.IsTrue(myVitalSignTestModule.SendTestMessage("StopControlling", 0, TestTargets.WorkflowController));
    }
}
