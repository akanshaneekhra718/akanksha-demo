﻿// <copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>

namespace TitanTest.VitalSignsTest.TestModule
{
    public sealed class VitalSignTestModule
    {
        private Xpta.Sita.TestSteps.ILogger myLogger;
        private static readonly object lockObj = new object();
        private static VitalSignTestModule instance = null;
        private readonly TestRestClient myTestRestClient;

        public void InjectLogger(Xpta.Sita.TestSteps.ILogger logger)
        {
            myLogger = logger;
        }
        public static VitalSignTestModule Instance
        {
            get
            {
                lock (lockObj)
                {
                    if (instance == null)
                    {
                        instance = new VitalSignTestModule();
                    }
                    return instance;
                }
            }
        }
        public VitalSignTestModule()
        {
            myTestRestClient = new TestRestClient();
        }

        public bool VerifyNetworkErrorModalDialog(string ExpNetworkDialogLabelText ,string ExpIconType, string ExpNetworkErrorModalDialogText)
        {
            bool isFound = false;
            DateTime endTime = DateTime.Now.AddSeconds(20);
            while (endTime > DateTime.Now)
            {
                try
                {
                    string ActDialogLabelText = TitanHomePage.NetworkErrorModelDialogue.GetAttribute("label");
                    string ActIconType = TitanHomePage.NetworkErrorModelDialogue.GetAttribute("type");
                    string ActNetworkErrorModalDialogText = TitanHomePage.NetworkErrorModelDialogue.TextValue;

                    if (ActDialogLabelText.Equals(ExpNetworkDialogLabelText) && ActIconType.Equals(ExpIconType) && ActNetworkErrorModalDialogText.Equals(ExpNetworkErrorModalDialogText))
                    {
                        isFound = true;
                        break;
                    }
                    else
                    {
                        myLogger?.WriteInfo($"Network Modal Dialog is not Available with Label{ActDialogLabelText} is displayed with {ActIconType} with text as {ActNetworkErrorModalDialogText} in the browser. Dialog Label expected is :{ExpNetworkDialogLabelText} with Icon Type as {ExpIconType} with Text as {ExpNetworkErrorModalDialogText}");
                       myLogger?.WriteInfo("Some other display found in the browser. Having Version : " + ActDialogLabelText);
                    }
                }
                catch (Exception ex)
                {
                    myLogger?.WriteError(ex.Message);
                }
            }
            return isFound;
        }

        private ControlCommands ParseControlCommand(string control)
        {
            ControlCommands command;
            System.Enum.TryParse(control, out command);
            return command;
        }

        public bool SendTestMessage(TestCommandType testCommandType, TestTargets testTargets, string control, int timePeriod)
        {
            try
            {
                TestMessage myTestMessage = new TestMessage()
                {
                    CommandType = testCommandType,
                    Target = testTargets,
                    ControlCommand = ParseControlCommand(control),
                    TimePeriod = timePeriod
                };
                myTestRestClient.SendRestRequest(myTestMessage, myTestMessage.Target).GetAwaiter().GetResult();
                //Some time is given to wait after control command is fired
                Thread.Sleep(5000);
                return true;
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
