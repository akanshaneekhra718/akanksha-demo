//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.ConfigurationTest.TestModule;
public class SetUpApolloMisbehaviourFWHWProtcl:TestStep
{
    public override string Description => "Set up for apollo misbehaviour Hardware and firmware mismatch";
    [TestStepParameter(DisplayName = "FirmwareMajorVer")]
    public int FirmwareMajorVer { get; set; }

    [TestStepParameter(DisplayName = "FirmwareMinorVer")]
    public int FirmwareMinorVer { get; set; }

    [TestStepParameter(DisplayName = "HardwareMajorVer")]
    public int HardwareMajorVer { get; set; }

    [TestStepParameter(DisplayName = "HardwareMinorVer")]
    public int HardwareMinorVer { get; set; }
    
    [TestStepParameter(DisplayName = "ProtocolMajVer")]
    public int ProtocolMajVer{get; set; }

    readonly ConfigurationObserverController ObserverControllerController = ConfigurationObserverController.Instance;

   /// <inheritdoc />
    public override void Action()
    {
        ObserverControllerController.SetHwFwPrtoclVerPairing(FirmwareMajorVer,FirmwareMinorVer,HardwareMajorVer,HardwareMinorVer,ProtocolMajVer);
    }
}