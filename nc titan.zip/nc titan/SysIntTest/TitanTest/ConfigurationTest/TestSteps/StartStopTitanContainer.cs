﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.ConfigurationTest.TestModule;

public class StartStopTitanContainer : TestStep
{
    public override string Description => "Start/Stop the Titan container";

    [TestStepParameter(DisplayName = "ContainerAction")]
    public string ContainerAction { get; set; }

    readonly TitanContainerController myTitanContainercontroller = TitanContainerController.Instance;

    public override void Action()
    {
        ActionType actionType;
        if (Enum.TryParse(ContainerAction, out actionType))
        {
            myTitanContainercontroller.StartStopTitanContainer(actionType);
        }
    }
}
