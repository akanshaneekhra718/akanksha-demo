﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.ConfigurationTest.TestModule;

public class EnterHostName : TestStep
{
    public override string Description => "Enter hostname into the field";
    [TestStepParameter(DisplayName = "Hostname")]
    public string Hostname { get; set; }
    readonly TitanUITestController myTitanUITestController=TitanUITestController.Instance;
    public override void Action()
    {
        myTitanUITestController.InjectLogger(Log);
        if (!string.IsNullOrEmpty(Hostname))
        {
            ConfigurationPage.HostName.WaitUntilVisible(10);
            if(Hostname.Trim().ToUpper().Equals("HOST.DOCKER.INTERNAL"))
            {
             Hostname=String.IsNullOrEmpty(myTitanUITestController.GetSystemIPAddress())?throw new Exception("GetIPAddress returned empty string"):myTitanUITestController.GetSystemIPAddress();
            }
            //entering value into Hostname field
             BaseContracts.MouseMoveAndClick(ConfigurationPage.HostName);
             ConfigurationPage.HostName.Text=Hostname;
        }
        else
        {
            throw new ArgumentNullException("Passed network parameters Hostname,TCP port,UDP port are empty or null");
        }
    }
}
