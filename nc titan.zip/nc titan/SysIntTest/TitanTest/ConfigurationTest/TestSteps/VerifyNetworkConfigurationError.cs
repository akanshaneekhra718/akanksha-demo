//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.ConfigurationTest.TestModule;
public class VerifyNetworkConfigurationError:TestStep
{
    public override string Description => "Verify NetworkConfiguration Error";
    [TestStepParameter(DisplayName = "ErrorMsg")]
    public string ErrorMsg { get; set; }

   /// <inheritdoc />
    public override void Action()
    {
        ConfigurationPage.ErrorNotificationNetworkConfig.WaitUntilVisible(10);
        string errorMsg=ConfigurationPage.ErrorNotificationNetworkConfig.GetAttribute("message");
        Assert.IsTrue(errorMsg.Equals(ErrorMsg));
    }
}
