//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.ConfigurationTest.TestModule;
public class VerifyEditButtonEnabled:TestStep
{
    public override string Description => "Verify Edit Button Enabled";

       /// <inheritdoc />
    public override void Action()
    {
      ConfigurationPage.EditButton.WaitUntilEnabled(15);
      Assert.IsTrue(ConfigurationPage.EditButton.Enabled);
    }
}