//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.ConfigurationTest.TestModule;
public class VerifyTitanIsRestarted : TestStep
{
    public override string Description => "Restart and verify Titan in Titan UI";
    readonly TitanContainerController myTitanContainercontroller = TitanContainerController.Instance;

    public override void Action()
    {
       myTitanContainercontroller.StartStopTitanContainer(ActionType.restart);
       if(TitanHomePage.StaticPage.Visible)
       {
         Assert.IsFalse(string.Equals(TitanHomePage.StaticPage.GetAttribute("label"),ConfigurationTestConst.TitanDisconnect));
       }
       else
       {
         Assert.IsFalse(TitanHomePage.StaticPage.Visible);
       }
    }
}