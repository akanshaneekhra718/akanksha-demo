//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.ConfigurationTest.TestModule;
public class VerifyTitanSysInfo:TestStep
{
    public override string Description => "Verify Titan System Information";
    readonly ConfigurationObserverController myObserverControllerController = ConfigurationObserverController.Instance;
    [TestStepParameter(DisplayName = "Connection Status")]
    public string ConnectionStatus { get; set; }
    
    public override void Precondition()
    {
      myObserverControllerController.StopTestServer();
    }
    public override void Action()
    {
      if(ConnectionStatus.Equals("NotConnected"))
      {
        ConfigurationTestController.AddTitanSysInfo();
        Assert.IsTrue(VerifyTitanSysInfoUI());
        Assert.IsTrue(myObserverControllerController.VerifyTitanSysInfo());
      }
      else
      {
        Dictionary<string,string> dictTitanSysInfoUi= new Dictionary<string, string>();
        for(int iteration=0;iteration<ConfigurationPage.TitanSysInfo.Count();iteration+=2)
        {
         dictTitanSysInfoUi.Add(ConfigurationPage.TitanSysInfo[iteration].InnerText,ConfigurationPage.TitanSysInfo[iteration+1].InnerText);
        }
        Assert.IsTrue(dictTitanSysInfoUi.SequenceEqual(ConfigurationTestController.myDictTitanSysInfo));
      }
   }

   private bool VerifyTitanSysInfoUI()
   {
     bool isTitanSysInfoAsExpected= (ConfigurationTestController.myDictTitanSysInfo[ConfigurationTestConst.MaterialNumberLabel]==ConfigurationTestConst.ExpectedTripleDashValue
                                   &&ConfigurationTestController.myDictTitanSysInfo[ConfigurationTestConst.SerialNumberLabel]==ConfigurationTestConst.ExpectedTripleDashValue
                                   &&!string.IsNullOrEmpty(ConfigurationTestController.myDictTitanSysInfo[ConfigurationTestConst.SoftwareVersionLabel]) 
                                   &&ConfigurationTestController.myDictTitanSysInfo[ConfigurationTestConst.SoftwareVersionLabel]!=ConfigurationTestConst.ExpectedTripleDashValue
                                   &&!string.IsNullOrEmpty(ConfigurationTestController.myDictTitanSysInfo[ConfigurationTestConst.BuildDateLabel]) 
                                   &&ConfigurationTestController.myDictTitanSysInfo[ConfigurationTestConst.BuildDateLabel]!=ConfigurationTestConst.ExpectedTripleDashValue
                                   &&!string.IsNullOrEmpty(ConfigurationTestController.myDictTitanSysInfo[ConfigurationTestConst.IPAddressLabel]) 
                                   &&ConfigurationTestController.myDictTitanSysInfo[ConfigurationTestConst.IPAddressLabel]!=ConfigurationTestConst.ExpectedTripleDashValue
                                   &&!string.IsNullOrEmpty(ConfigurationTestController.myDictTitanSysInfo[ConfigurationTestConst.HostNameLabel]) 
                                   &&ConfigurationTestController.myDictTitanSysInfo[ConfigurationTestConst.HostNameLabel]!=ConfigurationTestConst.ExpectedTripleDashValue);
     return isTitanSysInfoAsExpected;
   }
}