//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.ConfigurationTest.TestModule;
public class TearDownHwAndFwProtclMismatch:TestStep
{
    public override string Description => "Tear down steps for hardware and firmware mismatch";
    readonly ConfigurationObserverController ObserverControllerController = ConfigurationObserverController.Instance;

       /// <inheritdoc />
    public override void Action()
    {
      ApolloSimulatorController apolloSimulatorController = ApolloSimulatorController.Instance;
      Assert.IsTrue(apolloSimulatorController.FindAndStopApolloSimulator());
      TitanHomePage.MainWindow.Close();
      if(ProcessController.CheckBrowserProcessAlive(ProcessController.ProcessType.chrome))
      {
       Log.WriteInfo("Chrome browser is failed to get closed by close button.");
       ProcessController.KillProcess(ProcessController.ProcessType.chrome);
      }
    }

    public override void CleanUp()
    {
      ObserverControllerController.SetHwFwPrtoclVerPairing(ConfigurationTestConst.FwMajorVer,ConfigurationTestConst.FwMinorVer,ConfigurationTestConst.HwMajorVer,ConfigurationTestConst.HwMinorVer,ConfigurationTestConst.ProtocolMajorVer);
    }
}