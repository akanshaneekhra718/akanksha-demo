//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.ConfigurationTest.TestModule;
public class VerifyTitanReceivedVitalParam:TestStep
{
    public override string Description => "Verify Titan receives Vital parameters";
    readonly ConfigurationObserverController ObserverControllerController = ConfigurationObserverController.Instance;

       /// <inheritdoc />
    public override void Action()
    {
      Assert.IsTrue(ObserverControllerController.VerifyTitanReceivedVitalParameters());
    }
}