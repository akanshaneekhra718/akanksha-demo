//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.ConfigurationTest.TestModule;
public class VerifyNetworkParameterFieldsReadonly : TestStep
{
    public override string Description => "Verify Network Parameter Fields Readonly";
    /// <inheritdoc />
    public override void Action()
    {   
        ConfigurationPage.HostName.WaitUntilVisible(15);
        bool checkReadonly = ConfigurationPage.HostName.ReadOnly
                         &&ConfigurationPage.TCPPort.ReadOnly
                         &&ConfigurationPage.UDPPort.ReadOnly;
        Assert.IsTrue(checkReadonly);
    }
}
