//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.ConfigurationTest.TestModule;
public class VerifyVitalSignsDisplayed:TestStep
{
    public override string Description => "Verify vital signs displayed";

       /// <inheritdoc />
    public override void Action()
    {
      TitanHomePage.HeartRateValue.WaitUntilVisible(10);
      Assert.IsTrue(TitanHomePage.HeartRateValue.Visible);
    }
}