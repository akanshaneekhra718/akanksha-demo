﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.ConfigurationTest.TestModule;

public class ClickTcpPort : TestStep
{
	public override string Description => "Click on TCP Portnumber field";
	public override void Action()
	{
		BaseContracts.MouseMoveAndClick(ConfigurationPage.TCPPort);
	}
}