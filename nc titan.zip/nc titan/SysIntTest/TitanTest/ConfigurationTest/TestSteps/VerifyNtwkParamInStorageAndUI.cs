//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.ConfigurationTest.TestModule;
public class VerifyNtwkParamInStorageAndUI:TestStep
{
    public override string Description => "Verify Network parameters are same in storage and Titan UI";
    readonly ConfigurationObserverController myObserverControllerController = ConfigurationObserverController.Instance;

    public override void Precondition()
    {
      myObserverControllerController.StopTestServer();
    }
    public override void Action()
    {
        ConfigurationPage.EditButton.WaitUntilVisible(10);
        BaseContracts.MouseMoveAndClick(ConfigurationPage.EditButton);

        // Clicking and getting value from HostName field
        BaseContracts.MouseMoveAndClick(ConfigurationPage.HostName);
        string hostName=ConfigurationPage.HostName.Text;

        // Clicking and getting value from TCPPort field
        BaseContracts.MouseMoveAndClick(ConfigurationPage.TCPPort);
        int tcpPort=Convert.ToInt32(ConfigurationPage.TCPPort.Text);
        
        // Clicking and getting value from UDPPort field
        BaseContracts.MouseMoveAndClick(ConfigurationPage.UDPPort);
        int udpPort=Convert.ToInt32(ConfigurationPage.UDPPort.Text);
        Assert.IsTrue(myObserverControllerController.VerifyNetwkParamStorageAndUI(hostName,tcpPort,udpPort));
    }
}