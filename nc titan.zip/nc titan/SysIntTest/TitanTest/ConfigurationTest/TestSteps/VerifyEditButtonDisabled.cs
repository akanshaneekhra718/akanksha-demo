﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.ConfigurationTest.TestModule;
public class VerifyEditButtonDisabled : TestStep
{
    public override string Description => "Verify Edit Button Disabled";

    /// <inheritdoc />
    public override void Action()
    {
        Assert.IsFalse(ConfigurationPage.EditButton.Enabled);
    }
}