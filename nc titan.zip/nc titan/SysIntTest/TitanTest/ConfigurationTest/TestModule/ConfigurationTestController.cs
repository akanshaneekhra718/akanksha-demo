//  <copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>

namespace TitanTest.ConfigurationTest.TestModule;
public class ConfigurationTestController
{
    public static Dictionary<string,string> myDictTitanSysInfo=new Dictionary<string, string>();

  /// <summary>
 ///  Below Data contract fetch value from UI for system information and add it into a dictionary "myDictTitanSysInfo" 
///for test verification
/// </summary>
    public static void AddTitanSysInfo()
    {
      for(int iteration=0;iteration<ConfigurationPage.TitanSysInfo.Count();iteration+=2)
      {
         myDictTitanSysInfo.Add(ConfigurationPage.TitanSysInfo[iteration].InnerText,ConfigurationPage.TitanSysInfo[iteration+1].InnerText);
      }
    }
}