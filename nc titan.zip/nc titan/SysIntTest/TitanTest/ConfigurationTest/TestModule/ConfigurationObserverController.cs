//  <copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>

namespace TitanTest.ConfigurationTest.TestModule;
public class ConfigurationObserverController
{
    public TestServer myTestServer;
    private const int MinutesToSeconds = 60;
    private readonly ConcurrentDictionary<SignalPipelineObservationPoint, BlockingCollection<SignalPipelineTestResponse>> mySignalPipelineData;
    private readonly ConcurrentDictionary<WorkflowControllerObservationPoint, BlockingCollection<WorkflowControllerTestResponse>> myWorkflowControllerData;
    private readonly BlockingCollection<string> myWorkflowMessages;
    private readonly TestRestClient myTestRestClient;
    private const int maxAttemptCount = 25;
    private static readonly object lockObj = new object();
    private static ConfigurationObserverController instance = null;
  
    public static ConfigurationObserverController Instance
    {
        get
        {
            lock (lockObj)
            {
                if (instance == null)
                {
                    instance = new ConfigurationObserverController();
                }
                return instance;
            }
        }
    }

    public ConfigurationObserverController()
    {
        mySignalPipelineData = new ConcurrentDictionary<SignalPipelineObservationPoint, BlockingCollection<SignalPipelineTestResponse>>();
        myWorkflowControllerData = new ConcurrentDictionary<WorkflowControllerObservationPoint, BlockingCollection<WorkflowControllerTestResponse>>();
        myWorkflowMessages = new BlockingCollection<string>();
        myTestServer = new TestServer(mySignalPipelineData, myWorkflowControllerData, myWorkflowMessages);
        myTestRestClient = new TestRestClient();
    }

    public bool StartTestServer() => StartTestServerAndSendMessage(null);
    
    public bool StartTestServerAndSendMessage(TestMessage testMessage)
    {
        bool isServerStarted;
        myTestServer.SendDataToClientWhenConnected(testMessage);
        isServerStarted = myTestServer.StartAndWaitForClientToConnect(5 * MinutesToSeconds);// wait for 5 minute max
        /* We need not verify if command is received for Observing because we receive data immediately after observation starts
        But in case of Controlling we need to observe the behavior, that is the reason we verify command received */
        if (testMessage != null && testMessage.CommandType == TestCommandType.Control && isServerStarted
            && testMessage.ControlCommand != ControlCommands.Kill)
            myTestServer.IsCommandAcknowledgedByClient();
        return isServerStarted;
    }

    public void SendToMessageToAllConnectedClient(TestMessage testMessage)
    {
        myTestServer.SendToAllConnectedClient(testMessage);
    }

    public void StopTestServer()
    {
        myTestServer.Stop();
    }

    public void SetHwFwPrtoclVerPairing(int FirmwareMajorVer,int FirmwareMinorVer,int HardwareMajorVer,int HardwareMinorVer,int ProtocolMajVer)
    {
        try
        {
            string pairingParameters ="{\"versions\":{\"firmware\":{\"major\":"+FirmwareMajorVer+",\"minor\":"+FirmwareMinorVer+"},\"hardware\":{\"major\":"+HardwareMajorVer+",\"minor\":"+HardwareMinorVer+"},\"protocol\":{\"major\":"+ProtocolMajVer+"}}}";
            TestMessage testMessage = new TestMessage
            {
                CommandType = TestCommandType.Control,
                Target = TestTargets.WorkflowController,
                ControlCommand = ControlCommands.SetPairingDetailsIntoStorage,
                PairingVersion=pairingParameters
            };
            Assert.IsTrue(myTestRestClient.SendRestRequest(testMessage, testMessage.Target).GetAwaiter().GetResult());
            //Some time is given to wait after control command is fired
            Thread.Sleep(5000);
        }
        catch (Exception ex)
        {
            throw new Exception(ex.ToString());
        }
    }

    public bool VerifyTitanReceivedVitalParameters()
    {
        bool isStateExpected = true;
        TestMessage testmsg = new TestMessage()
        {
            CommandType = TestCommandType.Observe,
            Target = TestTargets.SignalPipeline,
            TimePeriod = 10
        };
        StartTestServerAndSendMessage(testmsg);
        for (int attempted = 0; attempted < maxAttemptCount; attempted++)
        {
            if (mySignalPipelineData.ContainsKey(SignalPipelineObservationPoint.UdpAcquisitionDataReceived))
            {
                isStateExpected = mySignalPipelineData[SignalPipelineObservationPoint.UdpAcquisitionDataReceived].
                                  Select(x => x.AcquisitionData.VitalSignsData.Spo2Saturation).ToList().Count>0;
                                 
                                  
                if(isStateExpected)
                {
                    Logger.Log(TraceLevel.Info, "Vital value received at Signal Pipeline ");
                }
                break;
            }
            else
            {
                Thread.Sleep(TimeSpan.FromMilliseconds(300));
            }
        }
        mySignalPipelineData.Clear();
        return isStateExpected;
    }

    public bool VerifyNetwkParamStorageAndUI(string hostname, int tcpPort, int udpPort)
    {
        bool isStorageContainsParameters = false;
        TestMessage testmsg = new TestMessage()
        {
            CommandType = TestCommandType.Observe,
            Target = TestTargets.WorkflowController,
            ControlCommand = ControlCommands.QueryNetworkParametersFromStorage
        };
        StartTestServerAndSendMessage(testmsg);
        for (int attempted = 0; attempted < maxAttemptCount; attempted++)
        {
            if (myWorkflowControllerData.ContainsKey(WorkflowControllerObservationPoint.NetwrorkParameterStorageDataSend))
            {
                isStorageContainsParameters = myWorkflowControllerData[WorkflowControllerObservationPoint.NetwrorkParameterStorageDataSend]
                                             .Select(x => new
                                             {
                                                 x.NetworkParameterData.Hostname,
                                                 x.NetworkParameterData.TcpPort,
                                                 x.NetworkParameterData.UdpPort
                                             })
                                             .Any(x => x.Hostname.Equals(hostname) && x.TcpPort == tcpPort && x.UdpPort == udpPort);
                break;
            }
            else
            {
                Thread.Sleep(TimeSpan.FromMilliseconds(300));
            }
        }
        myWorkflowControllerData.Clear();
        return isStorageContainsParameters;
    }

    public bool VerifyTitanSysInfo()
    {
        bool isStateExpected = false;
        TestMessage testmsg = new TestMessage()
        {
            CommandType = TestCommandType.Observe,
            Target = TestTargets.WorkflowController,
            ControlCommand = ControlCommands.QueryTitanSystemInformation
        };
        StartTestServerAndSendMessage(testmsg);
        for (int attempted = 0; attempted < maxAttemptCount; attempted++)
        {
            if (myWorkflowControllerData.ContainsKey(WorkflowControllerObservationPoint.SystemInformationStorageDataSend))
            {
                BlockingCollection<WorkflowControllerTestResponse> observerData = myWorkflowControllerData[WorkflowControllerObservationPoint.SystemInformationStorageDataSend];
                JsonObject systemInfoJsonObject = observerData.FirstOrDefault().SystemInformation;
                if (systemInfoJsonObject != null)
                {
                    Dictionary<string, string> storageTitanSysInfo = systemInfoJsonObject.ToDictionary(element => element.Key, element => (string)element.Value);
                    isStateExpected=storageTitanSysInfo.SequenceEqual(ConfigurationTestController.myDictTitanSysInfo);
                }
                break;
            }
            else
            {
                Thread.Sleep(TimeSpan.FromMilliseconds(300));
            }
        }
        myWorkflowControllerData.Clear();
        return isStateExpected;
    }
}
