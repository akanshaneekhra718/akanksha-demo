//  <copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>

namespace TitanTest.ConfigurationTest.TestModule;
public class ConfigurationTestConst
{
    #region  versionInfo
    // Once version is changed or senlink is updated , change needs to be done here and also in feature file of pairing
    public const int  FwMajorVer=0;
    public const int  FwMinorVer=0;
    public const int  HwMajorVer=0;
    public const int  HwMinorVer=0;
    public const int  ProtocolMajorVer=3;
    #endregion
    
    #region TitanSysInformation
    public const string MaterialNumberLabel="Material Number";
    public const string ExpectedTripleDashValue="---";
    public const string SerialNumberLabel="Serial Number";
    public const string SoftwareVersionLabel="Software Version";
    public const string BuildDateLabel="Build Date";
    public const string IPAddressLabel="IP Address";
    public const string HostNameLabel="HostName";
    public const string TitanDisconnect="We Couldn't Connect To Titan";
    #endregion
}