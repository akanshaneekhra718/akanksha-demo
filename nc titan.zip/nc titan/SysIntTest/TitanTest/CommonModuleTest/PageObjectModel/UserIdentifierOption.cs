﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.Common.TestModule;

public static class UserIdentifierOption
{
    public static IChromeMenu UserIdentifierMenu => WebElementControl.GetControl<IMenu>("#userIdentifierMenu").ToChromeControl();
    public static IMenuItem LanguageLabel => WebElementControl.GetControl<IMenuItem>("#languageLabel").ToChromeControl();
    public static IChromeMenu LanguageMenu => WebElementControl.GetControl<IMenu>("#languageMenu").ToChromeControl();
    public static IChromeMenuItem EnglishLanguageLabel => WebElementControl.GetControl<IMenuItem>("#menu-item-en").ToChromeControl();
    public static IChromeMenuItem GermanLanguageLabel => WebElementControl.GetControl<IMenuItem>("#menu-item-de").ToChromeControl();
    public static IChromeMenuItem SwedishLanguageLabel => WebElementControl.GetControl<IMenuItem>("#menu-item-sv").ToChromeControl();
    public static IChromeControl MenuExpandWrapper => WebElementControl.GetControl<IChromeControl>(@"menuExpandWrapper").ToChromeControl();
}

