﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
using IWindow = Xpta.Sita.Spy.Interfaces.ControlTypes.IWindow;

namespace TitanTest.Common.TestModule;

public static class TitanHomePage
{
    #region WebElements
    public static IChromeText HeartRateValue => WebElementControl.GetControl<IText>(@"#titanValueBox\\.hrValue\\.id").ToChromeControl();
    public static IChromeText SpO2Value => WebElementControl.GetControl<IText>(@"#titanValueBox\\.spo2Value\\.id").ToChromeControl();
    public static IChromeText StaticPage => WebElementControl.GetControl<IText>(@"#apolloStatus").ToChromeControl();
    public static IChromeText TitleHomePage => WebElementControl.GetControl<IText>(@"sh-access-bar").ToChromeControl();
    public static IChromeWindow SettingDialog => WebElementControl.GetControl<IWindow>(@"#settings-dialog").ToChromeControl();
    public static IChromeButton SettingsIcon => WebElementControl.GetControl<IButton>("#settingIcon").ToChromeControl();
    public static IChromeText NetworkErrorModelDialogue => WebElementControl.GetControl<IText>(@"#critical-messages").ToChromeControl();
    public static IChromeButton UserIdentifierLabel => WebElementControl.GetControl<IButton>(@"#userIdentifierLabel").ToChromeControl();
    public static IChromeText SpO2StatusText => WebElementControl.GetControl<IText>(@"#spo2StatusText").ToChromeControl();
    public static Collection<IText> IBPGridLineLabelText => WebElementControl.GetControl<IText>(@"#waveform\\.gridline\\.label\\.1").Parent.Descendants<IText>(a => a.AutomationId.Contains("waveform.gridline.label"));
    public static IChromeForm SplashScreenPage => WebElementControl.GetControl<IForm>("#splashScreen").ToChromeControl();
    public static IChromeText copyRightInfo => WebElementControl.GetControl<IText>("#copyRight").ToChromeControl();
    public static IChromeText TitanAccessBar => WebElementControl.GetControl<IText>(@"#app-access-bar").ToChromeControl();
    public static IChromeCustom IBPGridLineWaveformArea => WebElementControl.GetControl<ICustom>(@"#waveform\\.gridline").ToChromeControl();
    public static IDocument document = WebElementControl.GetControl<IDocument>(@"#app-page").ToChromeControl();
    public static Collection<IChromeControl> IBPWaveformsLabel = document.ToChromeControl().QuerySelectorAll("sh-text[id*='waveform\\.text\\.label\\.id']");
    public static Collection<IChromeControl> IBPGridLineLabel => document.ToChromeControl().QuerySelectorAll("sh-text[id*='waveform\\.gridline\\.label']");
    public static Collection<IChromeControl> IBPGridLines => document.ToChromeControl().QuerySelectorAll("line[id*='waveform\\.gridline']");
    #endregion

    #region  BrowserAction
    public static  IWindow MainWindow => BaseControl.CreateControl<IWindow>("/Window[@Name~'Titan .*']");
    public static IButton NewTab => BaseControl.CreateControl<IButton>("/Window[@Name='Titan - Google Chrome']/Form[@Index='2']/Form[@Index='1']/Form[@Index='2']/Form[@Index='1']/Tab[@Index='1']/Button[@Name='New Tab']");
    public static ITextBox NewTabAdressBar => BaseControl.CreateControl<ITextBox>("/Window[@Name='New Tab - Google Chrome']/Form[@Index='2']/Form[@Index='1']/Form[@Index='2']/Form[@Index='1']/ToolBar[@Index='1']/Form[@Index='1']/TextBox[@Name='Address and search bar']");
    #endregion
}