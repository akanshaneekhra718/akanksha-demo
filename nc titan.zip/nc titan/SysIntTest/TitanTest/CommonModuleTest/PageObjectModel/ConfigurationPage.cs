//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.Common.TestModule;

public static class ConfigurationPage
{
    public static IChromeButton EditButton => WebElementControl.GetControl<IButton>(@"#editButton").ToChromeControl();
    public static IChromeButton NetworkMenuItem => WebElementControl.GetControl<IButton>(@"#Network").ToChromeControl();
    public static IChromeButton NetworkMenuItemDe => WebElementControl.GetControl<IButton>(@"#Netzwerk").ToChromeControl();
    public static IChromeButton NetworkMenuItemSv => WebElementControl.GetControl<IButton>(@"#N�tverk").ToChromeControl();
    public static IChromeTextBox HostName => WebElementControl.GetControl<ITextBox>(@"#inputTextHostname").ToChromeControl();
    public static IChromeTextBox TCPPort => WebElementControl.GetControl<ITextBox>(@"#inputTextTcpPort").ToChromeControl();
    public static IChromeTextBox UDPPort => WebElementControl.GetControl<ITextBox>(@"#inputTextUdpPort").ToChromeControl();
    public static IChromeButton ApplyButton => WebElementControl.GetControl<IButton>(@"#applyButton").ToChromeControl();
    public static IChromeTextBox ErrorNotificationNetworkConfig => WebElementControl.GetControl<ITextBox>(@"#inline-error-message").ToChromeControl();
    public static IChromeWindow SettingDialog => WebElementControl.GetControl<IWindow>(@"#settings-dialog").ToChromeControl();
    public static IChromeButton CloselButton => (IChromeButton)SettingDialog.FirstChild.ToChromeControl().QuerySelector(".close-button");
    public static IChromeButton SystemInformationMenuItem => WebElementControl.GetControl<IButton>(@"#System\\ Information").ToChromeControl();
    public static System.Collections.ObjectModel.Collection<IChromeControl> TitanSysInfo =>WebElementControl.GetControl<ITable>(@"sh-wrapper[id='Titan\\ System\\ Information']").ToChromeControl().QuerySelectorAll(@"sh-text[id*='Titan\\ System\\ Information']");
    public static IChromeButton DeviceAndUserManagement => WebElementControl.GetControl<IButton>(@"#Devices\\ and\\ Users").ToChromeControl();    
    public static IChromeText StaticTrustedDevicePage => WebElementControl.GetControl<IText>(@"#no-trusted-device").ToChromeControl();
    public static IChromeButton TrustedAddButton => WebElementControl.GetControl<IButton>(@"#addDevice").ToChromeControl();
    public static IChromeTextBox AddDeviceNameField => WebElementControl.GetControl<ITextBox>(@"#device-name").ToChromeControl();
    public static IChromeButton AddThisDeviceOnAddButton => WebElementControl.GetControl<IButton>(@"#add-button").ToChromeControl();
    public static IChromeTable TrustedDeviceTable => WebElementControl.GetControl<ITable>(@"#table").ToChromeControl();
    public static IChromeText TrustedDeviceDialog => WebElementControl.GetControl<IText>(@"#trusted-Devices").ToChromeControl();
    public static IChromeButton CancelThisDeviceOnAddButton => WebElementControl.GetControl<IButton>(@"#cancel-button").ToChromeControl();
    public static IChromeWindow TrustedAddDeviceModel => WebElementControl.GetControl<IWindow>(@"#add-device-modal").ToChromeControl();
    public static IChromeButton AddThisDeviceCloseButton => (IChromeButton)TrustedAddDeviceModel.FirstChild.ToChromeControl().QuerySelector(".close-button");
    public static IChromeButton ClearDeviceNameField => WebElementControl.GetControl<IButton>(@"#clear").ToChromeControl();


}