﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.Common.TestModule
{
    public class TearDown : TestStep
    {
        readonly TitanUITestController myController = TitanUITestController.Instance;
        [TestStepParameter(DisplayName = "System Type")]
        public override string Description => "Tear Down Step";

        public override void Initialize()
        {
            CommonBase.RemoteAddress = myController.GetLocalAddress();
        }
        /// <inheritdoc />
        public override void Action()
        {
            ApolloSimulatorController myApolloSimulatorController = ApolloSimulatorController.Instance;
            Assert.IsTrue(myApolloSimulatorController.FindAndStopApolloSimulator(), "Apollo Simukator process is still active");
            Assert.IsTrue(myController.CloseAllBrowser(),"Browser process is still active");
            CommonBase.RemoteAddress = null;
            Log.WriteInfo("Tear down executed");
        }
    }
}