﻿
namespace TitanTest.Common.TestModule
{
    public class SplashScreenIsVisible : TestStep
    {
        public override string Description => "Test steps to Splash Screen Is Visible";
        readonly TitanUITestController myController = TitanUITestController.Instance;

        public override void Initialize()
        {
            CommonBase.RemoteAddress = myController.GetLocalAddress();
        }

        /// <inheritdoc />
        public override void Action()
        {
            myController.InjectLogger(Log);
            Assert.IsTrue(myController.VerifySplashScreenIsPresentWithProductInfo());
        }
    }
}