﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.Common.TestModule
{
    public class ApolloTitanPairing : TestStep
    {
        readonly TitanUITestController myController = TitanUITestController.Instance;
        readonly ApolloSimulatorController myApolloSimulatorController = ApolloSimulatorController.Instance;
        public override string Description => "Apollo Titan Pairing is done";

        public override void Initialize()
        {
            CommonBase.RemoteAddress = myController.GetLocalAddress();
        }
        public override void Precondition()
        {
            Assert.IsTrue(myApolloSimulatorController.FindAndStopApolloSimulator());
            Assert.IsTrue(myController.BrowserIslaunchedAndNavigatedToTitanURL(myController.GetLocalAddress()));
            Assert.IsTrue(myApolloSimulatorController.StartApolloSimulator());
        }

        public override void Action()
        {
            myController.InjectLogger(Log);
            Assert.IsTrue(myController.ConfigureTitanToConnectApollo());
        }

        public override void CleanUp()
        {
            Assert.IsTrue(myApolloSimulatorController.FindAndStopApolloSimulator());
            Assert.IsTrue(myController.CloseAllBrowser());
        }
    }
}