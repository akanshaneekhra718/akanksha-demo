﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>

namespace TitanTest.Common.TestModule
{
    public class BrowserIslaunchedAndNavigatedToTitanURL : TestStep
    {
        [TestStepParameter(DisplayName = "System Type")]
        public string ExpSystemType { get; set; }
        public override string Description => "Browser is launched and Novigated to Titan URL";
        readonly TitanUITestController myController = TitanUITestController.Instance;

        /// <inheritdoc />
        public override void Action()
        {
            SystemType systemType = (ExpSystemType == "Exam" ? SystemType.ExamRoom : SystemType.ControlRoom);
            switch (systemType)
            {
                case SystemType.ExamRoom:
                    CommonBase.RemoteAddress = myController.GetLocalAddress();
                    Log.WriteInfo("Local IP add ::" + myController.GetLocalAddress());
                    Assert.IsTrue(myController.BrowserIslaunchedAndNavigatedToTitanURL(myController.GetLocalAddress()));
                    break;
                case SystemType.ControlRoom:
                    Log.WriteInfo("Remote IP add ::" + myController.GetRemoteAddress());
                    CommonBase.RemoteAddress = myController.GetRemoteAddress();
                    Assert.IsTrue(myController.BrowserIslaunchedAndNavigatedToTitanURL(myController.GetRemoteAddress()));
                    break;
            }
        }

    }
}