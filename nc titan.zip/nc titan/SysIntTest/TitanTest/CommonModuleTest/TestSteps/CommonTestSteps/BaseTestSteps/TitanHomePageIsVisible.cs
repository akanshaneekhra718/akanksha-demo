﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.Common.TestModule
{
    public class TitanHomePageIsVisible : TestStep
    {
        public override string Description => "Apollo Simulator is started";
        readonly TitanUITestController controller = TitanUITestController.Instance;

        public override void Initialize()
        {
            CommonBase.RemoteAddress = controller.GetLocalAddress();
        }
        /// <inheritdoc />
        public override void Action()
        {
            string textContent = String.Empty;
            try
            {
                TitanHomePage.TitleHomePage.WaitUntilExistent(20);
                textContent =  TitanHomePage.TitleHomePage.GetAttribute("label");
            }
             catch (Exception ex)
            {
                Log.WriteError("my exception: " + ex);
            }
            Assert.IsTrue(textContent == TitanTestConstants.ProductTitle);
        }
    }
}