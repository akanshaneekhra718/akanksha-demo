﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.Common.TestModule;
public class SendControlRequestToWorkflowController : TestStep
{
    public override string Description => "Step for One Client Degraded";
    [TestStepParameter(DisplayName = "ControlCommand")]
    public string ControlCommand { get; set; }
    [TestStepParameter(DisplayName = "TimePeriod")]
    public string TimePeriod { get; set; }
    readonly TitanUITestController myController = TitanUITestController.Instance;
    readonly VitalSignTestModule myVitalSignTestModule = new VitalSignTestModule();

    public override void Initialize()
    {
        CommonBase.RemoteAddress = myController.GetLocalAddress();
        myVitalSignTestModule.InjectLogger(Log);
        
    }

    /// <inheritdoc />
    public override void Action()
    {
        
        if (string.IsNullOrEmpty(ControlCommand) || string.IsNullOrEmpty(TimePeriod))
        {
            Assert.Fail($"value for ControlCommand: {ControlCommand} or TimePeriod : {TimePeriod} is not given");
            return;
        }
        Thread.Sleep(5000);
        Assert.IsTrue(myVitalSignTestModule.SendTestMessage(ControlCommand, int.Parse(TimePeriod), TestTargets.WorkflowController));
    }
}
