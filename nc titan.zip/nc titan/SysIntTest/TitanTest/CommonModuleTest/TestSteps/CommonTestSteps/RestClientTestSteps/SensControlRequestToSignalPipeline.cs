﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.Common.TestModule;

public class SensControlRequestToSignalPipeline : TestStep
{
    public override string Description => "Step to Network Error Misbehaviour";
    [TestStepParameter(DisplayName = "ControlCommand")]
    public string ControlCommand { get; set; }
    [TestStepParameter(DisplayName = "TimePeriod")]
    public string TimePeriod { get; set; }

    readonly TitanUITestController myController = TitanUITestController.Instance;
    readonly VitalSignTestModule myVitalSignTestModule = new VitalSignTestModule();

    public override void Initialize()
    {
        CommonBase.RemoteAddress = myController.GetLocalAddress();
        myVitalSignTestModule.InjectLogger(Log);
    }

    /// <inheritdoc />
    public override void Action()
    {
        if (String.IsNullOrEmpty(ControlCommand) || String.IsNullOrEmpty(TimePeriod))
        {
            Assert.Fail("value for ControlCommand and TimePeriod is not given");
            return;
        }
        Assert.IsTrue(myVitalSignTestModule.SendTestMessage(ControlCommand, int.Parse(TimePeriod), TestTargets.SignalPipeline));
    }
}
