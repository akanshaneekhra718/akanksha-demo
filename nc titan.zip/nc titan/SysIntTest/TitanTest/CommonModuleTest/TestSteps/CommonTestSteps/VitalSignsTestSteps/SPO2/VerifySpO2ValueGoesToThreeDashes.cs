﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.Common.TestModule
{
    public class VerifySpO2ValueGoesToThreeDashes : TestStep
    {
        public override string Description => "Test steps to Verify SpO2 Value Goes to Three Dashes";
        [TestStepParameter(DisplayName = "HR List")]
        public string SpO2Value { get; set; }
        [TestStepParameter(DisplayName = "System Type")]
        public string ExpSystemType { get; set; }

        readonly TitanUITestController myController = TitanUITestController.Instance;

        public override void Initialize()
        {
            if (ExpSystemType == TitanTestConstants.ExamRoom)
            {
                CommonBase.RemoteAddress = myController.GetLocalAddress();
            }
            else if (ExpSystemType == TitanTestConstants.ControlRoom)
            {
                CommonBase.RemoteAddress = myController.GetRemoteAddress();
            }
            else
            {
                CommonBase.RemoteAddress = myController.GetLocalAddress();
            }
        }

        /// <inheritdoc />
        public override void Action()
        {
            if (string.IsNullOrEmpty(SpO2Value))
            {
                Assert.Fail("SpO2 value is Null Or Empty" + SpO2Value);
                return;
            }
            Assert.IsTrue(myController.VerifySpO2ValueIsPresent(SpO2Value));
            
        }       
    }
}