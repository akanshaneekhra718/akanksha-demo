﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.Common.TestModule
{
    public class VerifyVitalValueIsThreeDashes : TestStep
    {
        [TestStepParameter(DisplayName = "Vital Values")]
        public string VitalValue { get; set; }
        [TestStepParameter(DisplayName = "System Type")]
        public string ExpSystemType { get; set; }
        public override string Description => "Test steps to Verify SpO2 Value Goes to Three Dashes";
        readonly TitanUITestController myController = TitanUITestController.Instance;


        /// <inheritdoc />
        public override void Action()
        {
            
            if (string.IsNullOrEmpty(ExpSystemType))
            {
                CommonBase.RemoteAddress = myController.GetLocalAddress();
                Assert.Fail("ExpSystemType is Empty" + ExpSystemType);
                return;
            }

            if (string.IsNullOrEmpty(VitalValue))
            {
                Assert.Fail("Vital value is Empty" + VitalValue);
                return;
            }

            SystemType systemType = (ExpSystemType.ToLower() == "exam") ? SystemType.ExamRoom : SystemType.ControlRoom;


            switch (systemType)
            {
                case SystemType.ExamRoom:
                    CommonBase.RemoteAddress = myController.GetLocalAddress();
                    Assert.IsTrue(myController.VerifyVitalSignParameterValueIsPresent(VitalSignsType.HR, VitalValue));
                    Assert.IsTrue(myController.VerifyVitalSignParameterValueIsPresent(VitalSignsType.SpO2, VitalValue));
                    break;
                case SystemType.ControlRoom:
                    CommonBase.RemoteAddress = myController.GetRemoteAddress();
                    Thread.Sleep(3000);
                    Assert.IsTrue(myController.VerifyVitalSignParameterValueIsPresent(VitalSignsType.HR, VitalValue));
                    Assert.IsTrue(myController.VerifyVitalSignParameterValueIsPresent(VitalSignsType.SpO2, VitalValue));
                    break;
                default:
                    Log.WriteInfo("Defined System is not the correct system"+ExpSystemType);
                    break;
            }
        }
    }
}