//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.Common.TestModule;

public class VerifyVitalSignsNotDisplayed : TestStep
{
    public override string Description => "Verify Vital Signs Not Displayed";
    /// <inheritdoc />
    public override void Action()
    {
      Assert.IsFalse(TitanHomePage.HeartRateValue.Visible);
    }
}