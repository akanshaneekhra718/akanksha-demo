﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.Common.TestModule
{
    public class VerifyHRValueGoesToThreeDashes : TestStep
    {
        public override string Description => "Test steps to Verify HR Value Goes to Three Dashes";
        
        [TestStepParameter(DisplayName = "HR Value")]
        public string HRValue { get; set; }
        [TestStepParameter(DisplayName = "System Type")]
        public string ExpSystemType { get; set; }
        readonly TitanUITestController myController = TitanUITestController.Instance;


        public override void Initialize()
        {
            myController.InjectLogger(Log);
            if (ExpSystemType == TitanTestConstants.ExamRoom)
            {
                CommonBase.RemoteAddress = myController.GetLocalAddress();
            }
            else if (ExpSystemType == TitanTestConstants.ControlRoom)
            {
                CommonBase.RemoteAddress = myController.GetRemoteAddress();
            }
            else
            {
                CommonBase.RemoteAddress = myController.GetLocalAddress();
            }
        }

        /// <inheritdoc />
        public override void Action()
        {
            if (string.IsNullOrEmpty(HRValue))
            {
                Assert.Fail("HR value is Null Or Empty"+ HRValue);
                return;
            }
            Assert.IsTrue(myController.VerifyHRValueIsPresent(HRValue));           
        }       
    }
}