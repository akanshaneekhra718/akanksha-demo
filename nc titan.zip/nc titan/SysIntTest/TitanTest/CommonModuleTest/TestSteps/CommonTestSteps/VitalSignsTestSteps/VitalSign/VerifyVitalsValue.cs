﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.Common.TestModule;

public class VerifyVitalsValue : TestStep
{
    public override string Description => "Test steps to Verify Vital Values";
    [TestStepParameter(DisplayName = "System Type")]
    public string ExpSystemType { get; set; }

    readonly TitanUITestController myController = TitanUITestController.Instance;

    /// <inheritdoc />
    public override void Action()
    {
        SystemType systemType = (ExpSystemType == "Exam" ? SystemType.ExamRoom : SystemType.ControlRoom);
        switch (systemType)
        {
            case SystemType.ExamRoom:
                CommonBase.RemoteAddress = myController.GetLocalAddress();
                VerifyVitalValue();
                break;
            case SystemType.ControlRoom:
                CommonBase.RemoteAddress = myController.GetRemoteAddress();
                VerifyVitalValue();
                break;
            default:
                Log.WriteInfo("Defined System is not the correct system"+ExpSystemType);
                Assert.IsFalse(true);
                break;
        }
    }

    private void VerifyVitalValue()
    {
        TitanHomePage.HeartRateValue.WaitUntilVisible(30);
        Assert.IsFalse(myController.VerifyVitalValue(VitalSignsType.HR));
        Assert.IsFalse(myController.VerifyVitalValue(VitalSignsType.SpO2));
    }
}