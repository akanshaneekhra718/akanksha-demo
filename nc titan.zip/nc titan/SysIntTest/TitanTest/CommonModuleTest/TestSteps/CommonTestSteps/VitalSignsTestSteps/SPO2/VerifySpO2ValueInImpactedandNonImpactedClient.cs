﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.Common.TestModule;

public class VerifySpO2ValueInImpactedandNonImpactedClient : TestStep
{
    public override string Description => "Step for One Client Degraded";
    [TestStepParameter(DisplayName = "HR Value")]
    public string SpO2Value { get; set; }
    [TestStepParameter(DisplayName = "System Type")]
    public string mySystemType { get; set; }
    [TestStepParameter(DisplayName = "Impacted Type")]
    public string ImpactedSystem { get; set; }
    [TestStepParameter(DisplayName = "nonImpacted Type")]
    public string NonImpactedSystem { get; set; }
    
    readonly TitanUITestController myController = TitanUITestController.Instance;

    /// <inheritdoc />
    public override void Action()
    {
        if (string.IsNullOrEmpty(SpO2Value))
        {
            Assert.Fail("Sp02 value is Null Or Empty" + SpO2Value);
            return;
        }
        if (NonImpactedSystem.Equals(TitanTestConstants.ExamRoom))
        {
            CommonBase.RemoteAddress = myController.GetLocalAddress();
            Assert.IsFalse(myController.VerifyVitalValue(VitalSignsType.SpO2));
        }
        
        if (ImpactedSystem.Equals(TitanTestConstants.ControlRoom))
        {
            CommonBase.RemoteAddress = myController.GetRemoteAddress();
            Assert.IsTrue(myController.VerifySpO2ValueIsPresent(SpO2Value));
        }
    }
}
