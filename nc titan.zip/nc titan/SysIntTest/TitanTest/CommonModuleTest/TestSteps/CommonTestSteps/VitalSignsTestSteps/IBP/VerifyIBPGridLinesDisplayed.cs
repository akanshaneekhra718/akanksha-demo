﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>

namespace TitanTest.Common.TestModule
{
    public class VerifyIBPGridLinesDisplayed : TestStep
    {
        public override string Description => "Test steps to Verify IBP GridLines Displayed";

        readonly TitanUITestController myController = TitanUITestController.Instance;
        readonly VitalSignTestModule myVitalSignTestModule = VitalSignTestModule.Instance;
        [TestStepParameter(DisplayName = "Number of GridLine")]
        public int ExpectedNumberOfGridlInes { get; set; }

        public override void Initialize()
        {
            myController.InjectLogger(Log);
            CommonBase.RemoteAddress = myController.GetLocalAddress();
        }

        /// <inheritdoc />
        public override void Action()
        {
            myVitalSignTestModule.InjectLogger(Log);
            Assert.IsTrue(myVitalSignTestModule.VerifyIBPGridLinesDisplayed(ExpectedNumberOfGridlInes));
        }
    }
}