﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.Common.TestModule
{
    public class ContinousHR : TestStep
    {
        readonly TitanUITestController controller = TitanUITestController.Instance;
        [TestStepParameter(DisplayName = "HR List")]
        public string HRList { get; set; }
        [TestStepParameter(DisplayName = "System Type")]
        public string ExpSystemType { get; set; }

        public override string Description => "Test steps to Browser Is launche dAnd Navigated To Titan URL";

        public override void Initialize()
        {
            if (ExpSystemType == "Exam")
            {

                CommonBase.RemoteAddress = controller.GetLocalAddress();
            }
            else if (ExpSystemType == "Control")
            {
                CommonBase.RemoteAddress = controller.GetRemoteAddress();
            }
            else
            {
                CommonBase.RemoteAddress = controller.GetLocalAddress();
            }
        }

        /// <inheritdoc />
        public override void Action()
        {
            if (String.IsNullOrEmpty(HRList))
            {
                Assert.Fail("value for HR List is not given"+HRList);
                return;
            }
            Assert.IsTrue(controller.VerifyContinuosVitalSignValueList(HRList, VitalSignsType.HR));
        }
    }
}