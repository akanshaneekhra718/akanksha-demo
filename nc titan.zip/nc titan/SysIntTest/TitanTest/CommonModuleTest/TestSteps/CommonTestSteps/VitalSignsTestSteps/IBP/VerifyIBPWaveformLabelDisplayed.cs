﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>

namespace TitanTest.Common.TestModule
{
    public class VerifyIBPWaveformLabelDisplayed : TestStep
    {
        public override string Description => "Test steps to Verify IBP Waveform Label Displayed";

        readonly TitanUITestController myController = TitanUITestController.Instance;
        readonly VitalSignTestModule myVitalSignTestModule = VitalSignTestModule.Instance;
        [TestStepParameter(DisplayName = "Waveform Label")]
        public string IBPWaveformLabel { get; set; }

        public override void Initialize()
        {
            CommonBase.RemoteAddress = myController.GetLocalAddress();
        }

        /// <inheritdoc />
        public override void Action()
        {
            myVitalSignTestModule.InjectLogger(Log);
            Assert.IsTrue(myVitalSignTestModule.VerifyIBPWavelformLabelsDisplayed(IBPWaveformLabel));
        }
    }
}