﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.Common.TestModule;

public class VerifyHRValueInImpactedandNonImpactedClient : TestStep
{
    public override string Description => "Step for One Client Degraded";
    [TestStepParameter(DisplayName = "HR Value")]
    public string HRValue { get; set; }
    [TestStepParameter(DisplayName = "Impacted Type")]
    public string ImpactedSystem { get; set; }
    [TestStepParameter(DisplayName = "nonImpacted Type")]
    public string NonImpactedSystem { get; set; }
    readonly TitanUITestController myController = TitanUITestController.Instance;

    /// <inheritdoc />
    public override void Action()
    {
        if (string.IsNullOrEmpty(HRValue))
        {
            Assert.Fail("HR value is Null Or Empty" + HRValue);
            return;
        }

        if (NonImpactedSystem.Equals(TitanTestConstants.ExamRoom))
        {
            try
            {

                CommonBase.RemoteAddress = myController.GetLocalAddress();
                Assert.IsFalse(myController.VerifyVitalValue(VitalSignsType.HR));
            }
            catch (Exception ex)
            {

                Assert.Fail("Failed in exam room  " + ex.Message);
            }
        }

        if (ImpactedSystem.Equals(TitanTestConstants.ControlRoom))
        {
            try
            {

                CommonBase.RemoteAddress = myController.GetRemoteAddress();
                //Thread.Sleep(5000);
                Assert.IsTrue(myController.VerifyHRValueIsPresent(HRValue));

            }
            catch (Exception ex)
            {

                Assert.Fail("Failed in control room  " + ex.Message);
            }
        }
    }
}
