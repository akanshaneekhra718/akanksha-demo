﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.Common.TestModule
{
    public class ApolloSimulatorIsStartedWithCsvFile : TestStep
    {
        readonly TitanUITestController controller = TitanUITestController.Instance;
        public override string Description => "Apollo Simulator is started";

        [TestStepParameter(DisplayName = "Raw file")]
        public string CsvFile { get; set; }

        readonly ApolloSimulatorController apolloSimulatorController = ApolloSimulatorController.Instance;
        public override void Initialize()
        {
            CommonBase.RemoteAddress = controller.GetLocalAddress();
        }
        /// <inheritdoc />
        public override void Action()
        {
            
            if (string.IsNullOrEmpty(CsvFile))
            {
                Assert.Fail("CSV File is not given" + CsvFile);
                return;
            }

            Assert.IsTrue(apolloSimulatorController.StartApolloSimulatorWithApolloCsvFile(CsvFile));

        }
    }
}