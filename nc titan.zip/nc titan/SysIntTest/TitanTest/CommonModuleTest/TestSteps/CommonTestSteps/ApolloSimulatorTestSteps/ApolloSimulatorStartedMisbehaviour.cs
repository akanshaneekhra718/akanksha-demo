//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>

namespace TitanTest.Common.TestModule;
public class ApolloSimulatorStartedMisbehaviour : TestStep
{
    public override string Description => "Start Apollo simulator with misbehaviour";
    [TestStepParameter(DisplayName = "Misbehaviour")]
    public string Misbehaviour { get; set; }

    readonly TitanUITestController myController = TitanUITestController.Instance;
    readonly ApolloSimulatorController myApolloSimulatorController = ApolloSimulatorController.Instance;
    public override void Initialize()
    {
        CommonBase.RemoteAddress = myController.GetLocalAddress();
    }
    public override void Precondition()
    {
        myApolloSimulatorController.KillPreexistingApolloSimulator();
    }

    /// <inheritdoc />
    public override void Action()
    {
        Assert.IsTrue(myApolloSimulatorController.StartApolloSimulator(int.Parse(TitanTestConstants.TCPPort), Misbehaviour));
    }
}