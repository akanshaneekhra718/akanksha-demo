﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.Common.TestModule
{
    public class ApolloSimulatorIsStartedWithRawFile : TestStep
    {
        readonly TitanUITestController controller = TitanUITestController.Instance;
        public override string Description => "Apollo Simulator is started";

        [TestStepParameter(DisplayName = "Raw file")]
        public string RawFile { get; set; }

        readonly ApolloSimulatorController apolloSimulatorController = ApolloSimulatorController.Instance;
        public override void Initialize()
        {
            CommonBase.RemoteAddress = controller.GetLocalAddress();
        }
        /// <inheritdoc />
        public override void Action()
        {
            if (string.IsNullOrEmpty(RawFile))
            {
                Assert.Fail("RawFile is not given" + RawFile);
                return;
            }
            Assert.IsTrue(apolloSimulatorController.StartApolloSimulatorWithApolloRawFile(RawFile));
        }
    }
}