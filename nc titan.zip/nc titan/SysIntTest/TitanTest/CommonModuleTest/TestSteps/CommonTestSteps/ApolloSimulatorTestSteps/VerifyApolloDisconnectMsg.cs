//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.Common.TestModule;

public class VerifyApolloDisconnectMsg : TestStep
{
    public override string Description => "Verify Apollo Disconnect Msg";
    /// <inheritdoc />
    public override void Action()
    {
        string apolloDisconnectMsg = string.Empty;
        try
        {

        TitanHomePage.StaticPage.WaitUntilVisible(10);
        apolloDisconnectMsg=TitanHomePage.StaticPage.GetAttribute("label");
        }
        catch (Exception ex)
        {
            Log.WriteError("Static page is not displayed" + ex);
        }
        Assert.AreEqual(apolloDisconnectMsg,TitanTestConstants.ApolloDisconnectMsg);
    }
}
