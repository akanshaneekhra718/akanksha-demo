﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>

namespace TitanTest.Common.TestModule;

public class ApolloSimulatorIsStarted : TestStep
{
    public override string Description => "Apollo Simulator is started";
    readonly TitanUITestController myController = TitanUITestController.Instance;
    readonly ApolloSimulatorController myApolloSimulatorController = ApolloSimulatorController.Instance;

    public override void Initialize()
    {
        CommonBase.RemoteAddress = myController.GetLocalAddress();
    }
    /// <inheritdoc />
    public override void Action()
    {
        Assert.IsTrue(myApolloSimulatorController.StartApolloSimulator());
    }
}