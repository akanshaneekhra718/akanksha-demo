namespace TitanTest.Common.TestModule;
public class CloseSettingsDialog:TestStep
{
    public override string Description => "Close settings dialog";
   /// <inheritdoc />
    public override void Action()
    {
      BaseContracts.MouseMoveAndClick(ConfigurationPage.CloselButton);
    }
}