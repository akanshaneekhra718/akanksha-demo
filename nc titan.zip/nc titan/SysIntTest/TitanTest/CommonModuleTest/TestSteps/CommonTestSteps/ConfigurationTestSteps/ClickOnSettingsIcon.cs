//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.Common.TestModule;

public class ClickOnSettingsIcon : TestStep
{
    public override string Description => "Click on settings icon";
    /// <inheritdoc />
    public override void Action()
    {
        BaseContracts.MouseMoveAndClick(TitanHomePage.SettingsIcon);
    }
}