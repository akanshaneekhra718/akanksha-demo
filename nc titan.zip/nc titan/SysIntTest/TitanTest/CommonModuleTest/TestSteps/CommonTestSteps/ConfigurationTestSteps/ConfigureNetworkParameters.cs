//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.Common.TestModule;
public class ConfigureNetworkParameters:TestStep
{
    public override string Description => "Configure Network Parameters";
    [TestStepParameter(DisplayName = "Hostname")]
    public string Hostname { get; set; }
    [TestStepParameter(DisplayName = "TCPPortNumber")]
    public int? TCPPortNumber { get; set; }
    [TestStepParameter(DisplayName = "UDPPortNumber")]
    public int? UDPPortNumber { get; set; }

    readonly TitanUITestController myTitanUITestController=TitanUITestController.Instance;
   /// <inheritdoc />
    public override void Action()
    {
      myTitanUITestController.InjectLogger(Log);
      if(!string.IsNullOrEmpty(Hostname) && TCPPortNumber!=null && UDPPortNumber!=null)
      {
        ConfigurationPage.HostName.WaitUntilVisible(30);
        ConfigurationPage.HostName.BringIntoView();
        if(Hostname.Trim().ToUpper().Equals("HOST.DOCKER.INTERNAL"))
        {
          Hostname=String.IsNullOrEmpty(myTitanUITestController.GetSystemIPAddress())?throw new Exception("GetIPAddress returned empty string"):myTitanUITestController.GetSystemIPAddress();
        }

        //entering value into Hostname field
        BaseContracts.MouseMoveAndClick(ConfigurationPage.HostName);
        ConfigurationPage.HostName.Text=Hostname;
    
        //entering value into TCP Port field
        BaseContracts.MouseMoveAndClick(ConfigurationPage.TCPPort);
        ConfigurationPage.TCPPort.Text=TCPPortNumber.ToString();

        //entering value into UDP Port field
        BaseContracts.MouseMoveAndClick(ConfigurationPage.UDPPort);
        ConfigurationPage.UDPPort.Text=UDPPortNumber.ToString();
        
        BaseContracts.MouseMoveAndClick(ConfigurationPage.HostName);
        BaseContracts.MouseMoveAndClick(ConfigurationPage.UDPPort);
      }
      else
      {
        throw new ArgumentNullException("Passed network parameters Hostname,TCP port,UDP port are empty or null");
      }
    }
}