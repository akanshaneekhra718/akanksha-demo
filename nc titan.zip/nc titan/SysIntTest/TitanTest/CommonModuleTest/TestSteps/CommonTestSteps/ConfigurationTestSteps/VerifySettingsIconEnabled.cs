//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.Common.TestModule;
public class VerifySettingsIconEnabled:TestStep
{
    public override string Description => "Verify settings Icon enabled";
   /// <inheritdoc />
    public override void Action()
    {
      TitanHomePage.SettingsIcon.WaitUntilEnabled(10);
      Assert.IsTrue(TitanHomePage.SettingsIcon.Enabled);
    }
}