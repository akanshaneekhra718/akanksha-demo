//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.Common.TestModule;
public class ClickOnApplyButton:TestStep
{
    public override string Description => "Apply Button Click";
   /// <inheritdoc />
    public override void Action()
    {
      BaseContracts.MouseMoveAndClick(ConfigurationPage.ApplyButton);
    }
}