//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.Common.TestModule;
public class ClickOnEditButton:TestStep
{
    public override string Description => "Edit Button Click";
   /// <inheritdoc />
    public override void Action()
    {
      BaseContracts.MouseMoveAndClick(ConfigurationPage.EditButton);
    }
}