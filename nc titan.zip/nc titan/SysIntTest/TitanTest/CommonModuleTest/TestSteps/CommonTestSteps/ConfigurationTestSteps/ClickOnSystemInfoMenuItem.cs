//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.Common.TestModule;
public class ClickOnSystemInfoMenuItem:TestStep
{
    public override string Description => "Click on System Information Menu Item";
   /// <inheritdoc />
    public override void Action()
    {
      BaseContracts.MouseMoveAndClick(ConfigurationPage.SystemInformationMenuItem);
    }
}