//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.Common.TestModule;

public class ClickOnNetworkMenuItem : TestStep
{
    public override string Description => "Click on network menu item";
    /// <inheritdoc />
    public override void Action()
    {
      BaseContracts.MouseMoveAndClick(ConfigurationPage.NetworkMenuItem);
    }
}