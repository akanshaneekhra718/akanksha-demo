﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.Common.TestModule
{
    public class ClickOnDeviceAndUserManagementMenuItem:TestStep
    {
        public override string Description => "Click on Device and User Management menu item";
        /// <inheritdoc />
        public override void Action()
        {
            BaseContracts.MouseClickAndWait(ConfigurationPage.DeviceAndUserManagement);
            ConfigurationPage.TrustedDeviceDialog.WaitUntilVisible(2);
        }
    }
}
