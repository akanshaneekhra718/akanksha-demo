﻿namespace TitanTest.Common.TestModule;
public class TitanContainerAction : TestStep
{
    public override string Description => "Titan container Action performed";

    [TestStepParameter(DisplayName = "Actions")]
    public string ContainerActions { get; set; } 
    
    readonly TitanContainerController myTitanContainerController = TitanContainerController.Instance;

    public override void Action()
    {
        if (String.IsNullOrEmpty(ContainerActions))
        {
            Assert.Fail("Container Actions are not defined");
            return;
        }

        switch (ContainerActions)
        {
            case "started":
                Assert.IsTrue(myTitanContainerController.StartStopTitanContainer(ActionType.start));
                break;
            case "stopped":
                Assert.IsTrue(myTitanContainerController.StartStopTitanContainer(ActionType.stop));
                break;
            case "restarted":
                Assert.IsTrue(myTitanContainerController.StartStopTitanContainer(ActionType.restart));
                break;
            default:
                Assert.Fail("Action is not defined");
                break;
        }
    }
}
