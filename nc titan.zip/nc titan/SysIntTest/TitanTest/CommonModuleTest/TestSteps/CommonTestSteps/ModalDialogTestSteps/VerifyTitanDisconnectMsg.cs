﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.Common.TestModule;

public class VerifyTitanDisconnectMsg : TestStep
{
    public override string Description => "Verify Titan Disconnect Msg";
    /// <inheritdoc />
    public override void Action()
    {
        TitanHomePage.StaticPage.WaitUntilVisible(10);
        String apolloDisconnectMsg = TitanHomePage.StaticPage.GetAttribute("label");
        Assert.AreEqual(apolloDisconnectMsg, TitanTestConstants.TitanDisconnectMsg);
    }
}