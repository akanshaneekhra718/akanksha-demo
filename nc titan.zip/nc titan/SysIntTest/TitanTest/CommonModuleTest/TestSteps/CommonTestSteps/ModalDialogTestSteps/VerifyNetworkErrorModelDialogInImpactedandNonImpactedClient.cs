﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>

namespace TitanTest.Common.TestModule;

public class VerifyNetworkErrorModelDialogInImpactedandNonImpactedClient : TestStep
{
    public override string Description => "Step to verify Network Error Model Dialogue";
    [TestStepParameter(DisplayName = "Network Error Model Dialogue")]
    public string NetworkErrorModalDialogLabel { get; set; }
    [TestStepParameter(DisplayName = "Icon Type")]
    public string IconType { get; set; }    
    [TestStepParameter(DisplayName = "Network Error Modal Dialog Text")]
    public string ErrorText { get; set; }
    [TestStepParameter(DisplayName = "Impacted Type")]
    public string ImpactedSystem { get; set; }
    [TestStepParameter(DisplayName = "nonImpacted Type")]
    public string NonImpactedSystem { get; set; }
    readonly TitanUITestController myController = TitanUITestController.Instance;
    readonly VitalSignTestModule myVitalSignTestModule = VitalSignTestModule.Instance;
    public override void Initialize()
    {
        CommonBase.RemoteAddress = myController.GetLocalAddress();
    }
  
    /// <inheritdoc />
    public override void Action()
    {
        myController.InjectLogger(Log);

        if (string.IsNullOrEmpty(NetworkErrorModalDialogLabel) || string.IsNullOrEmpty(IconType) || string.IsNullOrEmpty(ErrorText))
        {
            Assert.Fail("value for NetworkErrorModalDialogLabel ,IconType and ErrorText is not given");
            return;
        }
        if (NonImpactedSystem.Equals(TitanTestConstants.ExamRoom))
        {
            CommonBase.RemoteAddress = myController.GetLocalAddress();
            
            if (!TitanHomePage.NetworkErrorModelDialogue.IsExisting)
            {
                bool IsModelDialogVisible = TitanHomePage.NetworkErrorModelDialogue.Visible;
                Assert.IsFalse(IsModelDialogVisible);
            }
        }
        if (ImpactedSystem.Equals(TitanTestConstants.ControlRoom))
        {
            CommonBase.RemoteAddress = myController.GetRemoteAddress();
            Assert.IsTrue(myVitalSignTestModule.VerifyNetworkErrorModalDialog(NetworkErrorModalDialogLabel, IconType, ErrorText));
        }
    } 
}