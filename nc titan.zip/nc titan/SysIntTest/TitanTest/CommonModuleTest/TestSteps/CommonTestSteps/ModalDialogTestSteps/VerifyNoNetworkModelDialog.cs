﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.Common.TestModule;

public class VerifyNoNetworkModelDialog : TestStep
{
    public override string Description => "Step for Verify NoNetwork Model Dialog";
    readonly TitanUITestController myController = TitanUITestController.Instance;

    public override void Initialize()
    {
        CommonBase.RemoteAddress = myController.GetLocalAddress();
    }

    /// <inheritdoc />
    public override void Action()
    {       
        if (!TitanHomePage.NetworkErrorModelDialogue.IsExisting)
        {
            bool IsModelDialogVisible = TitanHomePage.NetworkErrorModelDialogue.Visible;
            Assert.IsFalse(IsModelDialogVisible);
        }
    }
}
