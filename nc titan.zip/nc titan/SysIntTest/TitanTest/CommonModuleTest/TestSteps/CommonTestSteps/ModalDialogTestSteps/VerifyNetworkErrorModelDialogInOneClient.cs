﻿//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>

namespace TitanTest.Common.TestModule;

public class VerifyNetworkErrorModelDialogInOneClient : TestStep
             
{
    public override string Description => "Step to verify Network Error Model Dialogue";
    [TestStepParameter(DisplayName = "Network Error Model Dialogue")]
    public string NetworkErrorModalDialogLabel { get; set; }
    [TestStepParameter(DisplayName = "Icon Type")]
    public string IconType { get; set; }    
    [TestStepParameter(DisplayName = "Network Error Modal Dialog Text")]
    public string ErrorText { get; set; }
    [TestStepParameter(DisplayName = "Impacted Type")]
    public string ImpactedSystem { get; set; }
    readonly TitanUITestController myController = TitanUITestController.Instance;
    readonly VitalSignTestModule myVitalSignTestModule = VitalSignTestModule.Instance;
    public override void Initialize()
    {
        CommonBase.RemoteAddress = myController.GetLocalAddress();
        myVitalSignTestModule.InjectLogger(Log);
    }

    /// <inheritdoc />
    public override void Action()
    {
        if (string.IsNullOrEmpty(NetworkErrorModalDialogLabel) || string.IsNullOrEmpty(IconType) || string.IsNullOrEmpty(ErrorText))
        {
            Assert.Fail("value for NetworkErrorModalDialogLabel ,IconType and ErrorText is not given");
            return;
        }
        if (ImpactedSystem.Equals(TitanTestConstants.ExamRoom))
        {
            CommonBase.RemoteAddress = myController.GetLocalAddress();
            Assert.IsTrue(myVitalSignTestModule.VerifyNetworkErrorModalDialog(NetworkErrorModalDialogLabel, IconType, ErrorText));
        }
    }
}