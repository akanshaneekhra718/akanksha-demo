//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.Common.TestModule;

public class BaseContracts
{
 // Below method perform move to element and mouse click on for passed webElement
  public static void MouseMoveAndClick(IControl webElement)
  {
        webElement.WaitUntilVisible(30);
        webElement.WaitUntilEnabled(30);
        Mouse.Move(webElement.ClickablePoint, 1);
     // Below sleeps is given to wait till mouse completely moved to clickable point 
     //and then click and wait for some time before any other action.
     Thread.Sleep(1000);
     Mouse.Click();
     Thread.Sleep(1000);
    }

    public static void MouseClickAndWait(IControl webElement)
    {
        webElement.WaitUntilVisible(30);
        webElement.WaitUntilEnabled(30);
        webElement.MouseClick();
        //and then click and wait for some time before any other action.
        Thread.Sleep(1000);
    }

} 

