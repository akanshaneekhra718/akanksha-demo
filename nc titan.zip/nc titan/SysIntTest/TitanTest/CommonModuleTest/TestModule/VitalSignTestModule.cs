﻿// <copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.Common.TestModule
{
    public sealed class VitalSignTestModule
    {
        private Xpta.Sita.TestSteps.ILogger myLogger;
        private static readonly object myLockObj = new object();
        private static VitalSignTestModule myInstance = null;
        private readonly TestRestClient myTestRestClient;
        private const double myEndTime = 20;
        public void InjectLogger(Xpta.Sita.TestSteps.ILogger logger)
        {
            myLogger = logger;
        }
        public static VitalSignTestModule Instance
        {
            get
            {
                lock (myLockObj)
                {
                    if (myInstance == null)
                    {
                        myInstance = new VitalSignTestModule();
                    }
                    return myInstance;
                }
            }
        }
        public VitalSignTestModule()
        {
            myTestRestClient = new TestRestClient();
        }

        public bool VerifyNetworkErrorModalDialog(string ExpNetworkDialogLabelText, string ExpIconType, string ExpNetworkErrorModalDialogText)
        {
            bool isFound = false;
            try
            {
                TitanHomePage.NetworkErrorModelDialogue.WaitUntilVisible(20);
                string actDialogLabelText = TitanHomePage.NetworkErrorModelDialogue.GetAttribute("label");
                string actIconType = TitanHomePage.NetworkErrorModelDialogue.GetAttribute("type");
                string actNetworkErrorModalDialogText = TitanHomePage.NetworkErrorModelDialogue.ExecuteScript<string>("return document.querySelector('#critical-messages').innerHTML").Trim();
                if (actDialogLabelText.Equals(ExpNetworkDialogLabelText) && actIconType.Equals(ExpIconType) && actNetworkErrorModalDialogText.Equals(ExpNetworkErrorModalDialogText))
                {
                    isFound = true;
                    myLogger?.WriteInfo($"Network Modal Dialog is Available with Label {actDialogLabelText} is displayed with {actIconType} with text as {actNetworkErrorModalDialogText} in the browser. Dialog Label expected is :{ExpNetworkDialogLabelText} with Icon Type as {ExpIconType} with Text as {ExpNetworkErrorModalDialogText}");
                    return isFound;
                }
                else
                {
                    myLogger?.WriteInfo($"Network Modal Dialog is not Available with Label{actDialogLabelText} is displayed with {actIconType} with text as {actNetworkErrorModalDialogText} in the browser. Dialog Label expected is :{ExpNetworkDialogLabelText} with Icon Type as {ExpIconType} with Text as {ExpNetworkErrorModalDialogText}");
                    myLogger?.WriteInfo("Some other display found in the browser. Having Version : " + actDialogLabelText);
                }
            }
            catch (Exception ex)
            {
                myLogger?.WriteError(ex.Message);
            }
            return isFound;
        }

        private ControlCommands ParseControlCommand(string control)
        {
            ControlCommands command;
            Enum.TryParse(control, out command);
            return command;
        }

        public bool SendTestMessage(string control, int timePeriod, TestTargets testTargets)
        {
            try
            {
                TestMessage myTestMessage = new TestMessage()
                {
                    CommandType = TestCommandType.Control,
                    Target = testTargets,
                    ControlCommand = ParseControlCommand(control),
                    TimePeriod = timePeriod
                };
                return myTestRestClient.SendRestRequest(myTestMessage, myTestMessage.Target).GetAwaiter().GetResult();
            }
            catch (Exception ex)
            {
                myLogger?.WriteError(ex.Message);
            }
            return false;
        }

        public bool VerifyIBPGridLinesDisplayed(int ExpectedNumberOfGridlInes)
        {
            int actNumberOFGridlInes = 0;
            for (int i = 0; i < 10; i++)
            {
                actNumberOFGridlInes = TitanHomePage.IBPGridLines.Count;
                Thread.Sleep(1000);
                myLogger.WriteInfo("act Number of GridlInes are" + actNumberOFGridlInes);
                if (actNumberOFGridlInes != 0)
                {
                    break;
                }
            }
            try
            {
                if (actNumberOFGridlInes == ExpectedNumberOfGridlInes)
                {
                    myLogger.WriteInfo($"Expected Number of IBP Gridlines dispalyed : {ExpectedNumberOfGridlInes} matches with Actual Number of Gridlines :{actNumberOFGridlInes} in Titan UI");
                    return true;
                }
                else
                {
                    myLogger.WriteError($"Expected Number of IBP Gridlines dispalyed : {ExpectedNumberOfGridlInes} does not match with Actual Number of Gridlines :{actNumberOFGridlInes} in Titan UI");
                }
            }
            catch (Exception ex)
            {
                myLogger.WriteError(ex.Message);
            }
            return false;
        }

        private bool VerifyMultipleLabelsDisplayedInTitanUI(string labelList, Collection<IChromeControl> actualLabelList)
        {
            int actLabelList = 0;
            for (int i = 0; i < 10; i++)
            {
                actLabelList = TitanHomePage.IBPWaveformsLabel.Count;
                Thread.Sleep(1000);
                myLogger.WriteInfo("act Number of IBP Waveforms Label are" + actLabelList);
                if (actLabelList != 0)
                {
                    break;
                }
            }
            try
            {
                List<string> expectedLabels = labelList.Split(',').ToList();
                List<string> actualLabels = actualLabelList.Select(x => x.InnerText).ToList();


                if (actualLabels.Count == 0)
                {
                    myLogger.WriteError("None of the label are found in UI is " + actualLabels.Count);
                    return false;
                }
                else
                {
                    IEnumerable<string> labelsNotFound = expectedLabels.Except(actualLabels);

                    if (labelsNotFound.ToList().Count != 0)
                    {
                        foreach (string label in labelsNotFound)
                        {
                            myLogger.WriteError("Label not found {0} in the Titan UI" + label);
                        }
                        return false;
                    }
                    else
                    {
                        myLogger.WriteInfo($"All expected Labels found in the Titan UI");
                        return true;
                    }
                }
            }

            catch (Exception ex)
            {
                myLogger.WriteError(ex.Message);
            }
            return false;
        }
        public bool VerifyIBPWavelformLabelsDisplayed(string expectedLabels) =>
      VerifyMultipleLabelsDisplayedInTitanUI(expectedLabels, TitanHomePage.IBPWaveformsLabel);
        public bool VerifyIBPGridLinesLabelsDisplayed(string expectedLabels) =>
      VerifyMultipleLabelsDisplayedInTitanUI(expectedLabels, TitanHomePage.IBPGridLineLabel);
    }
}
