//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.Common.TestModule;

public static class WebElementControl
{
    internal static T GetControl<T>(string selector) where T : IControl
    {
        string name = typeof(T).Name;
        if (typeof(T).IsInterface && name.StartsWith("I"))
        {
          name = name.Substring(1);
        }
        return BaseControl.CreateControl<T>(TitanTestConstants.DocumentXpath + $"/{name}[@Selector='{selector}']");
    }
}