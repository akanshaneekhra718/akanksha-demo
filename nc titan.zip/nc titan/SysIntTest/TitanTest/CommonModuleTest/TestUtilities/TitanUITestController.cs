//  <copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.Common.TestModule;
using ProcessStartInfo = Xpta.Sita.Spy.Plugins.ProcessHandler.ProcessStartInfo;
using Process = Xpta.Sita.Spy.Plugins.ProcessHandler.Process;

public enum VitalSignsType
{
    HR,
    SpO2
};

public enum SystemType
{
    ExamRoom,
    ControlRoom
};

public enum SelectedLanguage
{
    English,
    Deutsch,
    Svenska
};

public enum ControlRoomBrowser
{
    AddBrowser,
    RemoveBrowser,
};

public sealed class TitanUITestController
{
    private readonly bool IsSITMachine = false;
    private bool BrowserLaunchedInControlRoom = false;
    private static readonly object lockObj = new object();
    private static TitanUITestController instance = null;
    public Xpta.Sita.TestSteps.ILogger myLogger;
    private const int MaxRetryCountIfWebElementNotFound = 3;
    public void InjectLogger(Xpta.Sita.TestSteps.ILogger logger)
    {
        myLogger = logger;
    }
    public static TitanUITestController Instance
    {
        get
        {
            lock (lockObj)
            {
                if (instance == null)
                {
                    instance = new TitanUITestController();
                }
                return instance;
            }
        }
    }
    public TitanUITestController()
    {
        IsSITMachine = Environment.GetEnvironmentVariable("SystemIntegrationTestEnvironment") == "SIT_Machine_IP";
    }

    public string GetBrowserLocation()
    {
        if (File.Exists(TitanTestConstants.x64Path))
        {
            return TitanTestConstants.x64Path;
        }
        return TitanTestConstants.x86Path;
    }

    /// <summary>
    /// Below block of code returns IP of system in which code is running
    /// </summary>
    public string GetSystemIPAddress()
    {
        string hostName = Dns.GetHostName();
        IPHostEntry hostEntry = Dns.GetHostEntry(hostName);
        IPAddress loopbackAddress = hostEntry.AddressList.FirstOrDefault(ip => ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork);
        if (loopbackAddress != null)
        {
            myLogger.WriteInfo("IPv4 loopback address: " + loopbackAddress.ToString());
            return loopbackAddress.ToString();
            //return "172.23.48.1";
        }
        else
        {
            myLogger.WriteError("IPv4 loopback address not found");
        }
        return string.Empty;
    }
    public bool BrowserIslaunchedAndNavigatedToTitanURL(string browserAdd)
    {
        try
        {
            if (OpenTitanUI(browserAdd))
            {
                TitanHomePage.SettingsIcon.WaitUntilVisible(20);
                return true;
            }
        }
        catch (Exception ex)
        {
            myLogger?.WriteError("Error caught while launching browser:: " + ex.Message);
        }
        return false;
    }
    public bool OpenTitanUI(string browserAdd)
    {
        try
        {
            string pageAddress = Environment.GetEnvironmentVariable("TITAN_WEBPAGE_ADDRESS") ?? TitanTestConstants.HostName;
            string pageLink = "http://" + pageAddress + ":" + TitanTestConstants.TitanPort.ToString();
            myLogger?.WriteInfo("Browser is launched and navigated to Titan URL :" + pageLink);
            var processStartInfo = new ProcessStartInfo
            {
                FileName = GetBrowserLocation(),
                Arguments = "--remote-debugging-port=9222 --hide-crash-restore-bubble --disable-infobars --start-maximized --new-window " + pageLink
            };
            Process.Start(browserAdd, processStartInfo);

            if (IsSITMachine && browserAdd.Equals(GetRemoteAddress()))
            {
                BrowserLaunchedInControlRoom = true;
            }

            return true;
        }
        catch (Exception ex)
        {
            myLogger?.WriteError("Error caught while launching browser:: " + ex.Message);
        }
        return false;
    }
    public bool VerifyHomepageIsVisibleWithParameterArea()
    {
        TitanHomePage.HeartRateValue.WaitUntilVisible(60);
        return true;
    }
    public string GetRemoteAddress()
    { //10.82.149.108  //172.16.254.141
        return IsSITMachine ? "net.tcp://172.16.254.141:55677" : "net.tcp://127.0.0.1:55677";
    }
    public string GetLocalAddress()
    { //10.82.148.199  //172.16.254.139
        return IsSITMachine ? "net.tcp://172.16.254.139:55677" : "net.tcp://127.0.0.1:55677";
    }
    bool IsTitanConfiguredToConnectApollo()
    {
        TitanHomePage.SettingsIcon.WaitUntilVisible(30.0);
        TitanHomePage.SettingsIcon.WaitUntilEnabled(30.0);
        TitanHomePage.SettingsIcon.MouseClick();
        bool isConfigured = GetSystemIPAddress().Equals(ConfigurationPage.HostName.GetAttribute("value"))
         && TitanTestConstants.TCPPort.Equals(ConfigurationPage.TCPPort.GetAttribute("value"))
         && TitanTestConstants.UDPPort.Equals(ConfigurationPage.UDPPort.GetAttribute("value"));
        myLogger?.WriteInfo("Apollo Configuration with Titan is already done");
        ConfigurationPage.CloselButton.WaitUntilEnabled(10.0);
        ConfigurationPage.CloselButton.MouseClick();
        return isConfigured;
    }
    public bool ConfigureTitanToConnectApollo()
    {
        bool isConfigured = false;
        if (IsTitanConfiguredToConnectApollo())
        {
            isConfigured = true;
        }
        while (!isConfigured)
        {
            try
            {
                TitanHomePage.SettingsIcon.WaitUntilVisible(10.0);
                TitanHomePage.SettingsIcon.WaitUntilEnabled(10.0);

                Mouse.Click(new System.Drawing.Point(TitanHomePage.SettingsIcon.BoundingRectangle.X + 1,
                    TitanHomePage.SettingsIcon.BoundingRectangle.Y + 1));

                ConfigurationPage.EditButton.WaitUntilVisible(10.0);
                ConfigurationPage.EditButton.WaitUntilEnabled(10.0);
                Mouse.Click(new System.Drawing.Point(ConfigurationPage.EditButton.BoundingRectangle.X + 10,
                   ConfigurationPage.EditButton.BoundingRectangle.Y + 10));

                Mouse.Click(new System.Drawing.Point(ConfigurationPage.HostName.BoundingRectangle.X + 10,
                ConfigurationPage.HostName.BoundingRectangle.Y + 10));
                ConfigurationPage.HostName.Text = GetSystemIPAddress();
                Thread.Sleep(1000);

                Mouse.Click(new System.Drawing.Point(ConfigurationPage.TCPPort.BoundingRectangle.X + 10,
                   ConfigurationPage.TCPPort.BoundingRectangle.Y + 10));
                ConfigurationPage.TCPPort.Text = TitanTestConstants.TCPPort;
                Thread.Sleep(1000);

                Mouse.Click(new System.Drawing.Point(ConfigurationPage.UDPPort.BoundingRectangle.X + 10,
                ConfigurationPage.UDPPort.BoundingRectangle.Y + 10));
                ConfigurationPage.UDPPort.Text = TitanTestConstants.UDPPort;
                Thread.Sleep(1000);

                Mouse.Click(new System.Drawing.Point(ConfigurationPage.HostName.BoundingRectangle.X + 10,
               ConfigurationPage.HostName.BoundingRectangle.Y + 10));

                Keyboard.PressKey(KeyboardKey.Tabulator);
                Keyboard.PressKey(KeyboardKey.Tabulator);
                Thread.Sleep(2000);

                ConfigurationPage.ApplyButton.WaitUntilEnabled(10.0);
                Mouse.Click(new System.Drawing.Point(ConfigurationPage.ApplyButton.BoundingRectangle.X + 10,
                ConfigurationPage.ApplyButton.BoundingRectangle.Y + 10));
                Thread.Sleep(2000);

                ConfigurationPage.CloselButton.WaitUntilEnabled(10.0);
                Mouse.Click(new System.Drawing.Point(ConfigurationPage.CloselButton.BoundingRectangle.X + 10,
                   ConfigurationPage.CloselButton.BoundingRectangle.Y + 10));
                myLogger?.WriteInfo("Apollo Configuration with Titan is done Succesfully");
                isConfigured = true;
            }
            catch (Exception ex)
            {
                myLogger?.WriteError("Unable to save  Setting, mostly container is down");
                myLogger?.WriteError(ex.Message);
                myLogger?.WriteError("Closing the configuration dialogue and retry after 100ms");
                ConfigurationPage.CloselButton.WaitUntilEnabled(10.0);
                ConfigurationPage.CloselButton.MouseClick();
                Thread.Sleep(100);
            }
        }
        return isConfigured;
    }
    public bool VerifyVitalSignParameterValueIsPresent(VitalSignsType vitalSignsType, string value, int timeOut = 30)
    {
        bool check = false;
        DateTime endTime = DateTime.Now.AddSeconds(timeOut);

        while (endTime > DateTime.Now)
        {
            try
            {
                string vitalSignParameter = "";
                switch (vitalSignsType)
                {
                    case VitalSignsType.HR:
                        vitalSignParameter = TitanHomePage.HeartRateValue.TextValue;
                        break;
                    case VitalSignsType.SpO2:
                        vitalSignParameter = TitanHomePage.SpO2Value.TextValue;
                        break;
                    default:
                        myLogger?.WriteInfo("Not supported Vital Parameter " + vitalSignParameter.ToString());
                        return false;
                }
                if (vitalSignParameter == value)
                {
                    myLogger?.WriteInfo($"VitalSign Exp Value {value} matches with Actual Value {vitalSignParameter}");
                    return true;
                }
                else
                {
                    string VitalSignParameterText = vitalSignParameter;
                    myLogger?.WriteWarning($" VitalSignParameter text is : " + VitalSignParameterText + "Expected :" + value);
                }
            }
            catch (Exception ex)
            {
                myLogger?.WriteError(ex.Message);
                myLogger?.WriteError($"VitalSign Value:\'{value}\' not found");

            }
            Thread.Sleep(100);
        }
        return check;
    }

    public bool CloseAllBrowser()
    {
        CloseAllWindow();
        if (!ProcessController.KillProcess(ProcessController.ProcessType.chrome))
        {
            myLogger?.WriteError("Chrome browser is failed to get closed by process kill");
            return false;
        }
        myLogger?.WriteInfo("Tear Down executed");

        if (BrowserLaunchedInControlRoom)
        {
            CommonBase.RemoteAddress = GetRemoteAddress();
            if (!ProcessController.KillProcess(ProcessController.ProcessType.chrome))
            {
                myLogger?.WriteError("Chrome browser is failed to get closed by process kill in control room");
                return false;
            }

            BrowserLaunchedInControlRoom = false;
            myLogger?.WriteInfo("Tear Down executed in control room");
        }

        return true;
    }

    private void CloseAllWindow()
    {
        DateTime dateTime = DateTime.Now.AddSeconds(5);
        while (TitanHomePage.MainWindow.IsExisting && dateTime > DateTime.Now)
        {
            try
            {
                TitanHomePage.MainWindow.Close();
                myLogger?.WriteInfo("Closed window");
                Thread.Sleep(100);
            }
            catch (Exception ex)
            {
                myLogger?.WriteError("Unable to close window");
                myLogger?.WriteError("error Message : " + ex.Message);
            }
        }
    }

    private string FetchVitalSignParameterValue(VitalSignsType vitalSignsType, bool isPresent = false)
    {
        for (int retryCount = 0; retryCount < MaxRetryCountIfWebElementNotFound; retryCount++)
        {
            try
            {
                string vitalSignParameter = "";
                switch (vitalSignsType)
                {
                    case VitalSignsType.HR:
                        vitalSignParameter = TitanHomePage.HeartRateValue.TextValue;
                        break;
                    case VitalSignsType.SpO2:
                        vitalSignParameter = TitanHomePage.SpO2Value?.TextValue;
                        break;
                    default:
                        myLogger?.WriteError("Not supported Vital Parameter " + vitalSignParameter.ToString());
                        return String.Empty;
                }
                if (isPresent)
                {
                    bool status = vitalSignParameter != "---";

                    if (status)
                    {
                        return vitalSignParameter;
                    }
                    myLogger?.WriteInfo("$$$ VitalSignParameter text is : " + vitalSignParameter);
                    return "---";
                }
                else
                {
                    string VitalSignParameterText = vitalSignParameter;
                    myLogger?.WriteInfo("$$$ VitalSignParameter text is : " + VitalSignParameterText);
                    if (!(string.IsNullOrEmpty(VitalSignParameterText)))
                    {
                        return VitalSignParameterText;
                    }
                }
            }
            catch (Exception ex)
            {
                myLogger?.WriteError("VitalSignParameter value couldn't be fetched");
                myLogger?.WriteError("Network error message found:" + TitanHomePage.NetworkErrorModelDialogue?.TextValue);
                myLogger?.WriteError("Modal Dialogue is available on screen with title : " + TitanHomePage.StaticPage?.GetAttribute(TitanTestConstants.ApolloDisconnectMsg));
                myLogger?.WriteError(ex);
            }
        }
        return String.Empty;
    }

    public bool VerifyVitalValue(VitalSignsType vitalSignsType)
    {

        string value = "";
        for (int retryCount = 0; retryCount < MaxRetryCountIfWebElementNotFound; retryCount++)
        {
            try
            {
                switch (vitalSignsType)
                {
                    case VitalSignsType.HR:
                        value = FetchVitalSignParameterValue(VitalSignsType.HR, true);
                        int hrValue = (value != "---") ? Int32.Parse(value) : -1;
                        if (hrValue == -1)//HR Value -1 means we couldn't fetch the value
                        {
                            myLogger?.WriteInfo("HR Value displayed in the Titan UI is " + hrValue);
                            return true;
                        }
                        myLogger?.WriteInfo("HR Value in the Titan found is " + hrValue);
                        break;
                    case VitalSignsType.SpO2:
                        value = FetchVitalSignParameterValue(VitalSignsType.SpO2, true);
                        int SpO2Value = (value != "---") ? Int32.Parse(value) : -1;
                        if (SpO2Value == -1)//SpO2 Value -1 means we couldn't fetch the value
                        {
                            myLogger?.WriteInfo("SpO2 Value {0} displayed in the Titan UI" + SpO2Value);
                            return true;
                        }
                        myLogger?.WriteInfo("SpO2 Value in the Titan found is " + SpO2Value);
                        break;
                    default:
                        myLogger?.WriteError("Not supported Vital Parameter ");
                        return false;
                }
            }

            catch (Exception ex)
            {
                myLogger?.WriteError("VitalSignParameter value couldn't be fetched");
                myLogger?.WriteError("Network error message found:" + TitanHomePage.NetworkErrorModelDialogue?.TextValue);
                myLogger?.WriteError("Modal Dialogue is available on screen with title : " + TitanHomePage.StaticPage?.GetAttribute(TitanTestConstants.ApolloDisconnectMsg));
                myLogger?.WriteError(ex.Message);
            }
        }
        return false;
    }
    public bool VerifyHRValueIsPresent(string value) =>
       VerifyVitalSignParameterValueIsPresent(VitalSignsType.HR, value);
    public bool VerifySpO2ValueIsPresent(string value) =>
        VerifyVitalSignParameterValueIsPresent(VitalSignsType.SpO2, value);
    public bool VerifySplashScreenIsPresentWithProductInfo()
    {
        try
        {
            TitanHomePage.SplashScreenPage.WaitUntilVisible(5);
            string label = TitanHomePage.SplashScreenPage.GetAttribute("label");
            string version = TitanHomePage.SplashScreenPage.GetAttribute("version");
            string copyRight = TitanHomePage.SplashScreenPage.InnerText;

            if (label.Equals(TitanUITestModuleConstant.ProductTitle) && version.Equals(TitanUITestModuleConstant.VersionNumber) && copyRight.Equals(TitanUITestModuleConstant.copyRightInformation))
            {
                myLogger.WriteInfo("Splash Screen is displayed in the browser: with label " + label + "Version as " + version + "\t and CopyRight Information as " + copyRight);
                return true;
            }
            else
            {
                myLogger.WriteInfo("Some other display found in the browser. Having Splash Screen Info : " + label);
            }
        }
        catch (Exception ex)
        {
            myLogger.WriteError(ex);
        }
        return false;
    }
    public bool VerifyContinuosVitalSignValueList(string vitalSignList, VitalSignsType vitalSignsType)
    {
        List<string> expValues = vitalSignList.Split(',').ToList();
        expValues = ConvertToValidRange(expValues, vitalSignsType);
        List<string> capturedValues = new List<string>();
        try
        {
            DateTime endTime = DateTime.Now.AddSeconds(60);
            myLogger.WriteInfo("current time : " + DateTime.Now);
            myLogger.WriteInfo("end time : " + endTime);
            List<string> pairListNotFound = new List<string>();
            while (endTime > DateTime.Now)
            {

                string currentVitalValue = FetchVitalSignParameterValue(vitalSignsType);
                capturedValues.Add(currentVitalValue);
                capturedValues = capturedValues.Distinct().ToList();
                pairListNotFound = expValues.Except(capturedValues).ToList();
                if (pairListNotFound.Count == 0) break;
                Thread.Sleep(100);
            }

            capturedValues.ForEach(pair => myLogger.WriteInfo("Element captured : " + pair));
            pairListNotFound.ForEach(pair => myLogger.WriteInfo("Element Not found : " + pair));
            return pairListNotFound.Count == 0;
        }
        catch (Exception ex)
        {
            myLogger.WriteError(ex);
        }

        myLogger.WriteWarning("VitalSign Value fetched didn't matched, expValues : " + String.Join(",", expValues));
        return false;
    }
    private List<string> ConvertToValidRange(List<string> list, VitalSignsType vitalSignsType)
    {
        List<string> retList = new List<string>();
        foreach (string value in list)
        {
            int intvalue = int.Parse(value);
            switch (vitalSignsType)
            {
                case VitalSignsType.HR:
                    if (intvalue < 20 || intvalue > 300)
                        retList.Add("---");
                    else
                        retList.Add(value);
                    break;
                case VitalSignsType.SpO2:
                    if (intvalue == 0)
                        retList.Add("---");
                    else
                        retList.Add(value);
                    break;
                default:
                    break;
            }
        }
        return retList;
    }
}