//  <copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
using Logger = Xpta.Sita.Spy.Plugins.ControlAccess.Logger;
namespace TitanTest.Common.TestModule;
public sealed class ApolloSimulatorController
{
    private readonly List<Process> myProcessList;
    public string myCurrentTestCaseId;
    private const int DefaultTcpPort = 6708;
    private const string ApolloNonRespondingScenarioNo = "27";
    private const string ApolloToSendInvalidLengthOfDataPacket = "10";
    private const string ApolloToSendNoDataPacketAfter20Sec = "16";
    private const string LogFolderName = "Logs";
    private const string ApolloSimulatorApplicationName = "ApolloSimulator";
    private static readonly object lockObj = new object ();  
    private static ApolloSimulatorController instance;
    public static ApolloSimulatorController Instance
    {
        get
        {
            lock (lockObj)
                {
                    if (instance == null)
                    {
                        instance = new ApolloSimulatorController();
                    }
                    return instance;
                }
        }
    }

    private ApolloSimulatorController()
    {
        myProcessList = new List<Process>();
        myCurrentTestCaseId = String.Empty;
    }
    private bool StopApplicationInProcessList(string processName)
    {
        try
        {
            for (int i = 0; i < myProcessList.Count; i++)
            {
                if (!myProcessList[i].HasExited)
                {
                    Xpta.Sita.Spy.Plugins.ControlAccess.Logger.Instance.Write(LogMessageType.Error, "hi");
                    Logger.Instance.Write(LogMessageType.Info,String.Format("Current Process Name: {0} Id: {1}.", myProcessList[i].ProcessName, myProcessList[i].Id));

                    if (myProcessList[i].ProcessName == processName)
                    {
                        Logger.Instance.Write(LogMessageType.Info, String.Format("$$$$ Killing process {0} : {1}", myProcessList[i], myProcessList[i].Id));
                        myProcessList[i].Kill();
                        myProcessList[i].WaitForExit(5000);
                        myProcessList[i].Dispose();
                        myProcessList.RemoveAt(i);
                        break;
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Logger.Instance.Write(LogMessageType.Error, String.Format("Failed to stop the Process {0}", ex.Message));
            return false;
        }
        return true;
    }

    public bool KillPreexistingApolloSimulator()
    {
        try
        {
            for (int maxRetryToKill = 1; maxRetryToKill <= 3; maxRetryToKill++)
            {
                Process[] processes = Process.GetProcessesByName(ApolloSimulatorApplicationName);
                if (processes.Length == 0) break;
                Logger.Instance.Write(LogMessageType.Info, String.Format( "Kill attempt : {0}", maxRetryToKill));
                foreach (Process process in processes)
                {
                    Logger.Instance.Write(LogMessageType.Info, String.Format("#### Killing process {0} : {1}", process, process.Id));
                    process.Kill();
                    process.WaitForExit(5000);
                }
            }
            return true;
        }
        catch (Exception ex)
        {
            Logger.Instance.Write(LogMessageType.Error, String.Format(ex.Message));
        }
        return false;
    }

    public bool StartApolloWithNotRespondingTcp()
    {
        return StartApolloSimulator(DefaultTcpPort, ApolloNonRespondingScenarioNo);
    }

    public bool StartApolloToSendInvalidLengthOfDataPacket()
    {
        return StartApolloSimulator(DefaultTcpPort, ApolloToSendInvalidLengthOfDataPacket);
    }

    public bool StartApolloToSendNoDataPacketAfter20Sec()
    {
        return StartApolloSimulator(DefaultTcpPort, ApolloToSendNoDataPacketAfter20Sec);
    }

    public bool StartApolloWithNotRespondingToHelloCmd()
    {
        //TODO: Need to replace with correct error code
        return StartApolloSimulator(DefaultTcpPort, ApolloNonRespondingScenarioNo);
    }

    public string ModifyHrValue(string hr)
    {
        //TODO: Need misbehave scenario for HR 19 and 301 since they are boundary case 
        //remove this function ones behavior is implemented in apollo 
        switch (hr)
        {
            case "19": hr = "15"; break;
            case "100": hr = "20"; break;
            case "301": hr = "317"; break;
        }
        return hr;
    }

    public bool StartApolloWithArguments(string args)
    {
        return StartApolloSimulator(DefaultTcpPort, args);
    }

    public bool StartApolloSimulatorWithApolloRawFile(string rawFile)
    {
        string location = "";
        if (!string.IsNullOrEmpty(rawFile))
            location = @" -r " + rawFile;
        return StartApolloSimulator(DefaultTcpPort, location);
    }

    public bool StartApolloSimulatorWithApolloCsvFile(string csvFile)
    {
        string location = "";
        if (!string.IsNullOrEmpty(csvFile))
            location = @" -C " + csvFile;
        return StartApolloSimulator(DefaultTcpPort, location);
    }

    private string GetApolloLogFilePath()
    {
        string logDirectory = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, @"..\..\..\")) + $"{LogFolderName}\\";
        if (!Directory.Exists(logDirectory))
            Directory.CreateDirectory(logDirectory);
        return $"{logDirectory}ApolloSimulator_{myCurrentTestCaseId}_{DateTime.UtcNow.ToString("yyyyMMddHHmmss")}.log";
    }

    public bool StartApolloSimulator(int port = DefaultTcpPort, string args = "")
    {
        try
        {
            Process processToBeBooted = new Process
            {
                StartInfo =
                {
                    WindowStyle = ProcessWindowStyle.Normal,
                    FileName = ApolloSimulatorApplicationName,
                    Arguments = @" -t " + port.ToString() + @" -v -v -l " + $"{GetApolloLogFilePath()}" + " " + args,
                },
            };

            if (processToBeBooted.Start())
            {
                myProcessList.Add(processToBeBooted);
                Logger.Instance.Write(LogMessageType.Info, String.Format( "Process Name: {0} : ID {1}  started with port:{2} args \"{3}\"", processToBeBooted.StartInfo.FileName, processToBeBooted.Id, port, args));
            }
            else
            {
                Logger.Instance.Write(LogMessageType.Info, String.Format("Process Name: {0} failed to start.", processToBeBooted.StartInfo.FileName));
                return false;
            }
        }
        catch (Exception ex)
        {
            Logger.Instance.Write(LogMessageType.Error, String.Format(ex.Message));
            return false;
        }
        return true;
    }

    public bool StopApolloSimulator()
    {
        return StopApplicationInProcessList(ApolloSimulatorApplicationName);
    }

    public bool FindAndStopApolloSimulator()
    {
        try
        {
            foreach (Process process in Process.GetProcessesByName(ApolloSimulatorApplicationName))
            {
                process.Kill();
                process.WaitForExit();
            }
        }
        catch (Exception ex)
        {
            Logger.Instance.Write(LogMessageType.Error, String.Format("Failed to stop the Process {0}", ex.Message));
            return false;
        }
        return true;
    }
}
