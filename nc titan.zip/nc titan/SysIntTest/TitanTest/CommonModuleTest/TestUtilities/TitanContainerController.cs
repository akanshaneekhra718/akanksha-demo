﻿using Logger = Xpta.Sita.Spy.Plugins.ControlAccess.Logger;
namespace TitanTest.Common.TestModule;
public enum ActionType
{
    start = 1,
    stop = 2,
    restart = 3
}
public sealed class TitanContainerController
{
    private const string ContainerRestartBatFile = "dockerRemoteAction.bat";

    private static readonly object lockObj = new object();
    private static TitanContainerController instance = null;
    private TitanContainerController() {}
    public static TitanContainerController Instance
    {
        get
        {
            lock (lockObj)
            {
                if (instance == null)
                {
                    instance = new TitanContainerController();
                }
                return instance;
            }
        }
    }

    //valid command parameters should be "start or stop or restart"
    public bool StartStopTitanContainer(ActionType actionType)
    {
        bool isBatFileExecuted = false;
        try
        {
            Process process = new Process();
            process.StartInfo.FileName = ContainerRestartBatFile;
            process.StartInfo.Arguments = actionType.ToString();
            process.Start();
            Thread.Sleep(TimeSpan.FromSeconds(50));// To wait after Titan container is starts and stops
            isBatFileExecuted = true;
        }
        catch (Exception ex)
        {
            Logger.Instance.Write(LogMessageType.Info, ex.ToString());
        }
        return isBatFileExecuted;
    }
}