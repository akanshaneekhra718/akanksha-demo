//  <copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
using Process = Xpta.Sita.Spy.Plugins.ProcessHandler.Process;
namespace TitanTest.Common.TestModule;

public static class ProcessController
{
    public enum ProcessType
    {
        chrome
    }

    public static bool KillProcess(ProcessType browser)
    {
        bool webDriverProcessKilled = false;
        string webDriverProcess = browser switch
        {
            ProcessType.chrome => ProcessType.chrome.ToString(),
            _ => string.Empty
        };
        if (!string.IsNullOrEmpty(webDriverProcess))
        {
               Process.GetProcessesByName(CommonBase.RemoteAddress,webDriverProcess).ToList().ForEach(e => { e.Kill(); e.WaitForExit(20000); });
               webDriverProcessKilled = true;
        }
        return webDriverProcessKilled;
    }

    public static bool CheckBrowserProcessAlive(ProcessType browser)
    {
        bool isProcessPresent = true;
         if (Process.GetProcessesByName(CommonBase.RemoteAddress,browser.ToString()).Any())
        {
            isProcessPresent = false;
        }
        return isProcessPresent;
    }
}