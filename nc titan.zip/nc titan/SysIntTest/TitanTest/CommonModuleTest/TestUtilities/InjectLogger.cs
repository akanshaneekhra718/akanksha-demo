//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.Common.TestModule;
public class InjectLogger
{ 
  public static Xpta.Sita.TestSteps.ILogger Log(Xpta.Sita.TestSteps.ILogger logger)
  {
    return logger;
  }
}