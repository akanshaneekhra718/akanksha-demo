//<copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace TitanTest.Common.TestModule;
public class TitanTestConstants
{
    public IWindow MainWindow => BaseControl.CreateControl<IWindow>("/Window[@Name~'Titan .*']");
    internal const string DocumentXpath = "/Window[@Name~'Titan .*']/Document[@Name='Titan']";
    internal const string x64Path = @"C:\Program Files\Google\Chrome\Application\chrome.exe";
    internal const string x86Path = @"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe";
    public const int TitanPort = 8080;
    public const string HostName = "localhost";
    public const string ProductTitle = "Titan";
    public const string VersionAttribute = "Version";
    public const string VersionNumber = "VA10A";
    public const string LabelAttribute = "label";
    public const string CopyRightYear = "2022";
    public const string TCPPort = "6708";
    public const string UDPPort = "6709";
    internal const string ApolloDisconnectMsg="We Couldn't Connect To Apollo";
    internal const string TitanDisconnectMsg="We Couldn't Connect To Titan";
    public const string ExamRoom = "Exam";
    public const string ControlRoom = "Control";
    public const string RemoteDebugging = "--remote-debugging-port=9222 --hide-crash-restore-bubble --disable-infobars --start-maximized --new-window ";
}