//  <copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace Titan.SysInt.Nls.Steps.Test;

[Binding]
public class NlsStepDefinitions
{
    private IWebDriver myTitanLocalWebpageExamRoom;
    private CommonUITestDataContract myCommonUITestDataContract;
    private TitanHomePage myTitanHomePage;
    private readonly UserIdentifierList myUserIdentifierList;
    public NlsStepDefinitions()
    {
        myUserIdentifierList = new UserIdentifierList();
    }

    #region BeforeScenario
    [BeforeScenario]
    public void BeforeScenario()
    {
        try
        {
            GivenTitanUIIsLaunched();
            WhenUserClicksOnTheUserIdentifierOptionOnTheTitanHomePage();
            WhenUserMouseHoversOnTheLanguageSelectionMenuItemFromUserMenuDropDownList();
            WhenUserSelectsFromTheLanguageMenu("English");
            Assert.IsTrue(Titan.Common.Test.WebDriver.CleanupForClickOnTheBookmark(myTitanLocalWebpageExamRoom));
            Assert.IsTrue(Titan.Common.Test.WebDriver.KillWebDriverProcess(Titan.Common.Test.WebDriver.BrowserType.Chrome));
        }
        catch (Exception ex)
        {
            Console.WriteLine("Exception caught : " + ex.ToString());
        }

    }
    #endregion

    #region AfterScenario
    [AfterScenario]
    public void AfterScenario()
    {
        try
        {
            if (myTitanLocalWebpageExamRoom != null)
            {
                WhenUserClicksOnTheUserIdentifierOptionOnTheTitanHomePage();
                WhenUserMouseHoversOnTheLanguageSelectionMenuItemFromUserMenuDropDownList();
                WhenUserSelectsFromTheLanguageMenu("English");
                Assert.IsTrue(Titan.Common.Test.WebDriver.CleanupForClickOnTheBookmark(myTitanLocalWebpageExamRoom));
                Assert.IsTrue(Titan.Common.Test.WebDriver.KillWebDriverProcess(Titan.Common.Test.WebDriver.BrowserType.Chrome));
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine("Exception caught : " + ex.ToString());
        }

    }

    #endregion

    #region
    [Given(@"Titan UI is launched")]
    public void GivenTitanUIIsLaunched()
    {
        Assert.IsTrue(Titan.Common.Test.WebDriver.KillWebDriverProcess(Titan.Common.Test.WebDriver.BrowserType.Chrome));
        myTitanLocalWebpageExamRoom = Titan.Common.Test.WebDriver.CreateInstance(Titan.Common.Test.WebDriver.BrowserType.Chrome);
        myCommonUITestDataContract = new CommonUITestDataContract(myTitanLocalWebpageExamRoom);
        myTitanHomePage = new TitanHomePage(myTitanLocalWebpageExamRoom);
        Assert.IsTrue(myTitanHomePage.LaunchBrowserNavigateToTitanURL());
    }
    #endregion

    #region
    [When(@"User clicks on the User Identifier option on the Titan home Page")]
    public void WhenUserClicksOnTheUserIdentifierOptionOnTheTitanHomePage()
    {
        if (myCommonUITestDataContract.IsElementDisplayed(myTitanHomePage.UserIdentifierLabel))
        {
            myCommonUITestDataContract.Click(myTitanHomePage.UserIdentifierLabel);
            Console.WriteLine("Language Label Displayed: " + myCommonUITestDataContract.GetAttributeValue(myUserIdentifierList.languageLabel, "label"));
            Assert.IsFalse(myCommonUITestDataContract.GetAttributeValue(myUserIdentifierList.languageLabel, "label").Equals("Language (undefined)"));
            Assert.IsTrue(myCommonUITestDataContract.IsElementSelected(myTitanHomePage.UserIdentifierLabel));
        }
    }
    #endregion

    #region
    [Then(@"Verify User Menu drop down list is displayed")]
    public void ThenVerifyUserMenuDropDownListIsDisplayed()
    {
        Assert.IsTrue(myCommonUITestDataContract.IsElementDisplayed(myUserIdentifierList.userIdentifierMenu));
    }
    #endregion

    #region
    [When(@"User mouse hovers on the Language selection menu item from User Menu drop down list")]
    public void WhenUserMouseHoversOnTheLanguageSelectionMenuItemFromUserMenuDropDownList()
    {
        myCommonUITestDataContract.MouseHover(myUserIdentifierList.languageLabel);
        Assert.IsTrue(myCommonUITestDataContract.IsElementSelected(myUserIdentifierList.languageLabel));
    }
    #endregion

    #region
    [Then(@"Verify language menu is displayed")]
    public void ThenVerifyLanguageMenuIsDisplayed()
    {
        Assert.IsTrue(myCommonUITestDataContract.IsElementDisplayed(myUserIdentifierList.languageMenu));
    }
    #endregion

    #region
    [Then(@"Verify English Language is highlighted in the language menu")]
    public void ThenVerifyEnglishLanguageIsHighlightedInTheLanguageMenu()
    {
        Thread.Sleep(1000);
        if (myCommonUITestDataContract.IsElementDisplayed(myUserIdentifierList.englishLanguageLabel))
        {
            Assert.IsTrue(myCommonUITestDataContract.GetAttributeValue(myUserIdentifierList.englishLanguageLabel, "active") == "true");
        }
    }
    #endregion

    #region
    [Then(@"English Language is displayed as part of the User Menu Language Label")]
    public void ThenEnglishLanguageIsDisplayedAsPartOfTheUserMenuLanguageLabel()
    {
        Assert.IsTrue(myCommonUITestDataContract.GetAttributeValue(myUserIdentifierList.languageLabel, "label").Equals("Language (English)"));
    }
    #endregion

    #region
    [Then(@"Selected ""([^""]*)"" Language is displayed as part of the User Menu Language Label")]
    public void ThenSelectedLanguageIsDisplayedAsPartOfTheUserMenuLanguageLabel(string language)
    {
        Thread.Sleep(1000); // Giving some time to load and verify
        switch (language)
        {
            case "English":
                Assert.IsTrue(myCommonUITestDataContract.GetAttributeValue(myUserIdentifierList.languageLabel, "label").Equals("Language (" + language + ")"));
                break;
            case "Deutsch":
                Assert.IsTrue(myCommonUITestDataContract.GetAttributeValue(myUserIdentifierList.languageLabel, "label").Equals("Sprache (" + language + ")"));
                break;
        }
    }
    #endregion

    #region
    [When(@"User selects ""([^""]*)"" from the language menu")]
    public void WhenUserSelectsFromTheLanguageMenu(string language)
    {
        switch (language)
        {
            case "English":
                if (myCommonUITestDataContract.IsElementDisplayed(myUserIdentifierList.englishLanguageLabel))
                {
                    myCommonUITestDataContract.Click(myUserIdentifierList.englishLanguageLabel);
                }
                break;
            case "Deutsch":
                if (myCommonUITestDataContract.IsElementDisplayed(myUserIdentifierList.germanLanguageLabel))
                {
                    myCommonUITestDataContract.Click(myUserIdentifierList.germanLanguageLabel);
                }
                break;
        }
    }
    #endregion

    #region
    [Then(@"Verify ""([^""]*)"" is selected")]
    public void ThenVerifyIsSelected(string language)
    {
        switch (language)
        {
            case "English":
                Assert.IsTrue(myCommonUITestDataContract.IsElementSelected(myUserIdentifierList.englishLanguageLabel));
                break;
            case "Deutsch":
                Assert.IsTrue(myCommonUITestDataContract.IsElementSelected(myUserIdentifierList.germanLanguageLabel));
                break;
        }
    }
    #endregion
}

