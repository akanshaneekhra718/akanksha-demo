﻿//  <copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>

namespace Titan.SysInt.VitalSigns.Steps.Test;

[Binding]
public sealed class SpO2StepDefinition
{
    private TitanUITestController myTitanLocalWebpageExamRoom;
    private TitanUITestController myTitanRemoteWebpageControlRoom;
    private readonly ApolloSimulatorController myApolloSimulatorController;
    private IWebDriver myLocalWebDriver;
    private IWebDriver myRemoteWebDriver;
    private readonly ScenarioContext myScenarioContext;
    public SpO2StepDefinition(ScenarioContext scenarioContext)
    {
        ChromeOptions options = new ChromeOptions();
        options.SetLoggingPreference(LogType.Browser, LogLevel.All);
        myApolloSimulatorController = new ApolloSimulatorController();
        myScenarioContext = scenarioContext;
    }

    #region AfterAfterScenario
    [AfterScenario, Scope(Feature = "SpO2")]
    public void AfterScenario()
    {
        if (myTitanLocalWebpageExamRoom != null)
            Assert.IsTrue(myTitanLocalWebpageExamRoom.CleanupForClickOnTheBookmark());
        if (myTitanRemoteWebpageControlRoom != null)
        {
            Assert.IsTrue(myTitanRemoteWebpageControlRoom.CleanupForClickOnTheBookmark());
        }
        Assert.IsTrue(myApolloSimulatorController.StopApolloSimulator());
        Assert.IsTrue(Titan.Common.Test.WebDriver.KillWebDriverProcess(Titan.Common.Test.WebDriver.BrowserType.Chrome));
    }

    #endregion

    #region  BeforeScenario
    [BeforeScenario, Scope(Feature = "SpO2")]
    public void BeforeScenario()
    {
        Logger.Log(TraceLevel.Info, "Starting " + myScenarioContext.ScenarioInfo.Tags[0]);
        myApolloSimulatorController.myCurrentTestCaseId = "SPO2_" + myScenarioContext.ScenarioInfo.Tags[0];
        Assert.IsTrue(ApolloSimulatorController.KillPreexistingApolloSimulator());
        Assert.IsTrue(Titan.Common.Test.WebDriver.KillWebDriverProcess(Titan.Common.Test.WebDriver.BrowserType.Chrome));
    }
    #endregion

    #region Common
    /// <summary>
    /// Same step used in the Test :- AT-TTN-SIT-002
    /// </summary>
    [Scope(Feature = "SpO2")]
    [Given(@"Apollo Simulator is started")]
    public void ApolloIsRunning()
    {
        Assert.IsTrue(myApolloSimulatorController.StartApolloSimulator());
    }

    /// <summary>
    ///  Same step used in the Test :- AT-TTN-SIT-002
    /// </summary>
    [Scope(Feature = "SpO2")]
    [Given(@"Browser is launched and navigated to Titan UI")]
    [When(@"Browser is launched and navigated to Titan UI")]
    public void BrowserIsLaunchedAndNavigatedToTitanWebpageURL()
    {
        myLocalWebDriver = Titan.Common.Test.WebDriver.CreateInstance(Titan.Common.Test.WebDriver.BrowserType.Chrome);
        myTitanLocalWebpageExamRoom = new TitanUITestController(myLocalWebDriver);
        Assert.IsTrue(myTitanLocalWebpageExamRoom.LaunchBrowserNavigateToTitanURL());
    }

    /// <summary>
    ///  Same step used in the Test :- AT-TTN-SIT-002,004
    /// </summary>
    [Scope(Feature = "SpO2")]
    [When(@"Titan UI is visible with monitoring screen")]
    [When(@"Titan UI is visible with monitoring screen on Exam room")]
    public void TitanUIHomepageIsVisibleWithParameterArea()
    {
        Assert.IsTrue(myTitanLocalWebpageExamRoom.WaitUntilTitanHomePageIsAvailableWithParameterArea(), "Home Page not available");
    }

    /// <summary>
    ///  Same step used in the Test :- AT-TTN-SIT-002
    /// </summary>
    [Then(@"SpO2 label is represented as '([^']*)' in Titan UI in exam room")]
    public void ThenSPOLabelIsRepresentedAs(string SPO2Label)
    {
        Assert.IsTrue(myTitanLocalWebpageExamRoom.VerifySpO2LabelPresentOnUI(SPO2Label), "SpO2 label is not available");
    }

    /// <summary>
    ///  Same step used in the Test :- AT-TTN-SIT-002
    /// </summary>
    [Then(@"Verify Real time value of SPO2 is displayed in monitoring screen in exam room")]
    public void ThenDefaultRealTimeValueOfSPO2IsDisplayed()
    {
        Assert.IsTrue(myTitanLocalWebpageExamRoom.VerifySpO2Value(), "SPO2 is in displayed in the titan UI");
    }

    /// <summary>
    ///  Same step used in the Test :- AT-TTN-SIT-003,004
    /// </summary>
    [When(@"Apollo simulator is started with clinical scenario raw file '([^']*)'")]
    [When(@"SpO2 Probe and Cable connect and disconnect behavior is simulated with a raw file '(.*)'")]
    [When(@"SpO2 sensor connect and disconnect behavior is simulated with a raw file '(.*)'")]
    [When(@"SpO2 Probe connect and disconnect behavior is simulated with a raw file '(.*)'")]
    [When(@"Apollo simulator is started with raw file '([^']*)'")]
    public void WhenApolloSimulatorIsStartedWithClinicalScenarioRawFile(string fileName)
    {
        string fileLocation = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
        string filePath = Path.Combine(fileLocation, fileName);
        if (File.Exists(filePath))
            Assert.IsTrue(myApolloSimulatorController.StartApolloSimulatorWithApolloRawFile(filePath));
        else
        {
            Logger.Log(TraceLevel.Warning, "Raw file does not exist on the provided path : " + filePath);
            Assert.IsTrue(File.Exists(filePath));
        }
    }

    /// <summary>
    ///  Same step used in the Test :- AT-TTN-SIT-002,004
    /// </summary>
    [Scope(Feature = "SpO2")]
    [When(@"Titan UI is visible with monitoring screen on Control room")]
    public void TitanHomepageIsVisibleOnControlRoomWithParameterArea()
    {
        Assert.IsTrue(myTitanRemoteWebpageControlRoom.WaitUntilTitanHomePageIsAvailableWithParameterArea());
    }

    /// <summary>
    ///  Same step used in the Test :- AT-TTN-SIT-002,004
    /// </summary>
    [Scope(Feature = "SpO2")]
    [When(@"Browser is launched and navigated to Titan UI in control room and exam room")]
    public void GivenBrowserIsLaunchedAndNavigatedToTitanWebpageURLInBothClient()
    {
        myLocalWebDriver = Titan.Common.Test.WebDriver.CreateInstance(Titan.Common.Test.WebDriver.BrowserType.Chrome);
        myTitanLocalWebpageExamRoom = new TitanUITestController(myLocalWebDriver);
        Assert.IsTrue(myTitanLocalWebpageExamRoom.LaunchBrowserNavigateToTitanURL());

        //Todo: Issue AT 3105: Enable selenium grid after fix
        // create instance of browser in control room
        myRemoteWebDriver = Titan.Common.Test.WebDriver.CreateInstance(Titan.Common.Test.WebDriver.BrowserType.Chrome);

        myTitanRemoteWebpageControlRoom = new TitanUITestController(myRemoteWebDriver);
        Assert.IsTrue(myTitanRemoteWebpageControlRoom.LaunchBrowserNavigateToTitanURL());
    }
    /// <summary>
    ///  Same step used in the Test :- AT-TTN-SIT-003,004
    /// </summary>
    [Then(@"All the SpO2 values mentioned in ""([^""]*)"" are displayed in the TitanUI")]
    [Then(@"All the SpO2 values mentioned in ""([^""]*)"" are displayed in the TitanUI in the exam room")]
    public void ThenAllTheSpOValuesMentionedInAreDisplayedInTheTitanUI(string SpO2_List)
    {
        Assert.IsTrue(myTitanLocalWebpageExamRoom.VerifyContinuosSpO2ValueList(SpO2_List));
    }

    [Then(@"All the SpO2 values mentioned in ""([^""]*)"" are displayed in the TitanUI in the control room")]
    public void ThenThenAllTheSpOValuesMentionedInAreDisplayedInTheTitanUIInTheRemoteTitanUI(string SpO2_List)
    {
        Assert.IsTrue(myTitanRemoteWebpageControlRoom.VerifyContinuosSpO2ValueList(SpO2_List));
    }

    #endregion

    #region AT-TTN-SIT-002
    /// <summary>
    ///  Same step used in the Test :- AT-TTN-SIT-002
    /// </summary>
    [Then(@"SpO2 label is represented as '([^']*)' in Titan UI in control room")]
    public void ThenSpOLabelIsRepresentedAsInControlRoom(string SPO2Label)
    {
        Assert.IsTrue(myTitanRemoteWebpageControlRoom.VerifySpO2LabelPresentOnUI(SPO2Label), "SpO2 label is not available");
    }

    /// <summary>
    ///  Same step used in the Test :- AT-TTN-SIT-002
    /// </summary>
    [Then(@"Verify Real time value of SPO2 is displayed in monitoring screen in control room")]
    public void ThenDefaultRealTimeValueOfSpOIsDisplayedInExamRoom()
    {
        Assert.IsTrue(myTitanRemoteWebpageControlRoom.VerifySpO2Value(), "SPO2 value is displayed in the Titan UI");
    }
    /// <summary>
    ///  Same step used in the Test :- AT-TTN-SIT-002
    /// </summary>
    [Then(@"Verify SPO2 Unit is displayed in monitoring screen '([^']*)' in exam room")]
    public void ThenSPOUnitIsDisplayedInInExamRoom(string SPO2Unit)
    {
        Assert.IsTrue(myTitanLocalWebpageExamRoom.VerifySPO2UnitPresentOnUI(SPO2Unit));
    }
    /// <summary>
    ///  Same step used in the Test :- AT-TTN-SIT-002
    /// </summary>
    [Then(@"Verify SPO2 Unit is displayed in monitoring screen '([^']*)' in control room")]
    public void ThenSPOUnitIsDisplayedInInControlRoom(string SPO2Unit)
    {
        Assert.IsTrue(myTitanRemoteWebpageControlRoom.VerifySPO2UnitPresentOnUI(SPO2Unit));
    }

    #endregion

    #region AT-TTN-SIT-004, AT-TTN-SIT-006
    /// <summary>
    ///  Same step used in the Test :- AT-TTN-SIT-004,006
    /// </summary>
    [Then(@"User get notified with Message on UI for Probe disconnected Status along with info icon")]
    [Then(@"User get notified with Message on UI for Sensor disconnected Status along with warning icon")]
    public void ThenUserGetNotifiedWithMessageOnTitanUIAlongWithIconOnTheTitanUI(Table table)
    {
        List<Tuple<string, string>> pairList = new List<Tuple<string, string>>();
        foreach (TableRow row in table.Rows)
        {
            List<string> messages = row.Values.ToList();
            Logger.Log(TraceLevel.Verbose, "|");
            messages.ForEach(text => Logger.Log(TraceLevel.Verbose, $"{text}|"));
            pairList.Add(new Tuple<string, string>(messages[1], messages[2]));

        }
        Assert.IsTrue(myTitanLocalWebpageExamRoom.VerifySPO2DisconnectTextOnUI(pairList, 100000));
    }
    #endregion

    #region AT-TTN-SIT-006
    /// <summary>
    ///  Same step used in the Test :- AT-TTN-SIT-006
    /// </summary>

    [Then(@"No message or icon displayed for Probe connected status")]
    [Then(@"No message or icon displayed for sensor connected status")]
    [Then(@"No probe disconnected message displayed on UI for probe connected status")]
    public void ThenNoMessageAndIconDisplayedForProbeConnectedStatus()
    {
        Assert.IsTrue(myTitanLocalWebpageExamRoom.VerifyNoSPO2StatusMessageAndIconPresentOnUI(" "));
    }

    /// <summary>
    ///  Same step used in the Test :- AT-TTN-SIT-002
    /// </summary>
    [Then(@"SpO2 cable disconnect message '([^']*)' with '([^']*)' icon displayed on the Titan UI for SpO2 cable disconnect status")]
    [Then(@"Attach SpO2 probe '([^']*)' message with '([^']*)' icon displayed on the Titan UI for Probe disconnected status")]
    public void ThenSpOSensorIsDisconnectedAndMessageWithIconDisplayedOnTheTitanUI(string message, string iconType)
    {
        const int WaitForMsgAndIconInSec = 10; //RawFile size is of 10 sec 
        Assert.IsTrue(myTitanLocalWebpageExamRoom.VerifySpo2MessageAndIconsPresentOnUI(message, iconType, WaitForMsgAndIconInSec));
    }
    #endregion

    #region Background

    [Scope(Feature = "SpO2")]
    [Given(@"Titan configured with apollo successfully done")]
    public void GivenTitanPairingWithApolloIsSuccessfullyDone()
    {
        myApolloSimulatorController.StartApolloSimulator();
        myLocalWebDriver = Titan.Common.Test.WebDriver.CreateInstance(Titan.Common.Test.WebDriver.BrowserType.Chrome);
        myTitanLocalWebpageExamRoom = new TitanUITestController(myLocalWebDriver);
        Assert.IsTrue(myTitanLocalWebpageExamRoom.ConfigureTitanToConnectApollo(), "Failed to configure Titan to connect with Apollo");
        myApolloSimulatorController.StopApolloSimulator();
        Titan.Common.Test.WebDriver.KillWebDriverProcess(Titan.Common.Test.WebDriver.BrowserType.Chrome);
    }
    #endregion
}
