//  <copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>

namespace Titan.SysInt.VitalSigns.Steps.Test;

[Binding]
public sealed class VitalSignStepDefinition
{
    private TitanUITestController myTitanLocalWebpageExamRoom;
    private readonly ApolloSimulatorController myApolloSimulatorController;
    private IWebDriver myLocalWebDriver;
    private readonly ObserverControllerModule myObserverControllerModule;
    private readonly ScenarioContext myScenarioContext;
    private readonly TestRestClient myTestRestClient;

    public VitalSignStepDefinition(ScenarioContext scenarioContext)
    {
        myScenarioContext = scenarioContext;
        myApolloSimulatorController = new ApolloSimulatorController();
        myObserverControllerModule = new ObserverControllerModule();
        myTestRestClient = new TestRestClient();
    }
    #region AfterScenario
    [AfterScenario, Scope(Feature = "VitalSign")]
    public void AfterScenario()
    {
        if (myTitanLocalWebpageExamRoom != null)
            Assert.IsTrue(myTitanLocalWebpageExamRoom.CleanupForClickOnTheBookmark());
        Assert.IsTrue(myApolloSimulatorController.StopApolloSimulator());
        Assert.IsTrue(Titan.Common.Test.WebDriver.KillWebDriverProcess(Titan.Common.Test.WebDriver.BrowserType.Chrome));
        myObserverControllerModule.StopTestServer();
    }
    #endregion

    #region BeforeScenario
    [BeforeScenario, Scope(Feature = "VitalSign")]
    public void BeforeScenario()
    {
        Logger.Log(TraceLevel.Info, "Starting " + myScenarioContext.ScenarioInfo.Tags[0]);
        myApolloSimulatorController.myCurrentTestCaseId = "VitalSign_" + myScenarioContext.ScenarioInfo.Tags[0];
        Assert.IsTrue(ApolloSimulatorController.KillPreexistingApolloSimulator());
        Assert.IsTrue(Titan.Common.Test.WebDriver.KillWebDriverProcess(Titan.Common.Test.WebDriver.BrowserType.Chrome));
    }
    #endregion

    #region Common

    /// <summary>
    ///  Same step used in the Test :- AT-TTN-SIT-VitalSign-004,005,006
    /// </summary>
    [Scope(Feature = "VitalSign")]
    [Given(@"Browser is launched and navigated to Titan UI")]
    public void BrowserIsLaunchedAndNavigatedToTitanWebpageURL()
    {
        myLocalWebDriver = Titan.Common.Test.WebDriver.CreateInstance(Titan.Common.Test.WebDriver.BrowserType.Chrome);
        myTitanLocalWebpageExamRoom = new TitanUITestController(myLocalWebDriver);
        Assert.IsTrue(myTitanLocalWebpageExamRoom.LaunchBrowserNavigateToTitanURL());
    }

    /// <summary>
    ///  Same step used in the Test :- AT-TTN-SIT-VitalSign-004,005
    /// </summary>
    [Scope(Feature = "VitalSign")]
    [Given(@"HR parameter value in webpage is represented as three dashes '([^']*)'")]
    [Then(@"HR parameter value in webpage is represented as three dashes '(.*)'")]
    public void ThenHRParameterValueInWebpageIsRepresentedAsThreeDashes(string value)
    {
        Assert.IsTrue(myTitanLocalWebpageExamRoom.VerifyHRValueIsPresent(value));
    }

    /// <summary>
    ///  Same step used in the Test :- AT-TTN-SIT-VitalSign-004,005,006
    /// </summary>
    [Scope(Feature = "VitalSign")]
    [Given(@"SpO2 parameter value in webpage is represented as three dashes '([^']*)'")]
    [Then(@"SpO2 parameter value in webpage is represented as three dashes '([^']*)'")]
    public void GivenSPOParameterValueInWebpageIsRepresentedAsThreeDashes(string value)
    {
        Assert.IsTrue(myTitanLocalWebpageExamRoom.VerifySpO2ValueIsPresent(value));
    }

    /// <summary>
    ///  Same step used in the Test :- AT-TTN-SIT-VitalSign-004,005
    /// </summary>
    [Scope(Feature = "VitalSign")]
    [Given(@"Apollo Simulator is started with no Vital Sign data Input")]
    [When(@"Apollo Simulator is started with no Vital Sign data Input")]
    public void WhenApolloIsStartedWhichDoesNotSendAnyVitalSignData()
    {
        Assert.IsTrue(myApolloSimulatorController.StartApolloSimulator(6708, "5"));
    }
    #endregion

    #region AT-TTN-SIT-VitalSign-005

    [Scope(Feature = "VitalSign")]
    [Given(@"Titan UI is visible")]
    public void TitanUIHomepageIsVisible()
    {
        Assert.IsTrue(myTitanLocalWebpageExamRoom.WaitUntilTitanHomePageIsAvailable(), "Home Page not available");
    }

    [Scope(Feature = "VitalSign")]
    [Then(@"Default real time value is displayed in the Titan UI")]
    public void DefaultRealTimeValueIsDisplayed()
    {
        Assert.IsTrue(myTitanLocalWebpageExamRoom.VerifyHRValue(), "Hr is displayed");
    }

    [When(@"Static page ""([^""]*)"" disappear")]
    public void WhenStaticPageDisappear(string p0)
    {
        Assert.IsTrue(myTitanLocalWebpageExamRoom.WaitUntilTitanHomePageIsAvailableWithParameterArea(), "Home Page not available");
    }

    [Then(@"Default real time value for SpO2 is displayed in the Titan UI")]
    public void ThenDefaultRealTimeValueForSPOIsDisplayed()
    {
        Assert.IsTrue(myTitanLocalWebpageExamRoom.VerifySpO2Value(), "SpO2 is in displayed");
    }

    [When(@"Apollo Simulator is restarted again")]
    public void WhenApolloSimulatorIsRestartedAgain()
    {
        Assert.IsTrue(myApolloSimulatorController.StopApolloSimulator(), "Unable to stop Apollo");
        Assert.IsTrue(myApolloSimulatorController.StartApolloSimulator(), "Failed to start Apollo");
    }

    #endregion

    #region AT-TTN-SIT-VitalSign-006

    [Scope(Feature = "VitalSign")]
    [Given(@"Apollo Simulator is started")]
    public void ApolloIsRunning()
    {
        Assert.IsTrue(myApolloSimulatorController.StartApolloSimulator());
    }

    [Scope(Feature = "VitalSign")]
    [Given(@"Titan UI is visible with monitoring screen")]
    [Then(@"Titan UI is visible with monitoring screen")]
    public void TitanUIHomepageIsVisibleWithParameterArea()
    {
        Assert.IsTrue(myTitanLocalWebpageExamRoom.WaitUntilTitanHomePageIsAvailableWithParameterArea(), "Home Page not available");
    }
    [When(@"Apollo and Titan has a network lag")]
    public void WhenApolloAndTitanHasANetworkLag()
    {
        TestMessage testMessage = new TestMessage()
        {
            CommandType = TestCommandType.Control,
            Target = TestTargets.WorkflowController,
            ControlCommand = ControlCommands.DelayApolloRoundTrip,
            TimePeriod = 10
        };
        Assert.IsTrue(myTestRestClient.SendRestRequest(testMessage, testMessage.Target).GetAwaiter().GetResult());
    }

    [Given(@"Modal dialog should display with Message displayed as '(.*)'")]
    [Then(@"Modal dialog should display with Message displayed as '(.*)'")]
    public void ThenModalMessageDisplayedIs(string message)
    {
        Assert.IsTrue(myTitanLocalWebpageExamRoom.WaitUntilModalDialogIsAvailableWithLabel(message), "Disconnect Modal dialog not available");
    }

    [Then(@"Modal dialog 'Vital Signs Cannot Be Displayed' goes away")]
    public void ThenModalDialogGoesAway()
    {
        Assert.IsTrue(myTitanLocalWebpageExamRoom.WaitUntilDisconnectsModalDialogGoesAway(), "Disconnect Modal dialog available");
    }

    [Then(@"HR parameter value in webpage is displayed as three dashes '([^']*)'")]
    public void ThenHRParameterValueInWebpageIsDisplayedAsThreeDashes(string hrValue)
    {
        Assert.IsTrue(myTitanLocalWebpageExamRoom.VerifyHRValueIsPresent(hrValue));
    }
    #endregion

    #region Background

    [Scope(Feature = "VitalSign")]
    [Given(@"Titan configured with apollo successfully done")]
    public void GivenTitanPairingWithApolloIsSuccessfullyDone()
    {
        myApolloSimulatorController.StartApolloSimulator();
        myLocalWebDriver = Titan.Common.Test.WebDriver.CreateInstance(Titan.Common.Test.WebDriver.BrowserType.Chrome);
        myTitanLocalWebpageExamRoom = new TitanUITestController(myLocalWebDriver);
        Assert.IsTrue(myTitanLocalWebpageExamRoom.ConfigureTitanToConnectApollo(), "Failed to configure Titan to connect with Apollo");
        myApolloSimulatorController.StopApolloSimulator();
        Titan.Common.Test.WebDriver.KillWebDriverProcess(Titan.Common.Test.WebDriver.BrowserType.Chrome);
    }
    #endregion
}