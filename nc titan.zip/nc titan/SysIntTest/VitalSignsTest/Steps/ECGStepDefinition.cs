//  <copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>

namespace Titan.SysInt.VitalSigns.Steps.Test;

[Binding]
public sealed class ECGStepDefinition
{
    private TitanUITestController myTitanLocalWebpageExamRoom;
    private TitanUITestController myTitanRemoteWebpageControlRoom;
    private readonly ApolloSimulatorController myApolloSimulatorController;
    private IWebDriver myLocalWebDriver;
    private IWebDriver myRemoteWebDriver;
    private readonly ScenarioContext myScenarioContext;
    public ECGStepDefinition(ScenarioContext scenarioContext)
    {
        ChromeOptions options = new ChromeOptions();
        options.SetLoggingPreference(LogType.Browser, LogLevel.All);
        myApolloSimulatorController = new ApolloSimulatorController();
        myScenarioContext = scenarioContext;
    }

    #region AfterAfterScenario
    [AfterScenario, Scope(Feature = "ECG")]
    public void AfterScenario()
    {
        Assert.IsTrue(myTitanLocalWebpageExamRoom.CleanupForClickOnTheBookmark());
        if (myTitanRemoteWebpageControlRoom != null)
        {
            Assert.IsTrue(myTitanRemoteWebpageControlRoom.CleanupForClickOnTheBookmark());
        }
        Assert.IsTrue(myApolloSimulatorController.StopApolloSimulator());
        Assert.IsTrue(Titan.Common.Test.WebDriver.KillWebDriverProcess(Titan.Common.Test.WebDriver.BrowserType.Chrome));
    }

    #endregion

    #region  BeforeScenario
    [BeforeScenario, Scope(Feature = "ECG")]
    public void BeforeScenario()
    {
        Logger.Log(TraceLevel.Info, "Starting " + myScenarioContext.ScenarioInfo.Tags[0]);
        myApolloSimulatorController.myCurrentTestCaseId = "Electrode_" + myScenarioContext.ScenarioInfo.Tags[0];
        Assert.IsTrue(ApolloSimulatorController.KillPreexistingApolloSimulator());
        Assert.IsTrue(Titan.Common.Test.WebDriver.KillWebDriverProcess(Titan.Common.Test.WebDriver.BrowserType.Chrome));
    }
    #endregion

    #region Common
    /// <summary>
    /// Used for scenario @AT-TTN-SIT-ECG-001
    /// </summary>
    [Scope(Feature = "ECG")]
    [When(@"Apollo simulator is started with csv file '(.*)'")]
    public void GivenApolloSimulatorIsStartedWithCsvFile(string fileName)
    {
        string fileLocation = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
        string filePath = Path.Combine(fileLocation, fileName);
        Logger.Log(TraceLevel.Verbose, filePath);
        if (File.Exists(filePath))
        {
            Assert.IsTrue(myApolloSimulatorController.StartApolloSimulatorWithApolloCsvFile(filePath));
        }
        else
        {
            Logger.Log(TraceLevel.Warning, "File does not exist in the mentioned path : " + filePath);
            Assert.IsTrue(File.Exists(filePath));
        }
    }

    /// <summary>
    /// Used for scenario @AT-TTN-SIT-ECG-002,@AT-TTN-SIT-ECG-003,@AT-TTN-SIT-ECG-006
    /// </summary>
    [Scope(Feature = "ECG")]
    [When(@"Apollo Simulator is started")]
    public void ApolloIsRunning()
    {
        Assert.IsTrue(myApolloSimulatorController.StartApolloSimulator());
    }

    /// <summary>
    /// Used for scenario @AT-TTN-SIT-ECG-001,@AT-TTN-SIT-ECG-002,@AT-TTN-SIT-ECG-003,@AT-TTN-SIT-ECG-004
    /// </summary>
    [Scope(Feature = "ECG")]
    [Given(@"Browser is launched on Exam room and navigated to Titan UI")]
    [Given(@"Browser is launched and navigated to Titan UI")]
    public void BrowserIsLaunchedAndNavigatedToTitanWebpageURL()
    {
        myLocalWebDriver = Titan.Common.Test.WebDriver.CreateInstance(Titan.Common.Test.WebDriver.BrowserType.Chrome);
        myTitanLocalWebpageExamRoom = new TitanUITestController(myLocalWebDriver);
        Assert.IsTrue(myTitanLocalWebpageExamRoom.LaunchBrowserNavigateToTitanURL());
    }

    [Scope(Feature = "ECG")]
    [Given(@"Browser is launched on control room and navigated to Titan UI")]
    public void BrowserIsLaunchedAndNavigatedToControlTitanWebpageURL()
    {
        //Todo: Issue AT 3105: Enable selenium grid after fix
        // create instance of browser in control room
        myRemoteWebDriver = Titan.Common.Test.WebDriver.CreateInstance(Titan.Common.Test.WebDriver.BrowserType.Chrome);
        myTitanRemoteWebpageControlRoom = new TitanUITestController(myRemoteWebDriver);
        Assert.IsTrue(myTitanRemoteWebpageControlRoom.LaunchBrowserNavigateToTitanURL());
    }
    /// <summary>
    /// Used for scenario @AT-TTN-SIT-ECG-001,@AT-TTN-SIT-ECG-002,@AT-TTN-SIT-ECG-003,@AT-TTN-SIT-ECG-004
    /// </summary>
    [Scope(Feature = "ECG")]
    [When(@"Titan UI is visible with monitoring screen")]
    [When(@"Titan UI is visible with monitoring screen on Exam room")]
    public void TitanUIHomepageIsVisible()
    {
        Assert.IsTrue(myTitanLocalWebpageExamRoom.WaitUntilTitanHomePageIsAvailableWithParameterArea(), "Home Page not available");
    }

    /// <summary>
    /// Used for scenario @AT-TTN-SIT-ECG-001,@AT-TTN-SIT-ECG-003
    /// </summary>
    [Scope(Feature = "ECG")]
    [When(@"Titan UI is visible with monitoring screen on Control room")]
    public void TitanHomepageIsVisibleOnControlRoom()
    {
        Assert.IsTrue(myTitanRemoteWebpageControlRoom.WaitUntilTitanHomePageIsAvailableWithParameterArea());
    }


    #endregion

    #region AT-TTN-SIT-ECG-001

    /// <summary>
    /// Used for scenario @AT-TTN-SIT-ECG-001
    /// </summary>
    [Then(@"Verify Message be shown on the Impacted_Lead on waveform area on Exam room")]
    public void ThenMessageShouldBeShownOnTheImpacted_LeadOnTitanUI(Table table)
    {
        List<Tuple<string, string, string>> pairList = new List<Tuple<string, string, string>>();
        foreach (TableRow row in table.Rows)
        {
            List<string> messages = row.Values.ToList();
            Logger.Log(TraceLevel.Verbose, "|");
            messages.ForEach(text => Logger.Log(TraceLevel.Verbose, $"{text}|"));
            pairList.Add(new Tuple<string, string, string>(messages[1], messages[2], messages[3]));

        }
        Assert.IsTrue(myTitanLocalWebpageExamRoom.VerifyElectrodeMessageOnImpactedLeads(pairList, 120000));
    }

    /// <summary>
    /// Used for scenario @AT-TTN-SIT-ECG-001
    /// </summary>
    [Then(@"Verify Message be shown on the Impacted_Lead on waveform area on Control room")]
    public void ThenMessageShouldBeShownOnTheImpactedLeadOnTitanUIOnControlRoom(Table table)
    {
        List<Tuple<string, string, string>> pairList = new List<Tuple<string, string, string>>();
        foreach (TableRow row in table.Rows)
        {
            List<string> messages = row.Values.ToList();
            Logger.Log(TraceLevel.Verbose, "|");
            messages.ForEach(text => Logger.Log(TraceLevel.Verbose, $"{text}|"));
            pairList.Add(new Tuple<string, string, string>(messages[1], messages[2], messages[3]));

        }
        Assert.IsTrue(myTitanRemoteWebpageControlRoom.VerifyElectrodeMessageOnImpactedLeads(pairList, 120000));
    }

    #endregion

    #region AT-TTN-SIT-ECG-002
    /// <summary>
    /// Used for scenario @AT-TTN-SIT-ECG-002
    /// </summary>
    [Then(@"Verify Label is displayed for Lead ""([^""]*)"" on the waveform area")]
    public void ThenLabelIsDisplayedForLeadOnTheTitanUI(string expectedLabel)
    {
        Assert.IsTrue(myTitanLocalWebpageExamRoom.VerifyWaveformLabelPresentOnUI(expectedLabel));
    }
    #endregion

    #region AT-TTN-SIT-ECG-003
    /// <summary>
    /// Used for scenario @AT-TTN-SIT-ECG-003
    /// </summary>
    [Then(@"Verify Default Sweep Speed and Gain Sensitivity label as ""([^""]*)"" & ""([^""]*)"" is displayed on the waveform area in exam room")]
    public void ThenVerifyDefaultSweepSpeedAndGainSensitivityLabelAsIsDisplayedOnTheUIInExamRoom(string expSweepSpeed, string expSensitivity)
    {
        Assert.IsTrue(myTitanLocalWebpageExamRoom.VerifySweepSpeedPresentOnUI(expSweepSpeed));
        Assert.IsTrue(myTitanLocalWebpageExamRoom.VerifySensitivityPresentOnUI(expSensitivity));
    }

    /// <summary>
    /// Used for scenario @AT-TTN-SIT-ECG-003
    /// </summary>
    [Then(@"Verify Default Sweep Speed and Gain Sensitivity label as ""([^""]*)"" & ""([^""]*)"" is displayed on the waveform area in control room")]
    public void ThenVerifyDefaultSweepSpeedAndGainSensitivityLabelAsIsDisplayedOnTheUIInControlRoom(string expSweepSpeed, string expSensitivity)
    {
        Assert.IsTrue(myTitanRemoteWebpageControlRoom.VerifySweepSpeedPresentOnUI(expSweepSpeed));
        Assert.IsTrue(myTitanRemoteWebpageControlRoom.VerifySensitivityPresentOnUI(expSensitivity));
    }

    #endregion

    #region AT-TTN-SIT-ECG-006
    /// <summary>
    /// Used for scenario @AT-TTN-SIT-ECG-ECG-006
    /// </summary>
    [Then(@"Verify Gain Indicator label is displayed for Lead I,II,III ""([^""]*)"" on the waveform area")]
    public void ThenVerifyGainIndicatorWithLabelIsDisplayedForLeadIIIIIIOnTheTitanUI(string expGainIndicator)
    {
        Assert.IsTrue(myTitanLocalWebpageExamRoom.VerifyGainIndicatorLabelPresentOnUI(expGainIndicator));
    }

    /// <summary>
    /// Used for scenario @AT-TTN-SIT-ECG-006
    /// </summary>
    [Then(@"Verify height of Gain Indicator to be (.*) mm within ±(.*) % for default sensitivity of 10mm/mV")]
    public void ThenVerifyHeightOfGainIndicatorToBeMmForDefaultSensitivityOfMmMV(int height, int errorPercentage)
    {
        Assert.IsTrue(myTitanLocalWebpageExamRoom.VerifyGainIndicatorHeightInPixel(height, errorPercentage));
    }
    #endregion

    #region Background

    [Scope(Feature = "ECG")]
    [Given(@"Titan configured with apollo successfully done")]
    public void GivenTitanPairingWithApolloIsSuccessfullyDone()
    {
        myApolloSimulatorController.StartApolloSimulator();
        myLocalWebDriver = Titan.Common.Test.WebDriver.CreateInstance(Titan.Common.Test.WebDriver.BrowserType.Chrome);
        myTitanLocalWebpageExamRoom = new TitanUITestController(myLocalWebDriver);
        Assert.IsTrue(myTitanLocalWebpageExamRoom.ConfigureTitanToConnectApollo(), "Failed to configure Titan to connect with Apollo");
        myApolloSimulatorController.StopApolloSimulator();
        Titan.Common.Test.WebDriver.KillWebDriverProcess(Titan.Common.Test.WebDriver.BrowserType.Chrome);
    }
    #endregion
}