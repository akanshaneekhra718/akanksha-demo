//  <copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>

namespace Titan.SysInt.VitalSigns.Steps.Test;

[Binding]
public sealed class HeartRateStepDefinitions
{
    private TitanUITestController myTitanLocalWebpageExamRoom;

    private TitanUITestController myTitanRemoteWebpageControlRoom;
    private readonly ApolloSimulatorController myApolloSimulatorController;
    private IWebDriver myLocalWebDriver;
    private IWebDriver myRemoteWebDriver;
    private readonly ObserverControllerModule myObserverControllerModule;
    private readonly ScenarioContext myScenarioContext;
    private readonly TestRestClient myTestRestClient;


    public HeartRateStepDefinitions(ScenarioContext scenarioContext)
    {
        myScenarioContext = scenarioContext;
        myApolloSimulatorController = new ApolloSimulatorController();
        myObserverControllerModule = new ObserverControllerModule();
        myTestRestClient = new TestRestClient();
    }

    #region AfterScenario 
    [AfterScenario, Scope(Feature = "HeartRate")]
    public void AfterScenario()
    {
        if (myTitanLocalWebpageExamRoom != null)
            Assert.IsTrue(myTitanLocalWebpageExamRoom.CleanupForClickOnTheBookmark());
        if (myTitanRemoteWebpageControlRoom != null)
        {
            Assert.IsTrue(myTitanRemoteWebpageControlRoom.CleanupForClickOnTheBookmark());
        }
        Assert.IsTrue(myApolloSimulatorController.StopApolloSimulator());
        Assert.IsTrue(Titan.Common.Test.WebDriver.KillWebDriverProcess(Titan.Common.Test.WebDriver.BrowserType.Chrome));
        myObserverControllerModule.StopTestServer();
    }
    #endregion

    #region BeforeScenario
    [BeforeScenario, Scope(Feature = "HeartRate")]
    public void BeforeScenario()
    {
        Logger.Log(TraceLevel.Info, "Starting " + myScenarioContext.ScenarioInfo.Tags[0]);
        myApolloSimulatorController.myCurrentTestCaseId = "HeartRate_" + myScenarioContext.ScenarioInfo.Tags[0];
        Assert.IsTrue(ApolloSimulatorController.KillPreexistingApolloSimulator());
        Assert.IsTrue(Titan.Common.Test.WebDriver.KillWebDriverProcess(Titan.Common.Test.WebDriver.BrowserType.Chrome));
    }
    #endregion

    #region Comman
    /// <summary>
    /// Same step used in the Test :- AT-TTN-SIT-HR-001,002,004,005,006,008,009,012
    /// </summary>
    [Given(@"Apollo Simulator is started")]
    [When(@"Apollo Simulator is started")]
    public void ApolloIsRunning()
    {
        Assert.IsTrue(myApolloSimulatorController.StartApolloSimulator());
    }

    /// <summary>
    ///  Same step used in the Test :- AT-TTN-SIT-HR-001,002,003,004,005,006,007,008,010,012,013,014,321,322,323,324
    /// </summary>
    [Scope(Feature = "HeartRate")]
    [Given(@"Browser is launched and navigated to Titan UI")]
    [When(@"Browser is launched and navigated to Titan UI")]
    public void BrowserIsLaunchedAndNavigatedToTitanWebpageURL()
    {
        myLocalWebDriver = Titan.Common.Test.WebDriver.CreateInstance(Titan.Common.Test.WebDriver.BrowserType.Chrome);
        myTitanLocalWebpageExamRoom = new TitanUITestController(myLocalWebDriver);
      
        Assert.IsTrue(myTitanLocalWebpageExamRoom.LaunchBrowserNavigateToTitanURL());
    }

    /// <summary>
    ///  Same step used in the Test :- AT-TTN-SIT-HR-001,002,004,005,006,007,008,010,011,012,013,014
    /// </summary>
    [Scope(Feature = "HeartRate")]
    [Given(@"Titan UI is visible with monitoring screen")]
    [When(@"Titan UI is visible with monitoring screen")]
    [Then(@"Titan UI is visible with monitoring screen")]
    [Given(@"Titan UI is visible with monitoring screen on Exam room")]
    [When(@"Titan UI is visible with monitoring screen on Exam room")]
    [Then(@"Titan UI is visible with monitoring screen on Exam room")]
    public void TitanUIHomepageIsVisibleWithParameterArea()
    {
        Assert.IsTrue(myTitanLocalWebpageExamRoom.WaitUntilTitanHomePageIsAvailableWithParameterArea(), "Home Page not available");
    }

    /// <summary>
    ///  Same step used in the Test :- AT-TTN-SIT-HR-002,009,011,015,016
    /// </summary>
    [Given(@"Browser is launched and navigated to Titan UI in control room and exam room")]
    [When(@"Browser is launched and navigated to Titan UI in control room and exam room")]
    public void GivenBrowserIsLaunchedAndNavigatedToTitanWebpageURLInBothClient()
    {
        myLocalWebDriver = Titan.Common.Test.WebDriver.CreateInstance(Titan.Common.Test.WebDriver.BrowserType.Chrome);
        myTitanLocalWebpageExamRoom = new TitanUITestController(myLocalWebDriver);
        Assert.IsTrue(myTitanLocalWebpageExamRoom.LaunchBrowserNavigateToTitanURL());

        //Todo: Issue AT 3105: Enable selenium grid after fix
        // create instance of browser in control room
        myRemoteWebDriver = Titan.Common.Test.WebDriver.CreateInstance(Titan.Common.Test.WebDriver.BrowserType.Chrome);

        myTitanRemoteWebpageControlRoom = new TitanUITestController(myRemoteWebDriver);
        Assert.IsTrue(myTitanRemoteWebpageControlRoom.LaunchBrowserNavigateToTitanURL());
    }


    /// <summary>
    ///  Same step used in the Test :- AT-TTN-SIT-HR-002,011,015,016
    /// </summary>
    [Given(@"Titan UI is visible with monitoring screen on Control room")]
    [When(@"Titan UI is visible with monitoring screen on Control room")]
    [Then(@"Titan UI is visible with monitoring screen on Control room")]
    public void TitanHomepageIsVisibleOnControlRoomWithParameterArea()
    {
        Assert.IsTrue(myTitanRemoteWebpageControlRoom.WaitUntilTitanHomePageIsAvailableWithParameterArea());
    }

    /// <summary>
    ///  Same step used in the Test :- AT-TTN-SIT-HR-003,005,012,015
    /// </summary>
    [Then(@"Verify page display with Message displayed as '(.*)'")]
    public void ThenMessageDisplayedIs(string message)
    {
        Assert.IsTrue(myTitanLocalWebpageExamRoom.WaitUntilStaticPageIsAvailableWithLabel(message), "Disconnect Modal dialog not available");
    }

    /// <summary>
    ///  Same step used in the Test :- AT-TTN-SIT-HR-004,005
    /// </summary>
    [Scope(Feature = "HeartRate")]
    [Given(@"Real time value is displayed in monitoring screen in Titan UI")]
    [Then(@"Verify Real time value is displayed in monitoring screen in Titan UI")]
    public void RealTimeValueIsDisplayed()
    {
        Assert.IsTrue(myTitanLocalWebpageExamRoom.VerifyHRValue(), "Hr is in displayed");
    }

    /// <summary>
    ///  Same step used in the Test :- AT-TTN-SIT-HR-008,011,014
    /// </summary>
    [Scope(Feature = "HeartRate")]
    [When(@"Apollo simulator is started with clinical scenario csv file '(.*)'")]
    [Given(@"Apollo simulator is started with clinical scenario csv file '(.*)'")]
    [When(@"Apollo simulator is started with csv file '([^']*)'")]
    public void WhenApolloSimulatorIsStartedWithFile(string fileName)
    {
        string fileLocation = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
        string filePath = Path.Combine(fileLocation, fileName);
        if (File.Exists(filePath))
            Assert.IsTrue(myApolloSimulatorController.StartApolloSimulatorWithApolloCsvFile(filePath));
        else
        {
            Logger.Log(TraceLevel.Warning, "Csv file does not exist on the provided path : " + filePath);
            Assert.IsTrue(File.Exists(filePath));
        }
    }

    /// <summary>
    ///  Same step used in the Test :- AT-TTN-SIT-HR-008,010,011,014
    /// </summary>
    [Then(@"Verify All the HR values mentioned in ""(.*)"" are displayed in the TitanUI")]
    public void ThenAllTheHRValuesMentionedInAreDisplayedInTheTitanUI(string HR_List)
    {
        Assert.IsTrue(myTitanLocalWebpageExamRoom.VerifyContinuosHRValueList(HR_List));
    }

    /// <summary>
    ///  Same step used in the Test :- AT-TTN-SIT-HR-005,012
    /// </summary>
    [When(@"Apollo Simulator is disconnected")]
    public void WhenApolloIsSwitchedOff()
    {
        Assert.IsTrue(myApolloSimulatorController.StopApolloSimulator());
    }

    /// <summary>
    ///  Same step used in the Test :- AT-TTN-SIT-HR-012,013,014
    /// </summary>
    [Given(@"Test code started to observe all the data interfaces")]
    [When(@"Test code started to observe all the data interfaces")]
    public void GivenTestCodeObservingAllTheDataInterface()
    {
        Thread.Sleep(5000); // wait for Apollo to connect 
        TestMessage testMessage = new TestMessage() { CommandType = TestCommandType.Observe, Target = TestTargets.All, TimePeriod = 10 };
        Assert.IsTrue(myObserverControllerModule.StartTestServerAndSendMessage(testMessage));
    }

    [When(@"Wait for observation to complete")]
    public void WhenWaitForObservationToComplete()
    {
        const int TimePeriod = 10;  
        Thread.Sleep(TimePeriod * 1000);
    }

    [Then(@"Verify WorkflowController sends AcquisitionStatus as Apollo disconnected on WebSocket")]
    public void ThenVerifyWorkflowControllerSendsAcquisitionStatusAsApolloDisconnectedOnWebSocket()
    {
        Assert.IsTrue(myObserverControllerModule.VerifyWorkflowControllerSendsAcquisitionStatusApolloConnected(false), "SignalPipeline has not received GRPC AcquisitionStatus to be false");
    }

    [Then(@"Verify TitanUI receives AcquisitionStatus as Apollo disconnected on WebSocket")]
    public void ThenVerifyTitanUIReceivesAcquisitionStatusAsApolloDisconnectedOnWebSocket()
    {
        Assert.IsTrue(myTitanLocalWebpageExamRoom.VerifyApolloStatusInConsole(false), "TitanUI has not received GRPC AcquisitionStatus to be false");
    }
    #endregion



    /// <summary>
    ///  Same step used in the Test :- AT-TTN-SIT-HR-007
    /// </summary>
    [Given(@"HR parameter value in webpage is represented as three dashes '([^']*)'")]
    [Then(@"HR parameter value in webpage is represented as three dashes '(.*)'")]
    public void ThenHRParameterValueInWebpageIsRepresentedAsThreeDashes(string value)
    {
        Assert.IsTrue(myTitanLocalWebpageExamRoom.VerifyHRValueIsPresent(value));
    }

    [Scope(Feature = "HeartRate")]
    [Given(@"Titan configured with apollo successfully done")]
    public void GivenTitanPairingWithApolloIsSuccessfullyDone()
    {
        myApolloSimulatorController.StartApolloSimulator();
        myLocalWebDriver = Titan.Common.Test.WebDriver.CreateInstance(Titan.Common.Test.WebDriver.BrowserType.Chrome);
        myTitanLocalWebpageExamRoom = new TitanUITestController(myLocalWebDriver);
        Assert.IsTrue(myTitanLocalWebpageExamRoom.ConfigureTitanToConnectApollo(), "Failed to configure Titan to connect with Apollo");
        myApolloSimulatorController.StopApolloSimulator();
        Titan.Common.Test.WebDriver.KillWebDriverProcess(Titan.Common.Test.WebDriver.BrowserType.Chrome);
    }

    #region AT-TTN-SIT-HR-001

    [Then(@"Splash screen is visible for 3 sec")]
    public void ThenSplashScreenIsVisibleFor3sec()
    {
        Assert.IsTrue(myTitanLocalWebpageExamRoom.VerifySplashScreenIsPresent());
    }

    [Then(@"Splash screen displays the Product Detail")]
    public void ThenSplashScreenDisplaysTheProductDetails()
    {
        Assert.IsTrue(myTitanLocalWebpageExamRoom.VerifySplashScreenIsPresentWithProductInfo());
    }

    #endregion

    #region AT-TTN-SIT-HR-003
    [When(@"Titan UI is visible")]
    public void TitanUIHomepageIsVisible()
    {
        Assert.IsTrue(myTitanLocalWebpageExamRoom.WaitUntilTitanHomePageIsAvailable(), "Home Page not available");
    }

    #endregion

    #region AT-TTN-SIT-HR-004
   [Then(@"Verify Heart rate label is represented as '(.*)'")]
    public void ThenHeartRateLabelIsRepresentedAs(string label)
    {
        Assert.IsTrue(myTitanLocalWebpageExamRoom.VerifyHRLabelPresentOnUI(label));
    }

    [Then(@"Verify HR Unit is displayed in '([^']*)'")]
    public void ThenHRValueIsDisplayedIn(string hrUnit)
    {
        Assert.IsTrue(myTitanLocalWebpageExamRoom.VerifyHRUnitPresentOnUI(hrUnit));
    }

    #endregion

    #region AT-TTN-SIT-HR-006
    [Then(@"Browser logs data trip time in console logs")]
    public void ThenBrowserLogsDataTripTimeInConsoleLogs()
    {
        Assert.IsTrue(myTitanLocalWebpageExamRoom.VerifyTripTimeInConsole());
    }

    [Then(@"Average trip time is less than '(.*)' millisecond in interval of '(.*)' sec")]
    public void ThenAverageTripTimeIsLessThanMillisecondInIntervalOfSec(int tripTimeThreshold, int durationOfExecution)
    {
        Assert.IsTrue(myTitanLocalWebpageExamRoom.VerifyTripTimeInConsole(tripTimeThreshold, durationOfExecution));
    }

    #endregion

    #region AT-TTN-SIT-HR-007

    [Then(@"Average time difference is less than '(.*)' millisecond in interval of '(.*)' sec between control room and exam room")]
    public void ThenAverageTimeDifferenceBetweenRoom(int timeDifferenceThreshold, int durationOfExecution)
    {
        Assert.IsTrue(myTitanLocalWebpageExamRoom.IsTimeDifferenceBelowThreshold(myTitanRemoteWebpageControlRoom,
        timeDifferenceThreshold, durationOfExecution));
    }
    #endregion

    #region AT-TTN-SIT-HR-010

    [Then(@"Verify All the HR values mentioned in ""(.*)"" are displayed in the Remote TitanUI")]
    public void ThenAllTheHRValuesMentionedInAreDisplayedInTheRemoteTitanUI(string HR_List)
    {
        Assert.IsTrue(myTitanRemoteWebpageControlRoom.VerifyContinuosHRValueList(HR_List));
    }
    #endregion

    #region AT-TTN-SIT-HR-012

    #endregion

    #region AT-TTN-SIT-HR-013
    [Then(@"Verify WorkflowController sends AcquisitionStatus as Apollo connected on WebSocket")]
    public void ThenVerifyWorkflowControllerSendsAcquisitionStatusAsApolloConnectedOnWebSocket()
    {
        Assert.IsTrue(myObserverControllerModule.VerifyWorkflowControllerSendsAcquisitionStatusApolloConnected(true), 
            "WorkflowController has not received GRPC AcquisitionStatus to be true");
    }

    [Then(@"Verify TitanUI receives AcquisitionStatus as Apollo connected on WebSocket")]
    public void ThenVerifyTitanUIReceivesAcquisitionStatusAsApolloConnectedOnWebSocket()
    {
        Assert.IsTrue(myTitanLocalWebpageExamRoom.VerifyApolloStatusInConsole(true), "TitanUI has not received GRPC AcquisitionStatus to be true");
    }

    [Then(@"Static page ""([^""]*)"" disappear")]
    public void WhenStaticPageDisappear(string p0)
    {
        Assert.IsTrue(myTitanLocalWebpageExamRoom.WaitUntilTitanHomePageIsAvailableWithParameterArea(), "Disconnect Modal dialog still available ");
    }

    #endregion

    #region AT-TTN-SIT-HR-014
    [Then(@"Verify SignalPipeline receive AcquisitionData with HR Value ""([^""]*)"" on UdpConnection")]
    public void ThenVerifySignalPipelineReceiveAcquisitionDataWithHRValueOnUdpConnection(string hrValues)
    {
        Assert.IsTrue(myObserverControllerModule.VerifySignalPipelineReceivesHrValues(hrValues), "SignalPipeline has not received Hr values");
    }

    [Then(@"Verify SignalPipeline sends Acquisition data with HR Value ""([^""]*)"" on Websocket")]
    public void ThenVerifySignalPipelineSendsAcquisitionDataWithHRValueOnWebsocket(string hrValues)
    {
        Assert.IsTrue(myObserverControllerModule.VerifySignalPipelineSendsHrValues(hrValues), "SignalPipeline has not sent Hr values");
    }

    [Then(@"Verify TitanUI receives Acquisition data HR Value ""([^""]*)"" on Websocket")]
    public void ThenVerifyTitanUIReceivesAcquisitionDataHRValueOnWebsocket(string hrValues)
    {
        Assert.IsTrue(myTitanLocalWebpageExamRoom.VerifyHrValuesInConsole(hrValues), "TitanUI has not received hr values");
    }
    #endregion

    #region AT-TTN-SIT-HR-015
    [When(@"Titan has internal ""([^""]*)""")]
    public void WhenTitanHasInternal(string error)
    {
        TestMessage testMessage = null;
        if (error.Contains("SignalPipeline error"))
        {
            testMessage = new TestMessage()
            {
                CommandType = TestCommandType.Control,
                Target = TestTargets.SignalPipeline,
                ControlCommand = ControlCommands.Kill
            };
        }
        // expecting false since this message will kill the SignalPipeline.
        // Hence not expecting response back from SignalPipeline.
        Assert.IsFalse(myTestRestClient.SendRestRequest(testMessage, testMessage.Target).GetAwaiter().GetResult());
    }

    [Then(@"Titan Recover with in '([^']*)' min")]
    public void ThenTitanRecoverWithIn(int min)
    {
        Logger.Log(TraceLevel.Info, myTitanLocalWebpageExamRoom.VerifyIsTitanPageGotRecovered(min) ?
            "Titan has recovered" : "Titan Unable to recover from Internal error");
    }

    #endregion

}



