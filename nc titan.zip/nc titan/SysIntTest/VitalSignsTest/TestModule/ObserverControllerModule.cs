﻿//  <copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>

using Titan.WorkflowController.Common;

namespace Titan.SysInt.VitalSigns.Test
{
    internal class ObserverControllerModule
    {
        public TestServer myTestServer;
        private const int MinutesToSeconds = 60;
        private readonly ConcurrentDictionary<SignalPipelineObservationPoint, BlockingCollection<SignalPipelineTestResponse>> mySignalPipelineData;
        private readonly ConcurrentDictionary<WorkflowControllerObservationPoint, BlockingCollection<WorkflowControllerTestResponse>> myWorkflowControllerData;
        private readonly BlockingCollection<string> myWorkflowMessages;

        public ObserverControllerModule()
        {
            mySignalPipelineData = new ConcurrentDictionary<SignalPipelineObservationPoint, BlockingCollection<SignalPipelineTestResponse>>();
            myWorkflowControllerData = new ConcurrentDictionary<WorkflowControllerObservationPoint, BlockingCollection<WorkflowControllerTestResponse>>();
            myWorkflowMessages = new BlockingCollection<string>();
            myTestServer = new TestServer(mySignalPipelineData, myWorkflowControllerData, myWorkflowMessages);
        }

        public bool StartTestServerAndSendMessage(TestMessage testMessage)
        {
            bool isServerStarted;
            myTestServer.SendDataToClientWhenConnected(testMessage);
            isServerStarted = myTestServer.StartAndWaitForClientToConnect(5 * MinutesToSeconds);// wait for 5 minute max
            /* We need not verify if command is received for Observing because we receive data immediately after observation starts
            But in case of Controlling we need to observe the behavior, that is the reason we verify command received */
            if (testMessage.CommandType == TestCommandType.Control && isServerStarted 
            && testMessage.ControlCommand != ControlCommands.Kill) 
                myTestServer.IsCommandAcknowledgedByClient();
            return isServerStarted;
        }

        public void SendToMessageToAllConnectedClient(TestMessage testMessage)
        {
            myTestServer.SendToAllConnectedClient(testMessage);
        }

        public void StopTestServer()
        {
            myTestServer.Stop();
        }

        #region ObservationLogicVerification

        private bool VerifyApolloStatusWhileSendingInWorkflowControllerObservationPoint(bool isApolloConnected)
        {
            string tag = $"\"StatusType\":1,\"State\":{isApolloConnected.ToString().ToLower()}";
            foreach ( string msg in myWorkflowMessages)
            {
                if(msg.Contains(tag))
                    return true;
            }
            return false;
        }

        public bool VerifyWorkflowControllerSendsAcquisitionStatusApolloConnected(bool isApolloConnected) =>
             VerifyApolloStatusWhileSendingInWorkflowControllerObservationPoint(isApolloConnected);

        public bool VerifySignalPipelineReceivesHrValues(string hrValues) =>
            VerifyDatBridgeObservationPointContainsHrValues(hrValues, SignalPipelineObservationPoint.UdpAcquisitionDataReceived);

        private bool VerifyDatBridgeObservationPointContainsHrValues(string hrValues, SignalPipelineObservationPoint observationPoint)
        {
            string[] hrValuesArray = hrValues.Split(',').ToArray();
            bool isFoundAllHrValues = false;
            if (mySignalPipelineData.ContainsKey(observationPoint))
            {
                foreach (var hrValue in hrValuesArray)
                {
                    isFoundAllHrValues = mySignalPipelineData[observationPoint]
                        .Select(x => x.AcquisitionData.VitalSignsData.EcgHeartRate).Any(x => x == Convert.ToUInt32(hrValue));
                    Logger.Log(TraceLevel.Info, $"{hrValue} Found : {isFoundAllHrValues}");
                    if (!isFoundAllHrValues) break;
                }
            }
            return isFoundAllHrValues;
        }

        public bool VerifySignalPipelineSendsHrValues(string hrValues)
        {
            string[] hrValuesArray = hrValues.Split(',').ToArray();
            bool isFoundAllHrValues = false;
            if (mySignalPipelineData.ContainsKey(SignalPipelineObservationPoint.WebSocketDataSend))
            {
                foreach (var hrValue in hrValuesArray)
                {
                    isFoundAllHrValues = mySignalPipelineData[SignalPipelineObservationPoint.WebSocketDataSend]
                        .Where(x => x.AcquisitionData != null)
                        .Select(x => x.AcquisitionData.VitalSignsData.EcgHeartRate).Any(x => x == Convert.ToUInt32(hrValue));
                    Logger.Log(TraceLevel.Info, $"{hrValue} Found : {isFoundAllHrValues}");
                    if (!isFoundAllHrValues) break;
                }
            }
            return isFoundAllHrValues;
        }
        #endregion
    }
}
