//  <copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>

namespace Titan.SysInt.Configuration.Steps.Test;

[Binding]
public class NetworkConfigurationStepDefinitions
{
    private readonly ConfigurationObserverController myConfigurationObserverController;
    private IWebDriver myTitanLocalWebpageExamRoom;
    private CommonUITestDataContract myCommonUITestDataContract;
    private TitanHomePage myTitanHomePage;
    private readonly ConfigurationPage myConfigurationPage;
    private readonly TestMessage myTestMessageObserveStorage;
    private readonly ApolloSimulatorController myApolloSimulatorController;
    private ConfigurationUtility myConfigurationUtility;
    private readonly ScenarioContext myScenarioContext;
    private readonly TestRestClient myTestRestClient;
    private readonly TitanContainerController myTitanContainerController;
    private TitanUITestController myTitanUITestController;
    private readonly UserIdentifierList myUserIdentifierList;

    private Dictionary<string, string> storageSystemInfoData;

    public NetworkConfigurationStepDefinitions(ScenarioContext scenarioContext)
    {
        myConfigurationObserverController = ConfigurationObserverController.Instance;
        myConfigurationPage = new ConfigurationPage();
        myApolloSimulatorController = new ApolloSimulatorController();
        myTitanContainerController = new TitanContainerController();
        myScenarioContext = scenarioContext;
        myTestMessageObserveStorage = new TestMessage()
        {
            CommandType = TestCommandType.Observe,
            Target = TestTargets.WorkflowController,
            ControlCommand = ControlCommands.QueryNetworkParametersFromStorage
        };
        myTestRestClient = new TestRestClient();
        myUserIdentifierList = new UserIdentifierList();
    }

    #region Background
    [Given(@"Apollo simulator is stopped")]
    [When(@"Apollo simulator is stopped")]
    public void GivenApolloSimulatorIsStopped()
    {
        Assert.IsTrue(myApolloSimulatorController.StopApolloSimulator());
        // this sleep is proviede to give some time to test cases that needs to been verified upon apollo disconnected
        Thread.Sleep(TimeSpan.FromSeconds(2));
    }

    [Given(@"Titan is Up and Running")]
    public void GivenIsTitanUpAndRunning()
    {
        try
        {
            GivenTitanUIHomePageIsLaunched();
            Assert.IsTrue(myConfigurationUtility.IsDisconnectedStaticPageAppeared(ConfigurationConstants.Apollo), "Titan Container is down");
            Assert.IsTrue(myTitanHomePage.CleanUp());
            Assert.IsTrue(Common.Test.WebDriver.CleanupForClickOnTheBookmark(myTitanLocalWebpageExamRoom));
            Assert.IsTrue(Common.Test.WebDriver.KillWebDriverProcess(Titan.Common.Test.WebDriver.BrowserType.Chrome));
            myTitanLocalWebpageExamRoom = null;
            myCommonUITestDataContract = null;
            myTitanHomePage = null;
            myConfigurationUtility = null;
        }
        catch (Exception)
        {
            AfterScenario(); // run for cleanup 
            throw;
        }
    }

    #endregion

    #region AfterScenario
    [AfterScenario]
    public void AfterScenario()
    {
        if (myTitanLocalWebpageExamRoom != null)
        {
            Assert.IsTrue(Titan.Common.Test.WebDriver.CleanupForClickOnTheBookmark(myTitanLocalWebpageExamRoom));
        }
        Assert.IsTrue(Titan.Common.Test.WebDriver.KillWebDriverProcess(Titan.Common.Test.WebDriver.BrowserType.Chrome));
        myConfigurationObserverController.StopTestServer();
        myApolloSimulatorController.StopApolloSimulator();
    }

    #endregion

    #region BeforeScenario
    [BeforeScenario(Order = 0)]
    public void BeforeScenario()
    {
        if (myTitanLocalWebpageExamRoom == null)
        {
            GivenTitanUIHomePageIsLaunched();
            if (myCommonUITestDataContract.IsElementDisplayed(myTitanHomePage.UserIdentifierLabel))
            {
                myCommonUITestDataContract.Click(myTitanHomePage.UserIdentifierLabel);
                Assert.IsTrue(myCommonUITestDataContract.IsElementSelected(myTitanHomePage.UserIdentifierLabel));
                myCommonUITestDataContract.MouseHover(myUserIdentifierList.languageLabel);
                Assert.IsTrue(myCommonUITestDataContract.IsElementSelected(myUserIdentifierList.languageLabel));
                myCommonUITestDataContract.Click(myUserIdentifierList.englishLanguageLabel);
                Assert.IsTrue(myCommonUITestDataContract.IsElementSelected(myUserIdentifierList.englishLanguageLabel));
                Assert.IsTrue(Titan.Common.Test.WebDriver.CleanupForClickOnTheBookmark(myTitanLocalWebpageExamRoom));
                Assert.IsTrue(Titan.Common.Test.WebDriver.KillWebDriverProcess(Titan.Common.Test.WebDriver.BrowserType.Chrome));
            }
        }

        myApolloSimulatorController.myCurrentTestCaseId = "Configuration_" + myScenarioContext.ScenarioInfo.Tags[0];
        Assert.IsTrue(myConfigurationObserverController.StartTestServer());
    }

    [BeforeScenario(Order = 1), Scope(Tag = "CheckForStorageExistance")]
    public void BeforeScenarioRun()
    {
        TestMessage testMessage = new TestMessage
        {
            CommandType = TestCommandType.Control,
            Target = TestTargets.WorkflowController,
            ControlCommand = ControlCommands.ValidateSiteConfigurationStorage
        };
        Assert.IsTrue(myTestRestClient.SendRestRequest(testMessage, testMessage.Target).GetAwaiter().GetResult());
    }
    #endregion

    #region Common
    /// <summary>
    /// Used in @AT-TTN-SIT-NetworkConfiguration-001,005,006,010,015,016
    /// AT-TTN-SIT-PairingFeature-025
    /// </summary>
    [Given(@"Apollo simulator is started")]
    [When(@"Apollo simulator is started")]
    [When(@"Apollo simulator is restarted")]
    public void GivenApolloSimulatorIsStarted()
    {

        Assert.IsTrue(myApolloSimulatorController.StartApolloSimulator());
        // this sleep is provided to give some time to test cases that needs to been verified upon apollo started as it some time takes more than 8 sec to up and running
        Thread.Sleep(TimeSpan.FromSeconds(20));
    }

    [When(@"Apollo simulator is started with no existing pairing with Titan")]
    public void WhenApolloSimulatorIsStartedWithNoExistingPairingWithTitan()
    {
        Assert.IsTrue(myApolloSimulatorController.DeleteConfigFiles());
        Assert.IsTrue(myApolloSimulatorController.StartApolloSimulator());
        // this sleep is provided to give some time to test cases that needs to been verified upon apollo started as it some time takes more than 8 sec to up and running
        Thread.Sleep(TimeSpan.FromSeconds(20));
    }

    [Then(@"Verify We Couldn't Connect To Titan message disappear from Titan UI when network is regained")]
    public void ThenVerifyWeCouldntConnectToTitanMessageDisappearFromTitanUIWhenNetworkIsRegained()
    {
        if (myTitanHomePage.LaunchBrowserNavigateToTitanURL())
        {
            Assert.IsTrue(myConfigurationUtility.IsStaticPageDisappeared());
        }
    }

    /// <summary>
    /// Used in @AT-TTN-SIT-NetworkConfiguration-001,007,011,012,013,014,016
    /// AT-TTN-SIT-DisplayApolloSystemInformation-020,021
    /// AT-TTN-SIT-PairingFeature-025
    /// </summary>
    [Then(@"Verify Vital Signs are displayed in Titan monitoring screen")]
    public void WhenVitalSignIsDisplayed()
    {
        Assert.IsTrue(myConfigurationUtility.IsVitalSignsDisplayed());
    }

    /// <summary>
    /// Used in @AT-TTN-SIT-NetworkConfiguration-001
    /// AT-TTN-SIT-PairingFeature-025
    /// </summary>
    [Then(@"Verify Vital Signs are not displayed")]
    public void ThenVerifyVitalSignsAreNotDisplayed()
    {
        Assert.IsFalse(myConfigurationUtility.VerifyVitalSignsNotDisplayed());
    }

    /// <summary>
    /// Used in @AT-TTN-SIT-NetworkConfiguration-001,004
    /// AT-TTN-SIT-PairingFeature-025
    /// </summary>
    [Then(@"Verify Vital parameters are received by titan")]
    public void ThenVerifyVitalParametersAreReceivedByTitan()
    {
        Assert.IsTrue(myConfigurationObserverController.VerifyTitanReceivedVitalParameters());
    }


    /// <summary>
    /// Used in @AT-TTN-SIT-NetworkConfiguration-001,005,006
    /// </summary>
    [Given(@"Storage file is deleted")]
    public void GivenStorageFileIsDeleted()
    {
        myConfigurationObserverController.SendDeleteStorageFileCmd();
        // this sleep is provided to give some time to test cases that needs to be verified upon strorage file deleted
        Thread.Sleep(TimeSpan.FromSeconds(3));
    }

    /// <summary>
    /// Used in @AT-TTN-SIT-NetworkConfiguration-001,005,010
    /// </summary>
    [When(@"Titan attempts to connects to apollo")]
    [When(@"Titan reconnects to Apollo")]
    public void WhenTitanAttemptsToConnectsToApollo()
    {
        myConfigurationObserverController.ReConnect();
        // this sleep is provided to give some time to test cases that needs state machine error connection trigger to be fired
        Thread.Sleep(TimeSpan.FromSeconds(10));
    }


    /// <summary>
    /// Used in @AT-TTN-SIT-NetworkConfiguration-001,005,010,015,016
    /// AT-TTN-SIT-PairingFeature-025
    /// </summary>
    [Then(@"Verify that Titan is not connected to ""([^""]*)""/signal acquisition device")]
    [Then(@"Verify We Couldn't Connect To ""([^""]*)"" message is displayed in Titan UI")]
    public void ThenWeCouldntConnectToApolloMessageIsDisplayedInTitanUI(string component)
    {
        Assert.IsTrue(myConfigurationUtility.IsDisconnectedStaticPageAppeared(component));
    }

    /// <summary>
    /// Used in @AT-TTN-SIT-NetworkConfiguration-001,002,003,004,005,006,015,016
    /// AT-TTN-SIT-PairingFeature-025
    /// </summary>
    [Given(@"Titan UI is launched")]
    [When(@"Titan UI is launched")]
    [When(@"User launches the Titan Monitoring Screen again")]
    public void GivenTitanUIHomePageIsLaunched()
    {
        Assert.IsTrue(Titan.Common.Test.WebDriver.KillWebDriverProcess(Titan.Common.Test.WebDriver.BrowserType.Chrome));
        myTitanLocalWebpageExamRoom = Titan.Common.Test.WebDriver.CreateInstance(Titan.Common.Test.WebDriver.BrowserType.Chrome);
        myCommonUITestDataContract = new CommonUITestDataContract(myTitanLocalWebpageExamRoom);
        myTitanHomePage = new TitanHomePage(myTitanLocalWebpageExamRoom);
        myTitanUITestController = new TitanUITestController(myTitanLocalWebpageExamRoom);
        myConfigurationUtility = new ConfigurationUtility(myCommonUITestDataContract, myConfigurationPage, myTitanHomePage, myTitanUITestController);
        Assert.IsTrue(myTitanHomePage.LaunchBrowserNavigateToTitanURL());
    }

    /// <summary>
    /// Used in @AT-TTN-SIT-NetworkConfiguration-001,007,010,106
    /// AT-TTN-SIT-PairingFeature-025
    /// </summary>
    [When(@"Apply button is clicked")]
    public void WhenClickOnApplyButton()
    {
        if (myCommonUITestDataContract.IsElementDisplayed(myConfigurationPage.ApplyButton))
        {
            myCommonUITestDataContract.Click(myConfigurationPage.ApplyButton);
        }
    }

    /// <summary>
    /// Used in  @AT-TTN-SIT-NetworkConfiguration-001,002,003,004,005,006,010,015,016
    /// AT-TTN-SIT-PairingFeature-025
    /// </summary>
    [When(@"Network configuration dialog is opened via the setting icon")]
    [Given(@"Network configuration dialog is opened via the setting icon")]
    [When(@"User clicks on the setting icon on the Titan UI Page")]
    public void GivenNetworkConfigurationDialogIsOpenedViaTheSettingIcon()
    {
        myCommonUITestDataContract.Click(myTitanHomePage.SettingsIcon);
    }

    /// <summary>
    /// Used in  @AT-TTN-SIT-NetworkConfiguration-003,004
    /// </summary>
    [Given(@"Network menu item in Settings menu is displayed")]
    public void GivenNetworkConfigurationDialogIsDisplayed()
    {
        Assert.IsTrue(myCommonUITestDataContract.IsElementDisplayed(myConfigurationPage.NetworkMenuItem));
    }

    /// <summary>
    /// Used in  @AT-TTN-SIT-NetworkConfiguration-001,003,004,006,016
    /// AT-TTN-SIT-PairingFeature-025
    /// </summary>
    [When(@"Edit button is clicked")]
    [Given(@"Edit button is clicked")]
    public void WhenEditButtonIsClicked()
    {
        if (myCommonUITestDataContract.IsElementDisplayed(myConfigurationPage.EditButton))
        {
            myCommonUITestDataContract.Click(myConfigurationPage.EditButton);
        }
        else
        {
            Logger.Log(TraceLevel.Error, "Edit button is not displayed");
        }
    }

    /// <summary>
    /// Used in  @AT-TTN-SIT-NetworkConfiguration-001,003,004,005,006,010,016
    /// AT-TTN-SIT-PairingFeature-025
    /// </summary>
    [When(@"Hostname ""([^""]*)"", TCPPortNumber (.*) and UDPPortNumber (.*) are entered")]
    [When(@"Hostname ""([^""]*)"" , invalid TCPPortNumber (.*) and UDPPortNumber (.*) are entered")]
    [When(@"Hostname ""([^""]*)"", TCPPortNumber (.*) and UDPPortNumber (.*) are updated")]
    public void WhenHostnameTCPPortNumberAndUDPPortNumberAreEntered(string hostname, int tcpPort, int udpPort)
    {
        string hostnameOrIp = myConfigurationUtility.GetSystemIPAddress();
        myCommonUITestDataContract.SelectAndClearTextBox(myConfigurationPage.HostName);
        if (hostname.ToUpper().Equals("HOST.DOCKER.INTERNAL"))
        {
            myCommonUITestDataContract.EnterTextInTextBox(myConfigurationPage.HostName, hostnameOrIp);
        }
        else
        {
            myCommonUITestDataContract.EnterTextInTextBox(myConfigurationPage.HostName, hostname);
        }
        myCommonUITestDataContract.Click(myConfigurationPage.TcpPort);
        myCommonUITestDataContract.SelectAndClearTextBox(myConfigurationPage.TcpPort);
        myCommonUITestDataContract.EnterTextInTextBox(myConfigurationPage.TcpPort, tcpPort.ToString());
        myCommonUITestDataContract.Click(myConfigurationPage.UdpPort);
        myCommonUITestDataContract.SelectAndClearTextBox(myConfigurationPage.UdpPort);
        myCommonUITestDataContract.EnterTextInTextBox(myConfigurationPage.UdpPort, udpPort.ToString());
    }

    /// <summary>
    /// Used in  @AT-TTN-SIT-NetworkConfiguration-002,003,004
    /// </summary>

    [Then(@"Verify Network Configuration dialog displays the value of parameters same as in storage file")]
    public void ThenNetworkConfigurationDialogRetainsTheLastSavedNetworkParameters()
    {
        myConfigurationObserverController.SendToMessageToAllConnectedClient(myTestMessageObserveStorage);
        myCommonUITestDataContract.Click(myConfigurationPage.EditButton);
        myCommonUITestDataContract.ExplicitWait(myConfigurationPage.TcpPort, 3);
        myCommonUITestDataContract.Click(myConfigurationPage.TcpPort);
        myCommonUITestDataContract.ExplicitWait(myConfigurationPage.UdpPort, 3);
        myCommonUITestDataContract.Click(myConfigurationPage.UdpPort);
        string displayedHostName = myCommonUITestDataContract.GetAttributeValue(myConfigurationPage.HostName, "value");
        int displayedTcpPort = Convert.ToInt32(myCommonUITestDataContract.GetAttributeValue(myConfigurationPage.TcpPort, "value"));
        int displayedUdpPort = Convert.ToInt32(myCommonUITestDataContract.GetAttributeValue(myConfigurationPage.UdpPort, "value"));
        Assert.IsTrue(myConfigurationObserverController.VerifyNetworkParametersAreInStorage(displayedHostName, displayedTcpPort, displayedUdpPort));
    }

    /// <summary>
    /// Used in  @AT-TTN-SIT-NetworkConfiguration-003,004
    /// </summary>
    [Then(@"Verify Hostname ""([^""]*)"", TCPPortNumber (.*) and UDPPortNumber (.*) parameters are not saved in the storage file")]
    public void ThenVerifyNetworkParametersAreNotSavedInTheStorageFile(string hostnanme, int tcpPort, int udpPort)
    {
        myConfigurationObserverController.SendToMessageToAllConnectedClient(myTestMessageObserveStorage);
        Assert.IsFalse(myConfigurationObserverController.VerifyNetworkParametersAreInStorage(hostnanme, tcpPort, udpPort));
    }


    /// <summary>
    /// Used in  @AT-TTN-SIT-NetworkConfiguration-008,009,015
    /// AT-TTN-SIT-PairingFeature-025
    /// </summary>
    [Then(@"Verify error ""([^""]*)"" is displayed in settings dialog")]
    [Then(@"Verify error ""([^""]*)"" is displayed")]
    public void ThenVerifyErrorIsDisplayed(string errorMsg)
    {
        Assert.IsTrue(myConfigurationUtility.IsSocketExceptionMsgDisplayed(errorMsg));
    }

    /// <summary>


    /// @AT-TTN-SIT-NetworkConfiguration-005,015
    /// </summary>
    [Then(@"Verify Hostname,TCP port and UDP port fields are empty")]
    public void ThenVerifyHostnameTCPPortAndUDPPortFieldsAreEmpty()
    {
        Assert.IsTrue(myCommonUITestDataContract.GetAttributeValue(myConfigurationPage.HostName, "class").Contains("shui-element empty"));
        Assert.IsTrue(myCommonUITestDataContract.GetAttributeValue(myConfigurationPage.TcpPort, "class").Contains("shui-element empty"));
        Assert.IsTrue(myCommonUITestDataContract.GetAttributeValue(myConfigurationPage.UdpPort, "class").Contains("shui-element empty"));
    }

    /// <summary>
    /// @AT-TTN-SIT-NetworkConfiguration-001,016
    /// AT-TTN-SIT-PairingFeature-025
    /// </summary>
    [When(@"Settings dialog is closed")]
    public void WhenSettingsDialogIsClosed()
    {
        Thread.Sleep(TimeSpan.FromSeconds(20));
        myCommonUITestDataContract.ExecuteJavaScript(myConfigurationPage.CancelJavaScript);
        Thread.Sleep(TimeSpan.FromSeconds(5));
    }

    /// <summary>
    /// AT-TTN-SIT-PairingFeature-025
    /// </summary>
    [Then(@"Verify Hostname , TCPPortNumber (.*) and UDPPortNumber (.*) are saved in storage file")]
    public void ThenVerifyHostnameTCPPortNumberAndUDPPortNumberAreSavedInStorageFile(int tcpPort, int udpPort)
    {
        string hostnameOrIP = myConfigurationUtility.GetSystemIPAddress();
        myConfigurationObserverController.SendToMessageToAllConnectedClient(myTestMessageObserveStorage);
        Assert.IsTrue(myConfigurationObserverController.VerifyNetworkParametersAreInStorage(hostnameOrIP, tcpPort, udpPort));
    }

    /// <summary>
    /// AT-TTN-SIT-PairingFeature-025
    /// </summary>
    [Then(@"Verify Hostname,TCP port and UDP port fields are readonly")]
    public void ThenHostnameTCPPortAndUDPPortFieldsAreReadonly()
    {
        bool hostNameFiledStatus = Convert.ToBoolean(myCommonUITestDataContract.GetAttributeValue(myConfigurationPage.HostName, "readonly"));
        bool tcpPortNumberFiledStatus = Convert.ToBoolean(myCommonUITestDataContract.GetAttributeValue(myConfigurationPage.TcpPort, "readonly"));
        bool udpPortFieldStatus = Convert.ToBoolean(myCommonUITestDataContract.GetAttributeValue(myConfigurationPage.UdpPort, "readonly"));
        Assert.IsTrue(hostNameFiledStatus && tcpPortNumberFiledStatus && udpPortFieldStatus);
    }
    #endregion

    #region @AT-TTN-SIT-NetworkConfiguration-002
    [Given(@"Network configuration dialog is closed")]
    public void GivenNetworkConfigurationDialogIsClosed()
    {
        Assert.IsTrue(myCommonUITestDataContract.ExecuteJavaScript(myConfigurationPage.CancelJavaScript));
    }
    #endregion

    #region @AT-TTN-SIT-NetworkConfiguration-003
    [When(@"Edit mode is canceled by actions ""([^""]*)""")]
    public void WhenEditModeIsCanceledByActions(string action)
    {
        switch (action)
        {
            case "Cancel Button":
                myCommonUITestDataContract.Click(myConfigurationPage.CancelButton);
                break;
            case "Close button in configuration dialog":
                myCommonUITestDataContract.ExecuteJavaScript(myConfigurationPage.CancelJavaScript);
                myCommonUITestDataContract.Click(myTitanHomePage.SettingsIcon);
                break;
            case "Outside network configuration dialog":
                Actions actions = new Actions(myTitanLocalWebpageExamRoom);
                actions.MoveToElement(myTitanHomePage.TitleHomePage)
                .DoubleClick()
                .Build()
                .Perform();
                myCommonUITestDataContract.Click(myTitanHomePage.SettingsIcon);
                break;
            case "Escape key":
                Actions act = new Actions(myTitanLocalWebpageExamRoom);
                act.SendKeys(Keys.Escape)
                .Build()
                .Perform();
                myCommonUITestDataContract.Click(myTitanHomePage.SettingsIcon);
                break;
        }
    }
    #endregion

    #region @AT-TTN-SIT-NetworkConfiguration-004
    [When(@"Browser close actions ""([^""]*)"" are simulated")]
    public void WhenBrowserCloseActionsAreSimulated(string action)
    {
        switch (action)
        {
            case "Browser is closed":
                myTitanLocalWebpageExamRoom.Quit();
                break;
            case "Browser process is killed":
                Process.GetProcesses().Where(e => e.ProcessName.Contains("chrome")).ToList().ForEach(s => s.Kill());
                break;
        }
    }
    #endregion

    #region @AT-TTN-SIT-NetworkConfiguration-006
    [When(@"Invalid Hostname/Ipaddress ""([^""]*)"" is entered")]
    public void WhenInvalidHostnameIpaddressIsEntered(string hostNameOrIp)
    {
        myCommonUITestDataContract.ClearTextBox(myConfigurationPage.HostName);
        myCommonUITestDataContract.EnterTextInTextBox(myConfigurationPage.HostName, hostNameOrIp);
    }

    [When(@"User focus out of Host Name or IP Address field")]
    public void WhenUserFocusOutOfHostNameOrIPAddressField()
    {
        myCommonUITestDataContract.Click(myConfigurationPage.TcpPort);
    }

    [Then(@"Verify inline error ""([^""]*)"" is displayed for scenario ""([^""]*)""")]
    public void ThenVerifyInlineErrorIsDisplayedForScenario(string errorMsg, string scenario)
    {
        switch (scenario)
        {
            case "MultipleIPsAssociated":
                Assert.IsTrue(myConfigurationUtility.VerifyInlineErrorMsg(errorMsg));
                break;
            case "InvalidIPv4Format":
                Assert.IsTrue(myConfigurationUtility.VerifyInlineErrorMsg(errorMsg));
                break;
            case "HostNotFound":
                Assert.IsTrue(myConfigurationUtility.VerifyInlineErrorMsg(errorMsg));
                break;
            case "HostUnreachable/TimedOut":
                Assert.IsTrue(myConfigurationUtility.VerifyInlineErrorMsg(errorMsg));
                break;
        }
    }

    [Then(@"Apply button is disabled")]
    [Then(@"Verify apply button is disabled")]
    public void ThenApplyButtonIsDisabled()
    {
        Assert.AreEqual("true", (myCommonUITestDataContract.GetAttributeValue(myConfigurationPage.ApplyButton, "aria-disabled")));
    }

    #endregion

    #region @AT-TTN-SIT-NetworkConfiguration-007
    [Given(@"Apollo simulator is started using TCPPortNumber (.*)")]
    public void GivenApolloSimulatorIsStartedAndUsingTCPPortNumber(int tcpPort)
    {
        myApolloSimulatorController.StartApolloSimulator(tcpPort);
    }

    [Then(@"Network configuration parameters fields should not be empty")]
    [Then(@"Verify Network configuration parameters fields should not be empty")]
    public void ThenAlreadySavedConfigurationParametersAreDisplayedInSettingsDialog()
    {
        Assert.IsTrue(myConfigurationUtility.IsNetworkParametersFieldsEmpty());
    }
    #endregion

    #region @AT-TTN-SIT-NetworkConfiguration-014
    [When(@"Network error is induced between Titan and Titan UI")]
    public void NetworkErrorIsInduced()
    {
        myConfigurationObserverController.KillSignalPipeline();
    }


    [Then(@"Verify Vital Signs are displayed in Titan monitoring screen when network is regained")]
    public void ThenVerifyVitalSignsAreDisplayedOnTitanUIWhenNetworkIsRegained()
    {
        if (myTitanHomePage.LaunchBrowserNavigateToTitanURL())
        {
            Assert.IsTrue(myConfigurationUtility.IsVitalSignsDisplayed());
        }
    }
    #endregion

    #region @AT-TTN-SIT-NetworkConfiguration-015

    [Then(@"Edit button is disabled")]
    [Then(@"Verify Edit button is disabled")]
    public void ThenEditButtonIsDisabled()
    {
        Assert.IsTrue(Convert.ToBoolean(myCommonUITestDataContract.GetAttributeValue(myConfigurationPage.EditButton, "disabled")));
    }
    #endregion

    #region @AT-TTN-SIT-NetworkConfiguration-016
    [When(@"User clicks on Network menu item in settings dialog")]
    public void WhenUserClicksOnNetworkMenuItemInSettingsDialog()
    {
        myCommonUITestDataContract.Click(myConfigurationPage.NetworkMenuItem);
    }

    [Then(@"Verify ""([^""]*)"" is displayed for parameters in the Apollo system information")]
    public void ThenVerifyIsDisplayedForParametersInTheApolloSystemInformation(string parameter)
    {
        bool isDefaultCharacterDisplayed = false;
        Dictionary<string, string> UISystemInfoData = myCommonUITestDataContract.GetTextOfWebElements(myConfigurationPage.SystemInformationLabel, myConfigurationPage.SystemInformationValue);
        foreach (KeyValuePair<string, string> item in UISystemInfoData)
        {
            if (item.Value == parameter)
            {
                isDefaultCharacterDisplayed = true;
            }
            else
            {
                isDefaultCharacterDisplayed = false;
                break;
            }
        }
        Assert.IsTrue(isDefaultCharacterDisplayed);
    }
    #endregion

    #region @AT-TTN-SIT-NetworkConfiguration-017
    [When(@"Titan is restarted")]
    public void WhenTitanContainerIsRestarted()
    {
        Assert.IsTrue(myTitanContainerController.StartStopTitanContainer(ActionType.restart));
    }

    #endregion

    #region @AT-TTN-SIT-NetworkConfiguration-018
    [Given(@"Titan container is stopped")]
    [When(@"Titan container is stopped")]
    public void WhenTitanContainerGoesDown()
    {
        Assert.IsTrue(myTitanContainerController.StartStopTitanContainer(ActionType.stop));
    }
    #endregion

    #region @AT-TTN-SIT-NetworkConfiguration-019

    [Given(@"Settings icon is enabled in titan UI")]
    [Then(@"Verify settings icon is enabled")]
    public void GivenSettingsIconIsEnabledInTitanUI()
    {
        bool isSettingsIconDisabled = Convert.ToBoolean(myCommonUITestDataContract.GetAttributeValue(myTitanHomePage.SettingsIcon, "aria-disabled"));
        Assert.IsFalse(isSettingsIconDisabled);
    }

    [Then(@"Verify settings icon is disabled")]
    public void ThenVerifySettingsIconIsDisabled()
    {
        bool isSettingsIconDisabled = Convert.ToBoolean(myCommonUITestDataContract.GetAttributeValue(myTitanHomePage.SettingsIcon, "aria-disabled"));
        Assert.IsTrue(isSettingsIconDisabled);
    }

    [Given(@"Titan container is restarted")]
    [When(@"Titan container is started")]
    public void WhenTitanIsUp()
    {
        Assert.IsTrue(myTitanContainerController.StartStopTitanContainer(ActionType.start));
    }

    #endregion

    #region @AT-TTN-SIT-DisplayApolloSystemInformation-001

    [When(@"User clicks on System information menu item in settings dialog")]
    public void UserClicksOnSystemInformationMenuItemInSettingsDialog()
    {
        int maxTry = 5;
        for (int i = 0; i < maxTry; i++)
        {
            if (Convert.ToBoolean(myCommonUITestDataContract.GetAttributeValue(myConfigurationPage.SystemInfoMenuItem, "active")))
            {
                Logger.Log(TraceLevel.Warning, $"SystemInfoMenuItem was active in {i} attempt after clicking");
                break;
            }
            else
            {
                myCommonUITestDataContract.ExecuteJavaScript(myConfigurationPage.ClickSysInfoTab);
            }
            Thread.Sleep(TimeSpan.FromSeconds(1));
        }
    }

    [Then(@"Verify System information displayed in Titan UI is of connected Apollo device")]
    public void ThenVerifySystemInformationDisplayedInTitanUIIsSameAsInStorageFile()
    {
        Dictionary<string, string> UISystemInfoData = myCommonUITestDataContract.GetTextOfWebElements(myConfigurationPage.SystemInformationLabel, myConfigurationPage.SystemInformationValue);
        TestMessage testmsg = new TestMessage()
        {
            CommandType = TestCommandType.Observe,
            Target = TestTargets.WorkflowController,
            ControlCommand = ControlCommands.QueryApolloSystemInformationFromStorage
        };
        myConfigurationObserverController.SendToMessageToAllConnectedClient(testmsg);
        Assert.IsTrue(myConfigurationObserverController.VerifySystemInformationAreInStorage(UISystemInfoData));

        storageSystemInfoData = UISystemInfoData;
    }
    #endregion

    #region @AT-TTN-SIT-DisplayApolloSystemInformation-002
    [Then(@"Verify Apollo System information displayed is same as that of previously connected Apollo device")]
    public void ThenVerifyApolloSystemInformationDisplayedIsSameAsThatOfPreviouslyConnectedApolloDevice()
    {
        bool isUIdataSameAsStorage = false;
        Dictionary<string, string> UISystemInfoData = myCommonUITestDataContract.GetTextOfWebElements(myConfigurationPage.SystemInformationLabel, myConfigurationPage.SystemInformationValue);
        isUIdataSameAsStorage = UISystemInfoData.OrderBy(element => element.Key).SequenceEqual(storageSystemInfoData.OrderBy(element => element.Key));
        Assert.IsTrue(isUIdataSameAsStorage);
    }
    #endregion

    /// <summary>
    /// AT-TTN-SIT-PairingFeature-025
    /// </summary>
    [Then(@"Verify Edit button is enabled in Titan UI")]
    public void ThenVerifyEditButtonIsEnabledInTitanUI()
    {
        bool isEditIconDisabled = Convert.ToBoolean(myCommonUITestDataContract.GetAttributeValue(myConfigurationPage.EditButton, "aria-disabled"));
        Assert.IsFalse(isEditIconDisabled);
    }
    #region @AT-TTN-SIT-NetworkConfiguration-009
    [Then(@"Verify Error message is disappeared")]
    public void ThenVerifyErrorMessageIsDisappeared()
    {
        Assert.IsFalse(myConfigurationUtility.IsSocketExceptionMsgDisappeared());
    }
    #endregion

}

