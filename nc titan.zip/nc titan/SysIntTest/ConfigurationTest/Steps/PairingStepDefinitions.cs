//  <copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>

namespace Titan.SysInt.Configuration.Steps.Test;

[Binding]
public class PairingStepDefinitions
{
    private readonly ApolloSimulatorController myApolloSimulatorController;
    private readonly ConfigurationObserverController myConfigurationObserverController;

    public PairingStepDefinitions()
    {
        myApolloSimulatorController = new ApolloSimulatorController();
        myConfigurationObserverController = ConfigurationObserverController.Instance;
    }

    #region @AT-TTN-SIT-Pairing-022
    [Given(@"Apollo simulator is started simulating TCP connection is closed forcefully right after connection is established")]
    public void GivenApolloSimulatorIsStartedSimulatingTCPConnectionIsClosedForcefullyRightAfterConnectionIsEstablished()
    {
        // Simulate TCP connection is closed forcefully right after connection is established between Apollo and Titan
        Assert.IsTrue(myApolloSimulatorController.StartApolloSimulator(6708, "26"));
    }
    #endregion

    #region @AT-TTN-SIT-Pairing-023
    [Given(@"Apollo simulator is started simulating no response to any message")]
    public void GivenApolloSimulatorIsStartedSimulatingNoResponseToAnyMessage()
    {
        //Simulate TCP connection is established, but Apollo doesn't respond to any message
        Assert.IsTrue(myApolloSimulatorController.StartApolloSimulator(6708, "27"));
    }
    #endregion

    #region @AT-TTN-SIT-Pairing-024
    [Given(@"Apollo simulator is started simulating protocol version mismatch")]
    public void GivenApolloSimulatorIsStartedSimulatingProtocolVersionMismatch()
    {
        Assert.IsTrue(myApolloSimulatorController.StartApolloSimulator(6708, "18"));
    }
    #endregion

    #region @AT-TTN-SIT-Pairing-025
    [Then(@"Verify Titan is configured with correct protocol version(.*)")]
    public void ThenVerifyTitanIsConfiguredWithCorrectProtocolVersion(int protocolVersion)
    {       
        Assert.IsTrue(myConfigurationObserverController.VerifyProtocolVersionInSystemVersionInfo(protocolVersion));
    }
    #endregion
}

