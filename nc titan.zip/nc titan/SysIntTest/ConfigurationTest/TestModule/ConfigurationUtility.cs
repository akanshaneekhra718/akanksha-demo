﻿//  <copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>

namespace Titan.SysInt.Configuration.Test;
public class ConfigurationUtility
{
    private readonly CommonUITestDataContract myCommonUITestDataContract;
    private readonly ConfigurationPage myConfigurationPage;
    private readonly TitanHomePage myTitanHomePage;
    private readonly TitanUITestController myTitanUITestController;


    public ConfigurationUtility(CommonUITestDataContract commonUITestDataContract, ConfigurationPage configurationPage, TitanHomePage titanHomePage, TitanUITestController titanUITestController)
    {
        myCommonUITestDataContract = commonUITestDataContract;
        myConfigurationPage = configurationPage;
        myTitanHomePage = titanHomePage;
        myTitanUITestController = titanUITestController;
    }

    public ConfigurationUtility(CommonUITestDataContract commonUITestDataContract, ConfigurationPage configurationPage, TitanHomePage titanHomePage)
    {
        myCommonUITestDataContract = commonUITestDataContract;
        myConfigurationPage = configurationPage;
        myTitanHomePage = titanHomePage;
    }
    /// <summary>
    /// Below block of code performs the verification for inline error message for IP tools
    /// </summary>
    /// <param name="msgToBeVerified">string</param>
    /// <returns>boolean</returns>
    public bool VerifyInlineErrorMsg(string msgToBeVerified)
    {
        bool isErrorMsgVerified = false;
        for (int attempted = 0; attempted < ConfigurationConstants.MaxTimeForPingRequest; attempted++)
        {
            if (String.Equals(myCommonUITestDataContract.GetAttributeValue(myConfigurationPage.HostName, "error-message"), msgToBeVerified))
            {
                isErrorMsgVerified = true;
                Logger.Log(TraceLevel.Warning, attempted.ToString());
                break;
            }
            else
            {
                Thread.Sleep(TimeSpan.FromSeconds(1));
            }
        }
        return isErrorMsgVerified;
    }

    /// <summary>
    /// Below block of code performs the verification for configuration parameters should not be empty
    /// </summary>
    public bool IsNetworkParametersFieldsEmpty()
    {
        bool isNetworkParameterEmpty = !string.IsNullOrEmpty(myCommonUITestDataContract.GetAttributeValue(myConfigurationPage.HostName, "value"))
    && !string.IsNullOrEmpty(myCommonUITestDataContract.GetAttributeValue(myConfigurationPage.TcpPort, "value"))
    && !string.IsNullOrEmpty(myCommonUITestDataContract.GetAttributeValue(myConfigurationPage.UdpPort, "value"));
        return isNetworkParameterEmpty;
    }

    /// <summary>
    /// Below block of code checks whether "We could'nt connect to apollo msg" static page diappeared
    /// </summary>
    public bool IsStaticPageDisappeared()
    {
        bool isStaticPageDisappeared = false;
        for (int attempted = 0; attempted < ConfigurationConstants.MaxTimeForStaticPageDisappear; attempted++)
        {
            if (!myCommonUITestDataContract.IsElementPresent(myTitanHomePage.CouldNotConnectToApolloMsg))
            {
                Logger.Log(TraceLevel.Warning, $"We could'nt connect Apollo static page disappeared after {attempted} sec");
                isStaticPageDisappeared = true;
                break;
            }
            else
            {
                Thread.Sleep(TimeSpan.FromSeconds(1));
            }
        }
        if (!isStaticPageDisappeared)
        {
            Logger.Log(TraceLevel.Error, $"We could'nt connect Apollo static page not disappeared even after {ConfigurationConstants.MaxTimeForStaticPageDisappear} sec");
        }
        return isStaticPageDisappeared;
    }

    /// <summary>
    /// Below block of code checks whether error msg displayed when socket exception happens
    /// </summary>
    public bool IsSocketExceptionMsgDisplayed(string socketErrorMsg)
    {
        bool isMsgDisplayed = false;
        for (int attempted = 0; attempted < ConfigurationConstants.MaxTimeForSocketMsgToAppear; attempted++)
        {
            if (myCommonUITestDataContract.GetAttributeValue(myConfigurationPage.ErrorNotificationNetworkConfig, "message").Equals(socketErrorMsg))
            {
                Logger.Log(TraceLevel.Warning, $"Socket exception error msg displayed in {attempted} sec");
                isMsgDisplayed = true;
                break;
            }
            else
            {
                Thread.Sleep(TimeSpan.FromSeconds(1));
            }
        }
        if (!isMsgDisplayed)
        {
            Logger.Log(TraceLevel.Error, $"Socket exception error msg not displayed even after {ConfigurationConstants.MaxTimeForSocketMsgToAppear} sec");
        }
        return isMsgDisplayed;
    }

    /// <summary>
    /// Below block of code will check if Error message disappears 
    /// </summary>
    public bool IsSocketExceptionMsgDisappeared()
    {
         bool IsErrorMsgPresent=myCommonUITestDataContract.IsElementDisplayed(myConfigurationPage.ErrorNotificationNetworkConfig);
         return IsErrorMsgPresent;
    } 

    /// <summary>
    /// Below block of code returns IP of system in which code is running
    /// </summary>
    public string GetSystemIPAddress()
    {
        string hostName = Dns.GetHostName();
        return Dns.GetHostEntry(hostName).AddressList[0].ToString();
    }

    public bool IsDisconnectedStaticPageAppeared(string component)
    {
        bool isStaticPageAppeared = false;
        By labelElement = null;
        switch (component)
        {
            case ConfigurationConstants.Titan:
                labelElement = myTitanHomePage.titanDisconnectedLabel;
                break;
            case ConfigurationConstants.Apollo:
                labelElement = myTitanHomePage.apolloDisconnectedLabel;
                break;
        }
        for (int attempted = 0; attempted < ConfigurationConstants.MaxTimeForStaticPageAppear; attempted++)
        {
            if (myCommonUITestDataContract.IsElementPresent(labelElement))
            {
                Logger.Log(TraceLevel.Warning, $"We could'nt connect {component} static page disappeared after {attempted.ToString()} sec");
                isStaticPageAppeared = true;
                break;
            }
            else
            {
                Thread.Sleep(TimeSpan.FromSeconds(1));
            }
        }
        if (!isStaticPageAppeared)
        {
            Logger.Log(TraceLevel.Error, $"We could'nt connect to {component} static page not disappeared even after {ConfigurationConstants.MaxTimeForSocketMsgToAppear.ToString()} sec");
        }
        return isStaticPageAppeared;
    }

    public bool IsVitalSignsDisplayed()
    {
        bool isElementDisplayed = false;
        TimeSpan maxTestDuration = new TimeSpan(0, 0, ConfigurationConstants.MaxTimeForStaticPageDisappear);
        DateTime startTime = DateTime.UtcNow;
        while(DateTime.UtcNow - startTime <= maxTestDuration)
        {
            if (myTitanUITestController.VerifyHRValueAvailable())
            {
                isElementDisplayed = true;
                Logger.Log(TraceLevel.Warning, (DateTime.UtcNow - startTime).ToString());
                break;
            }
            else
            {
                Thread.Sleep(TimeSpan.FromSeconds(1));
            }
        }
        return isElementDisplayed;
    }

    public bool VerifyLabelandParameterDisplayed(string label, string value)
    {
        bool isLabelandValueDisplayed = false;
        Dictionary<string, string> UISystemInfoData = myCommonUITestDataContract.GetTextOfWebElements(myConfigurationPage.SystemInformationLabel, myConfigurationPage.SystemInformationValue);
        if(UISystemInfoData.ContainsKey(label) && UISystemInfoData[label] == value)
        {
                isLabelandValueDisplayed = true;
        }
        return isLabelandValueDisplayed;
    }

    public bool VerifyVitalSignsNotDisplayed()
    {
        bool isElementNotDisplayed = true;
        for (int attempted = 0; attempted < ConfigurationConstants.MaxTimeForStaticPageDisappear; attempted++)
        {
            if (!myCommonUITestDataContract.IsElementDisplayed(myTitanHomePage.HrValueLocator))
            {
                isElementNotDisplayed = false;
                Logger.Log(TraceLevel.Warning, attempted.ToString());
                break;
            }
            else
            {
                Thread.Sleep(TimeSpan.FromSeconds(1));
            }
        }
        return isElementNotDisplayed;
    }
}

