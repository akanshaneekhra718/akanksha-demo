//  <copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
namespace Titan.SysInt.Configuration.Test;

public static class ConfigurationConstants
{
    // Retry/wait time specific constant
    public static readonly int MaxTimeForStaticPageDisappear =120; //Todo:NEON: this time will be changed after issue {ISSUE 693656} is closed
    public static readonly int MaxTimeForStaticPageAppear =120; //Todo:NEON: this time will be changed after issue {ISSUE 693656} is closed
    public static readonly int MaxTimeForElementToAppear =120; //Todo:NEON: this time will be changed after issue {ISSUE 693656} is closed
    public static readonly int MaxTimeForPingRequest =60;//Todo:NEON: this time will be changed after issue {ISSUE 693656} is closed
    public static readonly int MaxTimeForSocketMsgToAppear = 30;//Todo:NEON: this time will be changed after issue {ISSUE 693656} is closed
    public const string Titan = "Titan";
    public const string Apollo = "Apollo";
}
