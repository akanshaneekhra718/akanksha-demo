//  <copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>

namespace Titan.SysInt.Configuration.Test;
public sealed class ConfigurationPage
{
    public By EditButton => By.Id("editButton");
    public By HostName => By.Id("inputTextHostname");
    public By TcpPort => By.Id("inputTextTcpPort");
    public By UdpPort => By.Id("inputTextUdpPort");
    public By ApplyButton => By.Id("applyButton");
    public By CancelButton => By.Id("cancelButton");
    public By NetworkMenuItem => By.Id("Network");
    public string CancelJavaScript = "document.querySelector('#settings-dialog').shadowRoot.querySelector('.close-button').click()";
    public By ErrorNotificationNetworkConfig => By.Id("inline-error-message");
    public By SystemInfoMenuItem => By.Id("System Information");
    public By SystemInformationLabel => By.Id("Apollo System Information Key");
    public By SystemInformationValue => By.Id("Apollo System Information Value");
    public const string  ClearHostnameTextBoxScript =@"document.getElementById('inputTextHostname').value =""";
    public const string ClearTcpTextBoxScript = @"document.getElementById('inputTextTcpPort').value =""";
    public const string ClearUdpTextBoxScript = @"document.getElementById('inputTextUdpPort').value =""";
    public readonly string ClickSysInfoTab = @"document.getElementById('System Information').click()";
}