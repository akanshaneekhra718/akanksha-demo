//  <copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>

namespace Titan.SysInt.Configuration.Test;
public sealed class UserIdentifierList
{
    public By languageMenu => By.Id("languageMenu");
    public By languageLabel => By.Id("languageLabel");
    public By userIdentifierMenu => By.Id("userIdentifierMenu");
    public By englishLanguageLabel => By.Id("menu-item-en");
    public By germanLanguageLabel => By.Id("menu-item-de");
}