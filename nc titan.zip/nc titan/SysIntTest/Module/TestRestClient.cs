//  <copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>
using Logger = Titan.Common.TitanLogger.Logger;
namespace Titan.SysInt.Module.Test;

public class TestRestClient : IDisposable
{
    private bool myIsDisposed;
    private string mySignalPipelineRestUrl;
    private string myWorkflowControllerRestUrl;
    private readonly HttpClient mySignalPipelineClient;
    private readonly HttpClient myWorkflowControllerClient;
    private const int MaxRetryCount = 3;
    private const string WorkflowControllerTestEndPoint = @"api/test/WorkflowController/";
    private const string SignalPipelineTestEndPoint = @"api/test/SignalPipeline/";

    public TestRestClient()
    {
        GetRestUrl();
        mySignalPipelineClient = new HttpClient()
        {
            BaseAddress = new Uri(mySignalPipelineRestUrl),
            Timeout = TimeSpan.FromSeconds(5),
        };
        myWorkflowControllerClient = new HttpClient()
        {
           BaseAddress = new Uri(myWorkflowControllerRestUrl),
            Timeout = TimeSpan.FromSeconds(5),
        };
    }

    private void GetRestUrl()
    {
        if (!string.IsNullOrEmpty(Environment.GetEnvironmentVariable("RunSITInDebug")))
        {
            mySignalPipelineRestUrl = EndpointConstants.SignalPipelineRestUrl;
            myWorkflowControllerRestUrl = EndpointConstants.WorkflowControllerRestUrl;
        }
        else
        {
            string restHost = Environment.GetEnvironmentVariable("TITAN_WEBPAGE_ADDRESS") ?? TitanUITestModuleConstant.HostName;
            mySignalPipelineRestUrl = "http://" + restHost + ":" + TitanUITestModuleConstant.TitanPort.ToString();
            myWorkflowControllerRestUrl = mySignalPipelineRestUrl;
            
        }
    }

    #region <TraceKey AT-TTN-2040/>
    public async Task<bool> SendRestRequest(TestMessage testMessage, TestTargets testTarget)
    {
        bool response = false;
        try
        {
            switch (testTarget)
            {
                case TestTargets.WorkflowController:
                    response = ProcessResponse(await TriggerHttpRequest(myWorkflowControllerClient, testMessage, WorkflowControllerTestEndPoint));
                    break;
                case TestTargets.SignalPipeline:
                    response = ProcessResponse(await TriggerHttpRequest(mySignalPipelineClient, testMessage, SignalPipelineTestEndPoint));
                    break;
                case TestTargets.All:
                    response = ProcessResponse(await TriggerHttpRequest(myWorkflowControllerClient, testMessage, WorkflowControllerTestEndPoint));
                    response &= ProcessResponse(await TriggerHttpRequest(mySignalPipelineClient, testMessage, SignalPipelineTestEndPoint));
                    break;
                default:
                    break;
            }

        }
        catch (HttpRequestException ex)
        {
            response = false;
            Logger.Log(TraceLevel.Error, ex.Message);
        }
        return response;
    }

    private async Task<HttpResponseMessage> TriggerHttpRequest(HttpClient httpClient, TestMessage testMessage, string endPoint)
    {
        HttpResponseMessage response = null;
        try
        {
            for (int retryCount = MaxRetryCount; retryCount > 0; retryCount--)
            {
                response = await httpClient.PostAsJsonAsync(endPoint, testMessage);
                if (response != null && response.IsSuccessStatusCode)
                {
                    break;
                }
            }
        }
        catch (HttpRequestException ex)
        {
              Logger.Log(TraceLevel.Error, $"{endPoint} : {ex.Message}");
        }
        return response;
    }


    private bool ProcessResponse(HttpResponseMessage response)
    {
        if (response != null && response.IsSuccessStatusCode)
        {
            Common.TitanLogger.Logger.Log(TraceLevel.Info, $"Success sending message to Test RestServer, statusCode: {response.StatusCode}, message: {response.Content}");
            return true;
        }
        else
        {
            HandleFailedResponse(response);
        }
        return false;
    }

    private void HandleFailedResponse(HttpResponseMessage response)
    {
        if (response == null)
        {
            Logger.Log(TraceLevel.Error, $"No response received on Test RestServer");
        }
        else
        {
            Logger.Log(TraceLevel.Info, $"Test RestServer responded with error: statusCode: {response.StatusCode}, message: {response.Content}");
        }
    }
    #endregion

    protected virtual void Dispose(bool disposing)
    {
        if (!myIsDisposed)
        {
            if (disposing)
            {
                mySignalPipelineClient?.Dispose();
                myWorkflowControllerClient?.Dispose();
            }
            myIsDisposed = true;
        }
    }


    public void Dispose()
    {
        Dispose(disposing: true);
        GC.SuppressFinalize(this);
    }
}