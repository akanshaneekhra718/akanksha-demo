//  <copyright> Restricted Copyright (c) Siemens Healthcare GmbH, 2022. All Rights Reserved. </copyright>

namespace Titan.SysInt.Module.Test;
public class TestServer : IDisposable
{
    private int myConnectedClients => myClientList.Count;
    private readonly TcpListener myListener;
    private bool myStopServer;
    private Thread myServerListenerThread;
    private TestMessage myDataToSendWhenClientConnected;
    private readonly BlockingCollection<TcpClient> myClientList;
    private readonly EventWaitHandle myEventServerStarted;
    private readonly EventWaitHandle myEventClientConnected;
    private const int MaxTimeoutForResponse = 8;
    private bool myIsDisposed;
    private readonly AutoResetEvent myCommandResponseReceived;
    private readonly ConcurrentDictionary<SignalPipelineObservationPoint, BlockingCollection<SignalPipelineTestResponse>> mySignalPipelineData;
    private readonly ConcurrentDictionary<WorkflowControllerObservationPoint, BlockingCollection<WorkflowControllerTestResponse>> myWorkflowControllerData;
    private readonly BlockingCollection<string> myWorkflowMsgCollection;

    private TestServer()
    {
        myCommandResponseReceived=new AutoResetEvent(false);
        myListener = new TcpListener(IPAddress.Any, TestConstants.Port);
        myClientList = new BlockingCollection<TcpClient>();
        myEventServerStarted = new EventWaitHandle(false, EventResetMode.ManualReset);
        myEventClientConnected = new EventWaitHandle(false, EventResetMode.ManualReset);
    }

    public TestServer(ConcurrentDictionary<SignalPipelineObservationPoint, BlockingCollection<SignalPipelineTestResponse>> signalPipelineData, 
        ConcurrentDictionary<WorkflowControllerObservationPoint, BlockingCollection<WorkflowControllerTestResponse>> workflowControllerData,
        BlockingCollection<string> workflowMsgCollection) :this()
    {
        myWorkflowControllerData = workflowControllerData;
        mySignalPipelineData = signalPipelineData;
        myWorkflowMsgCollection = workflowMsgCollection;
    }

    private bool Start()
    {
        myStopServer = false;
        myServerListenerThread = new Thread(RunServer);
        myServerListenerThread.Name = "TestServer";
        myServerListenerThread.IsBackground = true;
        myServerListenerThread.Start();
        bool isServerStarted = myEventServerStarted.WaitOne(10000); // wait 10 sec for server to start else raise failed
        if (!isServerStarted)
        {
            myStopServer = true;
            myServerListenerThread.Join();
        }
        return isServerStarted;
    }

    private void RunServer()
    {
        Logger.Log(TraceLevel.Info, "Starting Server");
        StartServerForListener();
        while (!myStopServer)
        {
            try
            {
                Logger.Log(TraceLevel.Info, "Waiting For client");
                TcpClient client = myListener.AcceptTcpClient();
                myClientList.Add(client);
                ThreadPool.QueueUserWorkItem(HandleClient, client);
                Logger.Log(TraceLevel.Info, $"Current client count is ${myConnectedClients}");
            }
            catch (SocketException ex)
            {
                Logger.Log(TraceLevel.Error, "Stopping server due to Exception : {0}", ex.Message);
            }
        }
    }

    private void StartServerForListener()
    {
        try
        {
            myListener.Start();
            myEventServerStarted.Set();
        }
        catch (Exception ex)
        {
            Logger.Log(TraceLevel.Error, "Unable to start server most probably other server is running on same setting");
            Logger.Log(ex);
            myStopServer = true;
        }
    }

    public void Stop()
    {
        myStopServer = true;
        myListener.Server.Close();
        myListener.Stop();
        foreach (TcpClient client in myClientList)
            client.Close();
        Logger.Log(TraceLevel.Verbose, "Waiting for thread to exit");
        myServerListenerThread?.Join();
    }

    public void SendDataToClientWhenConnected(TestMessage testMessage)
    {
        myDataToSendWhenClientConnected = testMessage;
    }

    public void SendToAllConnectedClient(TestMessage testMessage)
    {
        var dataToSend = JsonSerializer.Serialize<TestMessage>(testMessage);
        foreach (TcpClient client in myClientList)
        {
            Send(client, dataToSend);
        }
    }

    public bool StartAndWaitForClientToConnect(int timeInSec)
    {
        if (!Start())
        {
            Logger.Log(TraceLevel.Warning, "Unable to start TestServer");
            return false;
        }

        bool isClientConnected = myEventClientConnected.WaitOne(timeInSec * 1000);
        if (!isClientConnected) Logger.Log(TraceLevel.Warning, "Test failed since no client is connected");
        return isClientConnected;
    }

    private void HandleClient(object obj)
    {
        var client = (TcpClient)obj;
        try
        {
            if(myDataToSendWhenClientConnected != null)
            {
                Send(client, JsonSerializer.Serialize<TestMessage>(myDataToSendWhenClientConnected));
                Logger.Log(TraceLevel.Verbose, "Send data to client : " + 
                    $"Target : {TestTools.GetTypeOfEnum(myDataToSendWhenClientConnected.Target)}, " +
                    $"Commandtype : {TestTools.GetTypeOfEnum(myDataToSendWhenClientConnected.CommandType)}, " +
                    $"ControlCommand : {TestTools.GetTypeOfEnum(myDataToSendWhenClientConnected.ControlCommand)}, " +
                    $"TimePeriod : {myDataToSendWhenClientConnected.TimePeriod}");
            }
            myEventClientConnected.Set();
            while (client.Connected)
            {
                byte[] dataSize = new byte[sizeof(int)];
                ReadTcp(client, dataSize);
                int receivedDataLength = BitConverter.ToInt32(dataSize);
                byte[] receiveMsg = new byte[receivedDataLength];
                ReadTcp(client, receiveMsg);

                string msg = Encoding.Unicode.GetString(receiveMsg);
                var type = JsonSerializer.Deserialize<TestResponse>(msg);
                switch (type.Type)
                {
                    case TestResponseType.Acknowledgement:
                        Logger.Log(TraceLevel.Info, $" Type: {TestTools.GetTypeOfEnum(type.Type)} , Got Message TCP : {msg}");
                        myCommandResponseReceived.Set();
                        break;
                    case TestResponseType.WorkflowController:
                        try
                        {
                            WorkflowControllerTestResponse WorkflowControllerTestResponse = JsonSerializer.Deserialize<WorkflowControllerTestResponse>(msg);
                            Logger.Log(TraceLevel.Info, $"Type: {TestTools.GetTypeOfEnum(type.Type)}, Observation point {TestTools.GetTypeOfEnum(WorkflowControllerTestResponse.ObservationPoint)}, Got Message TCP : {msg}");
                            ProcessWorkflowControllerData(WorkflowControllerTestResponse);
                            myWorkflowMsgCollection.Add(msg);
                        }
                        catch (Exception ex)
                        {
                            Logger.Log(TraceLevel.Error, "unable to cast to WorkflowControllerTestResponse" + ex.ToString());
                        }
                        break;
                    case TestResponseType.SignalPipeline:
                        try
                        {
                            SignalPipelineTestResponse SignalPipelineTestResponse = JsonSerializer.Deserialize<SignalPipelineTestResponse>(msg);
                            Logger.Log(TraceLevel.Info, $"Type: {TestTools.GetTypeOfEnum(type.Type)}, Observation point {TestTools.GetTypeOfEnum(SignalPipelineTestResponse.ObservationPoint)}, Got Message TCP : {msg}");
                            ProcessSignalPipelineData(SignalPipelineTestResponse);
                        }
                        catch (Exception ex)
                        {
                            Logger.Log(TraceLevel.Error, "unable to cast to SignalPipelineTestResponse" + ex.ToString());
                        }
                        break;
                    default:
                        Logger.Log(TraceLevel.Error, "Invalid data received" + msg);
                        break;
                }
            }
        }
        catch (Exception ex)
        {
            Logger.Log(ex);
        }
        finally
        {
            try
            {
                Remove(myClientList, client);
                client?.Close();
                client?.Dispose();
                Logger.Log(TraceLevel.Info, $"Current client count is ${myConnectedClients}");
            }
            catch (Exception ex)
            {
                Logger.Log(ex);
            }
        }
    }


    public bool IsCommandAcknowledgedByClient()
    {
        return myCommandResponseReceived.WaitOne(MaxTimeoutForResponse * 1000);
    }

    private void ProcessWorkflowControllerData(WorkflowControllerTestResponse response)
    {
        if (myWorkflowControllerData == null) return;
        WorkflowControllerObservationPoint receivedTag = response.ObservationPoint;
        if (myWorkflowControllerData.ContainsKey(receivedTag))
        {
            myWorkflowControllerData[receivedTag].Add(response);
        }
        else
        {
            try
            {
                myWorkflowControllerData.TryAdd(receivedTag, new BlockingCollection<WorkflowControllerTestResponse>() { response });

            }
            catch (Exception ex)
            {
                Logger.Log(TraceLevel.Error, $"Unable to add key {Enum.GetName(typeof(WorkflowControllerObservationPoint), receivedTag)} {ex.ToString()}");
            }        
        }
    }
     private void ProcessSignalPipelineData(SignalPipelineTestResponse response)
     {
        if(mySignalPipelineData == null) return;
        SignalPipelineObservationPoint receivedTag= response.ObservationPoint;
        if (mySignalPipelineData.ContainsKey(receivedTag))
        {
            mySignalPipelineData[receivedTag].Add(response);
        }
        else
        {
            try
            {
                mySignalPipelineData.TryAdd(receivedTag, new BlockingCollection<SignalPipelineTestResponse>() { response });

            }
            catch (Exception ex)
            {
                Logger.Log(TraceLevel.Error, $"Unable to add key {Enum.GetName(typeof(SignalPipelineObservationPoint), receivedTag)} {ex.ToString()}");
            }
        }
     }

    private int ReadTcp(TcpClient client, byte[] data)
    {
        DateTime startTime = DateTime.UtcNow;
        TimeSpan allowedTime = new TimeSpan(0, 0, 1);
        int byteRead = 0;
        do
        {
            byteRead += client.GetStream().Read(data, 0 + byteRead, data.Length - byteRead);
            if (byteRead == data.Length)
                break;
        } while (DateTime.UtcNow - startTime < allowedTime);
        if (byteRead != data.Length)
            throw new IOException("Received Invalid data");
        if (byteRead == 0)
            throw new IOException("TCP socket is in CLOSE_WAIT state");
        return byteRead;
    }

    private void Send(TcpClient client, byte[] messageBytes)
    {
        try
        {
            client.GetStream().Write(messageBytes, 0, messageBytes.Length);
        }
        catch (Exception ex)
        {
            Logger.Log(TraceLevel.Error, "Unable to send SenlinkMessageType:" + messageBytes);
            Logger.Log(ex);
        }
    }

    private void Send(TcpClient client, string stringData) => Send(client, Encoding.UTF8.GetBytes(stringData));

    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }

    private bool Remove<T>(BlockingCollection<T> collection, T itemToRemove)
    {
        lock (collection)
        {
            T comparedItem;
            var itemsList = new List<T>();
            do
            {
                var result = collection.TryTake(out comparedItem);
                if (!result)
                    return false;
                if (!comparedItem.Equals(itemToRemove))
                {
                    itemsList.Add(comparedItem);
                }
            } while (!(comparedItem.Equals(itemToRemove)));
            Parallel.ForEach(itemsList, t => collection.Add(t));
        }
        return true;
    }


    protected virtual void Dispose(bool disposing)
    {
        if (!myIsDisposed && disposing)
        {
            foreach (TcpClient client in myClientList)
            {
                myCommandResponseReceived.Dispose();
                client?.Close();
                client?.Dispose();
            }
            myIsDisposed = true;
        }
    }

}
